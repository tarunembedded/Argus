#ifndef INC_FLASH_SECTOR_H_
#define INC_FLASH_SECTOR_H_

#include "stdint.h"
uint32_t FLASH_Write_Data(uint32_t StartSectorAddress, uint32_t *data, uint16_t numberofwords);
uint32_t FLASH_Read_Data(uint32_t StartSectorAddress, uint32_t *Rx_Data, uint16_t numberofwords);
void Convert_to_Str(uint32_t *Data, char *Buf);

#endif
