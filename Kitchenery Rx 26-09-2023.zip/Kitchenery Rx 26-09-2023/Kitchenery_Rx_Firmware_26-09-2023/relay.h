#ifndef _RELAY_H
#define _RELAY_H

#include "Arduino.h"


  ///@brief Function prototype

void RX_Relay_on(void);
void RX_Relay_off(void);

#endif
