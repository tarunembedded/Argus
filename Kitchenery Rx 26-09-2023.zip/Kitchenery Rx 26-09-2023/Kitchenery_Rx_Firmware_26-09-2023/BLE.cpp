/*
   @brief  Project Name: Kitchenery
   @brief  Author Name: Argus Team
   @brief  Task: TX Commands from tx board
   @brief  Development Board:ESP WROOM 32

*/
#include <SoftwareSerial.h>
#include "BLE.h"

#include "current_sensor.h"
#include "temp_sensor.h"
#include "ds3231_rtc.h"


extern char current_data[8];
extern String notify_data;

extern String inputString;         // a String to hold incoming data
bool stringComplete = true;  // whether the string is complete

String debuginputString = "";         // a String to hold incoming data
bool debugstringComplete = false;  // whether the string is complete

char sample_buff[20] = "$BLE,GET,CURR,01";
uint8_t parse_buff[50];
uint8_t debug_parse_buff[50];
char *rest = NULL;
char *debugrest = NULL;

char *parsing = NULL;
char *debugparsing = NULL;
uint8_t BLE_command_flag = 0;
uint8_t datasend_flag = 0;
volatile uint8_t debug_command_flag = 0;
//String debuginputString = "";         // a String to hold incoming data
//bool debugstringComplete = false;  // whether the string is complete

extern   uint8_t* pData;

///@brief This function is used to GET event on serial2
///@brief This function should called at whenever we want data on the serial2
///@return None
///@param None
void serialEvent() {
  if (Serial2.available()) {
    while (Serial2.available()) {
      // get the new byte:
      char inChar = Serial2.read();
      // add it to the inputString:
      inputString += inChar;
      // if the incoming character is a newline, set a flag so the main loop can
      // do something about it:
      if (inChar == '\n') {
        stringComplete = true;
      }
    }
  }
}


///@brief This function is used to GET event on debugserial
///@brief This function should called at whenever we want data on the debugserial
///@return None
///@param None
void serialdebugEvent(void) {
  if (Serial.available()) {
    while (Serial.available()) {
      // get the new byte:
      char inChar1 = Serial.read();
      // add it to the inputString:
      debuginputString += inChar1;

      // if the incoming character is a newline, set a flag so the main loop can
      // do something about it:
      if (inChar1 == '\n') {
        debugstringComplete = true;
      }
    }
  }
}



void debug_reading_data(void)
{
  serialdebugEvent();
  memcpy(debug_parse_buff, debuginputString.c_str(), 50);
  debugparsing = (char *)debug_parse_buff;
  if (debugstringComplete)
  {
    //    Serial.print(debugparsing);
    debugrest = strtok(debugparsing, ",");
    if (!strncmp("$UART", debugrest, 5))
    {
      debugrest = strtok(NULL, ",");
      if (!strncmp("GET", debugrest, 3))
      {
        debugrest = strtok(NULL, ",");
        if (!strncmp("CURR", debugrest, 3))
        {
          debugrest = strtok(NULL, ",");
          if (!strncmp("01", debugrest, 2))
          {

            Serial.println("Read the Rx Current data");
            DB_current_reading();
            delay(2000);

          }
        }
        else if (!strncmp("TEMP", debugrest, 3))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {

            Serial.println("Read the Rx Temperature data"); 
            temp_sensor_reading_at_DB();
            delay(2000);

          }
        }
       else if (!strncmp("TIME", debugrest, 3))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {

            Serial.println("RTC TIME ON");
             RTC_ON();
            delay(2000);

          }
        }
      }
    debuginputString = "";
    debugstringComplete = false;
    }
  }
}
