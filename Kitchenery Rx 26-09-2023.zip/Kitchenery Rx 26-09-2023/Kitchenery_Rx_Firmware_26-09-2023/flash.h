
#ifndef _FLASH_H
#define  _FLASH_H
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define printDETAIL
//#define printINDIVIDUALRUNS
#define NUMBEROFREPEATS 2


#if defined(ARDUINO_SAMD_ZERO) && defined(SERIAL_PORT_USBVIRTUAL)
// Required for Serial on Zero based boards
#define Serial SERIAL_PORT_USBVIRTUAL
#endif

#if defined (SIMBLEE)
#define BAUD_RATE 250000
#define LDR 1
#else
#define BAUD_RATE 115200
#define LDR A0
#endif

// volatile  ConfigurationIn1 configurationIn;
// volatile ConfigurationOut1 configurationOut;

/*typedef struct  {
  float lux = 3.24;
  //  double arr[8] = {0.2, 1.3, 2.4, 3.6, 4.12, 5.4, 6.9, 9.7};
  double arr[8];
  } tConfigurationIn, *ptconfigurationIn;

  typedef struct  {
  float lux;
  double arr[8];
  } tConfigurationOut, *ptconfigurationOut;

  extern  volatile  tConfigurationIn configurationIn;
  extern volatile tConfigurationOut configurationOut;*/
typedef  struct {
  //   float lux = 3.24;
  //  double arr[8] = {0.2, 1.3, 2.4, 3.6, 4.12, 5.4, 6.9, 9.7};
  char arr[1];

  uint8_t   RawRxBuffer[10];
  uint8_t   RawTxBuffer[10];

} tConsoleBdInterface, *ptConsoleBdInterface;

typedef struct {

  char sensor_data[2] = {0};
  //  char sense[50];
} flash_data1;

extern volatile flash_data1 current_sensor_data;

extern  volatile  tConsoleBdInterface configurationIn;
extern  volatile  tConsoleBdInterface configurationOut;



   ///@brief Function prototype
void flash_setup();
void flash_init(void);
void printLine(void);
void printstar();
void FLASH_Erase_Section();
void FLASH_Init();
void getAddresses();
void SPI_FLASH_READ_ALL_Sensor_Data();
void SPI_FLASH_WRITE_ALL_Sensor_Data();


#endif
