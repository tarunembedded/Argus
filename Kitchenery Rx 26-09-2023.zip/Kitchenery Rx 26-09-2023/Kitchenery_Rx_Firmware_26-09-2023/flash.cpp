#include<SPIMemory.h>
#include "flash.h"


#if defined(ARDUINO_SAMD_ZERO) && defined(SERIAL_PORT_USBVIRTUAL)
// Required for Serial on Zero based boards
#define Serial SERIAL_PORT_USBVIRTUAL
#endif

#if defined (SIMBLEE)
#define BAUD_RATE 250000
#else
#define BAUD_RATE 115200
#endif

#define arrayLen(x) sizeof(x)/sizeof(x[0])
char current_data[110];
bool write_spiflash = false;

//SPIFlash flash(SS1, &SPI1);       //Use this constructor if using an SPI bus other than the default SPI. Only works with chips with more than one hardware SPI bus
SPIFlash flash;

uint32_t CharAddr[1];
uint32_t  readaddr[1]={0x0};
uint8_t Write = 0;
uint8_t Read = 10;
uint8_t Flash_write_flag = 0;


char test_data[20]="kitchenery";

extern char All__Sensor_Data_saved[8];
char All__Sensor_Data_read[8];

extern uint8_t spi_read_count;
extern uint8_t spi_write_count;
uint32_t Get_addr;
uint32_t readAdr = 1;


///@brief Initializing the SPI pins for external flash
///@brief This function should be called In the setup function
///@return None
///@param None
void flash_setup()
{
#if defined (ARDUINO_ARCH_SAMD) || (__AVR_ATmega32U4__) || defined(ARCH_STM32)
  while (!Serial) ; // Wait for Serial monitor to open
#endif
  delay(60); //Time to terminal get connected
  //Serial.print(F("INITIALISING SPI-FLASH MEMORY"));

  flash.begin();
  Serial.println(F("SPI-FLASH MEMORY INITIALIZED"));
  flash.eraseChip();      // Uncomment this if you would like to erase chip
  Serial.println(F("FLASH ERASED"));
  flash_init();
  Get_addr = flash.getAddress(sizeof(char));
}

///@brief This function is used to Write the data into flash
///@brief This function should be called In the   whenever we need to write data in to flash
///@return None
///@param None
void SPI_FLASH_WRITE_ALL_Sensor_Data()
{


      write_spiflash = true;
      for (uint8_t i = 0; i < 1; i++)
      {
        CharAddr[i] = flash.getAddress(sizeof(char));
        if (flash.writeCharArray(CharAddr[i], test_data, 8))
        {
          Serial.print(test_data);
          Serial.print("  Written to 0x");
          Serial.println(CharAddr[i], HEX);

        }
      }

  }


///@brief This function is used to Read the data from flash
///@brief This function should be called In the   whenever we need to Read data from flash
///@return None
///@param None
void SPI_FLASH_READ_ALL_Sensor_Data() {

    if(flash.readCharArray(readAdr, test_data, 8))
    {

      Serial.print(All__Sensor_Data_read);
      Serial.print("  Read from 0x");
      Serial.println(readAdr, HEX);

    }
    readAdr = readAdr + 8;

    memset(test_data, '\0', strlen(test_data));
   spi_read_count--; 
}
///@brief This function is used to Initi the device
///@brief This function should be called In the  setup
///@return None
///@param None
void flash_init(void)
{
  uint32_t id = 0;
  uint32_t deviceid = 15679511;
  id = flash.getJEDECID();
  Serial.print("Device ID:");
  Serial.println(id);
  if (id == deviceid)
  {
    Serial.println("FLASH INITIALIZED");
  }
  else {
    Serial.println("ERROR 1");
  }
}
