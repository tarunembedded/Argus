#ifndef _BLE_H
#define _BLE_H


  ///@brief Function prototype



void serialEvent();



#endif
