#include "relay.h"


///@brief This function is used to Turn ON the 230V relay
///@brief This function is called when 230V relay    command is given through BLE,UART and touchpad
///@return None
///@param None

void RX_Relay_on() {

  //digitalWrite(35,HIGH);
//  Serial.println("Power Relay On");

}
void RX_Relay_off() {

  //digitalWrite(35,LOW);
//  Serial.println("Default 12V power On");
}
