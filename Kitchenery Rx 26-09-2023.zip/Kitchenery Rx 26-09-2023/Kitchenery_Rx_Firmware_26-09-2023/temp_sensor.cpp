/*
   @brief  Project Name: Kitchenery
   @brief  Author Name: Argus Team
   @brief  Task: temperature sensor
   @brief  Development Board:ESP WROOM 32

*/
#include "temp_sensor.h"

uint8_t  rx_temp_sensor_falg = 0;

int DB_temp_sensorpin = 36;
float  DB_offset = .4;
float DB_reading;
extern char All__Sensor_Data_saved[];
//extern char aws_server_data;
char DB_temp_server_data[40];


///@brief This function read the ADC pin and converting bits to voltage and converting to temperature
///@brief This function is called when temp command  is received from tx board
///@return None
///@param None
void temp_sensor_reading_at_DB(void)
{
  rx_temp_sensor_falg = 1;
  // Get the voltage reading from the LM35
  DB_reading = analogRead(DB_temp_sensorpin);
  float voltage = (DB_reading /1000); //* (3.3 / 4095.0);
  // Convert the voltage into the temperature in Celsius
  float temperatureC = (voltage - DB_offset) / (0.0195);
  // Print the temperature in Celsius
//  Serial.print("Temperature: ");
//  Serial.print(temperatureC);
//  Serial.print("\xC2\xB0"); // shows degree symbol
//  Serial.print("C  |  ");
  sprintf(All__Sensor_Data_saved, "TEMP:%.2f", temperatureC);
//  Serial.print("DT :");
//  Serial.println(All__Sensor_Data_saved);
//  // Print the temperature in Fahrenheit
//  float temperatureF = (temperatureC * 9.0 / 3.3) + 32.0;
//  Serial.print(temperatureF);
//  Serial.print("\xC2\xB0"); // shows degree symbol
//  Serial.println("F");
  //}
  delay(1000); // wait a second between readings
}
