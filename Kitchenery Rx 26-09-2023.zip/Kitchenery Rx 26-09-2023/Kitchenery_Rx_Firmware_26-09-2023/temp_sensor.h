#ifndef _TEMP_SENSOR_H
#define _TEMP_SENSOR_H

#include "Arduino.h"


  ///@brief Function prototype

void temp_sensor_reading_at_DB(void);



#endif
