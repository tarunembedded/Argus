#include <EEPROM.h>
#include "device_debug_handler.h"
#include "device_eeprom_handler.h"
#include "wifi_credentials_handler.h"
#include "eeprom_param_handler.h"

char eRead[READ_MAXSIZE];

extern volatile  tSystemConfiguration gSystemConfiguration;

///@brief This function is used to save string in internal eeprom
///@brief This function is called in config param write function
///@return None
///@param uint16_t startAt, uint8_t* id, uint16_t len

// Saves string do EEPROM
void Save_String(uint16_t startAt, uint8_t* id, uint16_t len)
{
  //DEBUG_SERIAL.print(strlen(id));
  for (uint16_t i = 0; i < len; i++)
  {
    EEPROM.write(i + startAt, id[i]);
  }
  EEPROM.commit();
}

// Reads string from EEPROM
void Read_String(uint8_t* eBuffer, uint16_t startAt, uint16_t bufor)
{
  for (uint16_t i = 0; i < bufor; i++)
  {
    eRead[i] = (char)EEPROM.read(i + startAt);
    eBuffer[i] = eRead[i];
    // DEBUG_SERIAL.print(eBuffer[i]);
  }
  //len = bufor;
}

//Saves byte to EEPROM
void Save_Byte(int startAt, byte val)
{
  EEPROM.write(startAt, val);

  EEPROM.commit();
}

//Reads byte from EEPROM
byte Read_Byte(byte startAt)
{
  byte Read = -1;

  Read = EEPROM.read(startAt);
  return Read;
}
///@brief This function is to Initilize the internal eeprom
///@brief This function is called in setup function
///@return None
///@param None
void Eeprom_Init()
{
  EEPROM.begin(512);
}

///@brief This function is used to clear the internal eeprom
///@brief This function is called in setup function
///@return None
///@param None
void Eeprom_Clear() {
  DEBUG_TEST_SERIAL.print("Clearing EEPROM..");
  for (int i = 0; i < 512; i++) {
    EEPROM.write(i, 0);
  }
  EEPROM.commit();
  delay(50);
  gSystemConfiguration.Wificheckbit = 0;
  ESP.restart();
}
