#ifndef _RELAY_H
#define _RELAY_H


  ///@brief Function prototype

void relay_init(void);
void k1_power_relay_on(void);
void k1_power_relay_off(void);
void volt12_relay_on(void);
void volt12_relay_off(void);
void half_bridge_relay_on(void);
void half_bridge_relay_off(void);
void fan1_relay_on(void);
void fan1_relay_off(void);
void fan2_relay_on(void);
void fan2_relay_off(void);
void Testing_relay(void);

#endif
