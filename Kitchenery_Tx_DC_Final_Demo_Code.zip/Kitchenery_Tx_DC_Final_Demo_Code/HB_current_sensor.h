#ifndef _HB_CURRENT_SENSOR_H
#define _HB_CURRENT_SENSOR_H



/*
 *  ///@brief Function prototype
 */
void HB_current_reading(void);
float HB_getVPP();
void HB_send_aws_current_data();

#endif
