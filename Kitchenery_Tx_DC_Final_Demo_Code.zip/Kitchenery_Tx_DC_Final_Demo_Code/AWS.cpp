#include <PubSubClient.h>
#include <WiFi.h>
#include "aws_iot_certificates.h"
#include "wifi_credentials_handler.h"
#include "aws.h"

extern WiFiClientSecure net; // = WiFiClientSecure();
extern PubSubClient client;
char server_data[24];


  ///@brief This function is used to connect the AWS server
  ///@brief This function is called when we want send the data to aws server  
  ///@return None
  ///@param None
void connectAWS()
{
  if(WiFi.status() == WL_CONNECTED)
    {
         if (!client.connected()) {
    //reconnect();

  // Configure WiFiClientSecure to use the AWS IoT device credentials
  net.setCACert(AWS_CERT_CA);
  net.setCertificate(AWS_CERT_CRT);
  net.setPrivateKey(AWS_CERT_PRIVATE);

  // Connect to the MQTT broker on the AWS endpoint we defined earlier
  client.setServer(AWS_IOT_ENDPOINT, 8883);

  Serial.println("Connecting to AWS IOT");

  if(!client.connect(THINGNAME)) 
  {
     Serial.println("ERROR 4");

  }
  else
  {
        Serial.println("AWS connected");
  }

  // Subscribe to a topic
  wifi_aws_subscribe();

 // Serial.print("AWS IoT Connected!");
 
//  }
         }
    }
}


  ///@brief This function is used to subscribe the AWS Topic
  ///@brief This function is called at connect AWS function  
  ///@return None
  ///@param None
void wifi_aws_subscribe(void)
{
  client.subscribe(AWS_IOT_SUBSCRIBE_TOPIC);
}
