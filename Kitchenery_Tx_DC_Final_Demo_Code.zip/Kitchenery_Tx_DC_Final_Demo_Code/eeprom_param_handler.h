#ifndef _eeprom_param_handler_h
#define _eeprom_param_handler_h

#define SLAVE_ID_MAX 247      //Maximum slave id entered 255
#define SLAVE_ID_MIN 1        //Minumum slave id entered 1

#define BAUD_MAX_VALUE 4
#define BAUD_MIN_VALUE 0

#define COMM_CONFIG_MAX_VALUE 3
#define COMM_CONFIG_MIN_VALUE 0

#define EOP_TIMER_MAX_VALUE 25
#define EOP_TIMER_MIN_VALUE 3

#define BAUD_RATE_1200   0
#define BAUD_RATE_2400   1
#define BAUD_RATE_4800   2
#define BAUD_RATE_9600   3
#define BAUD_RATE_19200  4


#define SOFTWARE_VERSION_MAX  9
#define SOFTWARE_VERSTION_MIN 1

#define HARDWARE_VERSION_MAX  9
#define HARDWARE_VERSTION_MIN 1
#pragma pack(1)

typedef struct
{
  uint16_t                MagicNumber;            // 0xBEEF
  //Device Information
  uint16_t                Firmware_Version;       // e.g 10000=V1.00.00
  uint8_t                 Device_Model[20];       // ASCII HEX Value/Register
  uint16_t                Protocol_Version;       // e.g 100=V1.00
  uint64_t                chipID;                 // MAC address of Device

  uint8_t                 Wificheckbit;
  //Wifi Settings
  uint8_t                 WifiUsername[64];
  uint8_t                 WifiPassword[64];

  //Device Setup
  uint8_t                 unit_id;
  uint8_t                 baud_rate;
  uint8_t                 comm_config;;
  //uint8_t                 reserved;
  time_t                  firmware_update_date;   // UNIX Timestamp

} tSystemConfiguration, *cfgparam_p;

extern volatile  tSystemConfiguration gSystemConfiguration;

//Default System Configuration.
#define SYSTEM_CONFIG_MAGIC_NUMBER                      0xABCD

#define SYSTEM_CONFIG_DEVICE_MODEL                      "2SPMC-RS-0"
#define SYSTEM_CONFIG_FIRMWARE_VERSION                  10000
#define SYSTEM_CONFIG_PROTOCOL_VERSION                  100
#define SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE              1620655017
#define SYSTEM_CONFIG_UNIT_ID                           200
#define SYSTEM_CONFIG_BAUD_RATE                         3
#define SYSTEM_CONFIG_COMM_CONFIG                       3
#define WIFI_CHECK_BIT                                  0

#define DEFAULT_SSID                                    "bcs"
#define DEFAULT_PASSWORD                                "bcs"





///@brief Function prototype

void dump_cfg_param_info(void);
void config_param_default_init(void);
void config_param_assigned_init(void);
void cfg_param_read(void);
int cfg_param_write(void);


#endif
