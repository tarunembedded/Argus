#ifndef _BLE_H
#define _BLE_H
/**********************************************************************************
   TITLE: Multiple SinricPro Switch device for ESP01 (send data to Arduino through Serial Terminal)
   Click on the following links to learn more.
   YouTube Video: https://youtu.be/YpddzFyWMHA
   Related Blog : https://iotcircuithub.com/arduino-iot-project-with-google-assistant-alexa/
   by Tech StudyCell

   Download the libraries
   SinricPro 2.9.14 Library:     https://github.com/sinricpro/esp8266-esp32-sdk
   ArduinoJson 6.19.1 Library:   https://github.com/bblanchon/ArduinoJson
   WebSockets 2.3.5 Library:     https://github.com/Links2004/arduinoWebSockets
   IRremote 3.5.2 Library:       https://github.com/Arduino-IRremote/Arduino-IRremote
   Arduino-timer 2.3.1 Library:  https://github.com/contrem/arduino-timer
**********************************************************************************/


 ///@brief Function prototype

void send_AT_QMTCONN();
void EG95_init();
void issueCommand(char* msg);
void serialEvent();
void serialdebugEvent(void);
void reading_data();
void debug_reading_data(void);
void send_AT();
void send_AT_REG();
void send_AT_BLEINIT();
void send_AT_BLEGATTSSRVCRE();
void send_AT_BLEGATTSSRVSTART();
void send_AT_BLEADVDATA();
void send_AT_BLEADVSTART();
void send_AT_BLEGATTCRD();
void send_AT_BLEGATTSNTFY();
void BLE_command_handle(void);
void BLE_command_handler(void);
void send_AT_BLEGATTSNTFY_For_Temp();
void send_AT_BLEGATTSNTFY_For_Power_On();
void send_AT_BLEGATTSNTFY_For_Power_Off();
#endif
