
///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: Half Bridge temperature sensor
///@brief  Development Board:ESP WROOM 32

#include "HB_TEMP.h"


int HB_temp_sensorpin = 32;
float  HB_offset = 0.4;
float HB_reading;
char HB_temp_server_data[40];

extern char All__Sensor_Data_saved[];

///@brief This function read the ADC pin and converting bits to voltage and converting to temperature
///@brief This function is called when Half bridge temp command is given through BLE,UART and touchpad
///@return None
///@param None
void temp_sensor_reading_at_HB(void)
{

  // Get the voltage reading from the LM35
  HB_reading = analogRead(HB_temp_sensorpin);
  double voltage =  (HB_reading / 1000); //* (3.3/4095.0) ;
  // Convert the voltage into the temperature in Celsius
  float temperatureC = (voltage - HB_offset) / (0.0195);

  sprintf(All__Sensor_Data_saved, "HT:%.1f", temperatureC);
  Serial.print(All__Sensor_Data_saved);
  Serial.print("  ");
  delay(1000); // wait a second between readings
}
