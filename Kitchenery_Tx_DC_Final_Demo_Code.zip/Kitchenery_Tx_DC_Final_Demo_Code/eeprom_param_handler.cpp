#include "device_debug_handler.h"
#include "eeprom_param_handler.h"
#include "device_eeprom_handler.h"
#include "device_getchipid_handler.h"

volatile   tSystemConfiguration gSystemConfiguration;
  ///@brief This function is used to print the eeprom data
  ///@brief This function is called in setup function 
  ///@return None
  ///@param None
void dump_cfg_param_info(void)
{
  DEBUG_SERIAL_IMP.printf("SYSTEM_CONFIG_MAGIC_NUMBER                  : %x \r\n", (int)gSystemConfiguration.MagicNumber);
  DEBUG_SERIAL_IMP.printf("SYSTEM_CONFIG_CURRENT_VERSION_NUMBER        : %d \r\n", (int)gSystemConfiguration.Firmware_Version);
  DEBUG_SERIAL_IMP.printf("SYSTEM_NAME                                 : %.10s \r\n", (char*)gSystemConfiguration.Device_Model);
  DEBUG_SERIAL_IMP.printf("SYSTEM_ID                                   : %d \r\n", (char*)gSystemConfiguration.Protocol_Version);
  DEBUG_SERIAL_IMP.printf("Device Chip ID                              : %04X", (uint16_t)(gSystemConfiguration.chipID >> 32));   //print High 2 bytes
  DEBUG_SERIAL_IMP.printf("%08X\n", (uint32_t)gSystemConfiguration.chipID); //print Low 4bytes.
  return;
}
  ///@brief This function is to initilize the internal eeprom
  ///@brief This function is called in setup function 
  ///@return None
  ///@param None
void config_param_default_init(void)
{
  memset((void *)&gSystemConfiguration, 0, sizeof(gSystemConfiguration));

  gSystemConfiguration.MagicNumber          = SYSTEM_CONFIG_MAGIC_NUMBER;
  gSystemConfiguration.Firmware_Version     = SYSTEM_CONFIG_FIRMWARE_VERSION;
  gSystemConfiguration.Protocol_Version     = SYSTEM_CONFIG_PROTOCOL_VERSION;
  gSystemConfiguration.Wificheckbit         = WIFI_CHECK_BIT;
  gSystemConfiguration.unit_id              = SYSTEM_CONFIG_UNIT_ID;
  gSystemConfiguration.baud_rate            = SYSTEM_CONFIG_BAUD_RATE;
  gSystemConfiguration.comm_config          = SYSTEM_CONFIG_COMM_CONFIG;
  gSystemConfiguration.firmware_update_date = SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE;

  strncpy((char*)gSystemConfiguration.Device_Model, SYSTEM_CONFIG_DEVICE_MODEL, sizeof(gSystemConfiguration.Device_Model));
  // Default Wi-Fi Credential SSID and PASSWORD
    strncpy((char*)gSystemConfiguration.WifiUsername, DEFAULT_SSID, sizeof(gSystemConfiguration.WifiUsername));
    strncpy((char*)gSystemConfiguration.WifiUsername, DEFAULT_PASSWORD, sizeof(gSystemConfiguration.WifiUsername));
}

void config_param_default_init_for_30sec(void)
{

  gSystemConfiguration.MagicNumber          = SYSTEM_CONFIG_MAGIC_NUMBER;
  gSystemConfiguration.Firmware_Version     = SYSTEM_CONFIG_FIRMWARE_VERSION;
  gSystemConfiguration.Protocol_Version     = SYSTEM_CONFIG_PROTOCOL_VERSION;
  gSystemConfiguration.Wificheckbit         = WIFI_CHECK_BIT;
  gSystemConfiguration.unit_id              = SYSTEM_CONFIG_UNIT_ID;
  gSystemConfiguration.baud_rate            = SYSTEM_CONFIG_BAUD_RATE;
  gSystemConfiguration.comm_config          = SYSTEM_CONFIG_COMM_CONFIG;
  gSystemConfiguration.firmware_update_date = SYSTEM_CONFIG_FIRMWARE_UPDATE_DATE;

  strncpy((char*)gSystemConfiguration.Device_Model, SYSTEM_CONFIG_DEVICE_MODEL, sizeof(gSystemConfiguration.Device_Model));

    strncpy((char*)gSystemConfiguration.WifiUsername, DEFAULT_SSID, sizeof(gSystemConfiguration.WifiUsername));
    strncpy((char*)gSystemConfiguration.WifiUsername, DEFAULT_PASSWORD, sizeof(gSystemConfiguration.WifiUsername));

}

void config_param_assigned_init(void)
{


}
  ///@brief This function read data from the internal eeprom
  ///@brief This function is called in setup function 
  ///@return None
  ///@param None
void cfg_param_read(void)
{
  uint8_t buf1[READ_MAXSIZE];

  int* buf = (int*)&gSystemConfiguration;
  int  len  = sizeof(gSystemConfiguration);
//  DEBUG_TEST_SERIAL.print("Read Function   :");
  Read_String(buf1, 0, len); //Read Data from EEPROM

//  DEBUG_TEST_SERIAL.print(sizeof(gSystemConfiguration));
  memcpy(buf, buf1, sizeof(gSystemConfiguration));
}
  ///@brief This function write the data in to internal eeprom
  ///@brief This function is called whenever we need to write  data into internal flash  
  ///@return None
  ///@param None
int cfg_param_write(void)
{

//  DEBUG_TEST_SERIAL.print("Write Function   :");
  Save_String(0, (uint8_t *)&gSystemConfiguration, sizeof(gSystemConfiguration));
}
