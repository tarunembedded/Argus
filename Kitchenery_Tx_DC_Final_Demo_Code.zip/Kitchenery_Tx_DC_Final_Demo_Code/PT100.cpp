

///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: External temperature sensor PT100
///@brief  Development Board:ESP WROOM 32


#include "PT100.h"
//Variable decleared
float Volts; //voltage read by arduino
float tempC; //final temperature in degree celsius after calibration
float tempF; //final temperature in degree fahrenhiet after calibration
float temp1; //temperatuere before calibration
float calibration; //calibration
float Rx; //Resistance of PT100

// variables that required to convert voltage into resistance
float C = 100.0; //Constant of straight line (Y = mx + C)
float slope = 17.366; // Slope of straight line (Y = mx + C)


// variables that required to convert resistance into temperatures
float R0 = 100.0; //Resistance of minimum temperature to be measured (at 0 degree)
float alpha = 0.00382; // value of alpha from datasheet alpha = (R150-R0)/(150 C * R0)

//pin assignment for sensor
int EXT_temp_sensorpin = 33;

char EXT_temp_server_data[40];
extern char All__Sensor_Data_saved[];


////@brief This function read the ADC pin and converting bits to voltage and converting to temperature
///@brief This function is called when external temp command is given through BLE,UART and touchpad
///@return None
///@param None
void temp_sensor_reading_EXT()
{
  // Bits to Voltage

  int ADC = analogRead(EXT_temp_sensorpin);
  double Volts = ( ADC / 4095.0) * 3.3; //converting bits of voltage into voltage

  // Converting voltage to resistance
  Rx = Volts * slope + C; //y=mx+c

  // Converting resistnace to temperature
  temp1 = ((Rx - R0) / (alpha * R0 ));

  // temp1= ((Rx/R0)-1.0)/alpha; // from Rx = R0(1+alpha*X)
  calibration = 0.3 + (0.005 * temp1); //tolerance for class B PT100
  tempC = temp1 - calibration; // Final temperature in celsius

  sprintf(All__Sensor_Data_saved, "ET:%0.1f", tempC);
  Serial.print(All__Sensor_Data_saved);
  Serial.print("  ");
  delay(1000);
}
