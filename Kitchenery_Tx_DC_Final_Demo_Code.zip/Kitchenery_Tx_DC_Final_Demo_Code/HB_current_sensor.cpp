
///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: Half Bridge current sensor
///@brief  Development Board:ESP WROOM 32


#include <SoftwareSerial.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "HB_current_sensor.h"
//#include "aws.h"

//extern uint8_t  Sensor_falg;

extern char All__Sensor_Data_saved[];

int HB_current_sensorpin = 35;
int HB_mVperAmp = 66; // use 100 for 20A Module and 66 for 30A Module

double HB_Voltage = 0;
double HB_VRMS = 0;
double HB_AmpsRMS = 0;
double HB_AmpsRMS1 = 0;
char HB_current_data[110];
uint8_t HB_rms1 = 0;
int voltage_reading = 0;

///@brief This function convert the ADC values to voltage and that convert to AMPS using root mean square formule
///@brief This function is called when Half bridge current command is given through BLE,UART and touchpad
///@return None
///@param None
void HB_current_reading(void)
{
  //  Sensor_falg = 1;
  HB_Voltage = HB_getVPP();
  HB_VRMS = ((HB_Voltage / 2.0) * 0.707); //root 2 is 0.707
  HB_AmpsRMS = (HB_VRMS * 1000) / HB_mVperAmp;
  HB_AmpsRMS1 = HB_AmpsRMS - 0.39;
  if (HB_AmpsRMS1 < 0.2) {
    HB_AmpsRMS1 = 0;
  }
  sprintf(All__Sensor_Data_saved, "HC:%.1f", HB_AmpsRMS1);
  Serial.print(All__Sensor_Data_saved);
  Serial.print("  ");

  /////@ For testing voltage monitoring function called here
  //  voltage_reading = Half_Voltage_Monitoring();                                        // Note: Voltage Monitoring fucntion
  //  sprintf(All__Sensor_Data_saved, "HC:%.1f", voltage_reading);
  //  Serial.print(All__Sensor_Data_saved);
  //  Serial.print("  ");
}


///@brief This function read the ADC pin
///@brief This function is called at the time of cerrent calculations
///@return Float
///@param None
float HB_getVPP()
{
  float HB_result, HB_result1;
  int HB_readValue;             //value read from the sensor
  int HB_maxValue = 0;          // store max value here
  int HB_minValue = 4096;          // store min value here

  uint32_t HB_start_time = millis();
  while ((millis() - HB_start_time) < 2000) //sample for 1 Sec
  {
    HB_readValue = analogRead(HB_current_sensorpin);
    // Serial.print(readValue);
    //Serial.print(" readValue");

    // see if you have a new maxValue
    if (HB_readValue > HB_maxValue)
    {
      /*record the maximum sensor value*/
      HB_maxValue = HB_readValue;

      //Serial.print(maxValue);
      // Serial.print(" maxValue");
    }
    if (HB_readValue < HB_minValue)
    {
      /*record the minimum sensor value*/
      HB_minValue = HB_readValue;

      // Serial.print(minValue);
      // Serial.print(" minValue");
    }
  }



  // Subtract min from max
  HB_result = ((HB_maxValue - HB_minValue) * 5.0) / 4096.0;
  //Serial.print(result);
  //  Serial.print(" result Value");

  HB_result1 = (HB_maxValue - HB_minValue);
  //Serial.print(result1);
  //  Serial.print(" result1 Value");

  return HB_result;
}
