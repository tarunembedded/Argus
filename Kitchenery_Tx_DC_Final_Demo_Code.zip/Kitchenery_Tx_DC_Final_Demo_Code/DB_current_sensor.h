#ifndef _DB__CURRENT_SENSOR_H
#define _DB__CURRENT_SENSOR_H


  ///@brief Function prototype

void DB_current_reading(void);
float DB_getVPP();
void DB_send_aws_current_data();

#endif
