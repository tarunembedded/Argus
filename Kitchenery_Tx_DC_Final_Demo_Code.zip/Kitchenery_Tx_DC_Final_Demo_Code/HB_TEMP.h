#ifndef _HB_TEMP_H
#define _HB_TEMP_H

#include "Arduino.h"



  ///@brief Function prototype

void temp_sensor_reading_at_HB(void);



#endif
