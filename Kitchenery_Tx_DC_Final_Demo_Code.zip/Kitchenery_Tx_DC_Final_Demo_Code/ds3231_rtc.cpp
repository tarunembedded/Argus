#include "ds3231_rtc.h"

RTC_DS3231 rtc;

char daysOfTheWeek[7][12] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
char rtc_time_stamp_buff[50];
char rtc_time_buff[25];
char rtc_date_buff[25];
char now_unix_time[20];

const char* ntpServer = "pool.ntp.org";
const long  gmtOffset_sec = 19800;
const int   daylightOffset_sec = 0;
  ///@brief This function is used to print the local time
  ///@brief This function is called in the NTP init function 
  ///@return None
  ///@param None
void printLocalTime()
{
  struct tm timeinfo;
  if(!getLocalTime(&timeinfo)){
//    Serial.print("Failed to obtain time");
    Serial.println("ERROR 3");
//    return;
  }
  else {Serial.println(&timeinfo, "DATE: %d %B %Y DAY: %A TIME: %H:%M:%S");
  rtc.adjust(DateTime((timeinfo.tm_year-100),(timeinfo.tm_mon+1) , timeinfo.tm_mday, timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec));
   //Serial.print(&timeinfo);  
   }
}

  ///@brief This function is initializing the NTP server time
  ///@brief This function is called in the setup function 
  ///@return None
  ///@param None
void Ntp_init()
{
  //init and get the time
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  printLocalTime();
}

  ///@brief This function is initializing the RTC
  ///@brief This function is called in the setup function 
  ///@return None
  ///@param None
void RTC_INIT(void)
{
  Serial.println("RTC INITIALIZED");
  if (! rtc.begin()) {
    Serial.println("Couldn't find RTC");
    while (1);
  }

  if (rtc.lostPower()) {
    Serial.println("RTC lost power, lets set the time!");
//     Serial.println("ERROR 3")
  
  // Comment out below lines once you set the date & time.
    // Following line sets the RTC to the date & time this sketch was compiled
//  rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    // Following line sets the RTC with an explicit date & time
    // for example to set January 27 2017 at 12:56 you would call:
    rtc.adjust(DateTime(2023, 3, 13, 11, 41, 0));
  }
   //rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
    // Following line sets the RTC with an explicit date & time
    // for example to set January 27 2017 at 12:56 you wou1d call:
    //rtc.adjust(DateTime(2022, 7, 29, 15, 50, 30));
}

  ///@brief This function is to give the time and data
  ///@brief This function is called whenever we need time and date 
  ///@return None
  ///@param None
void RTC_ON(void)
{
    DateTime now = rtc.now();

    sprintf(rtc_time_stamp_buff,"%d-%02d-%02d %02d:%02d:%02d",now.year(),now.month(),now.day(),now.hour(),now.minute(),now.second());
    sprintf(rtc_time_buff,"TIME :%d:%d:%d",now.hour(),now.minute(),now.second());
    Serial.print(rtc_time_buff);
    Serial.print("  ");
    sprintf(rtc_date_buff,"DATE :%d:%d:%d",now.day(),now.month(),now.year());
    Serial.print(rtc_date_buff);
//    Serial.print(now.unixtime()+3240);
    Serial.print("\n"); 
}
