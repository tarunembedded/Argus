#include "TM1637.h"
#include <Arduino.h>
#include <TM1637Display.h>

// Module connection pins (Digital Pins)
//#define CLK 18
//#define DIO 5

int CLK = 18;
int DIO = 5;

// The amount of time (in milliseconds) between tests
#define TEST_DELAY   2000

TM1637Display display(CLK, DIO);
uint8_t data[] = { 0xff, 0xff, 0xff, 0xff };

const uint8_t SEG_t1[] = {0x78, 0x30, 0x00, 0x00};
const uint8_t SEG_t2[] = {0x78, 0x5B, 0x00, 0x00};
const uint8_t SEG_t3[] = {0x78, 0x4F, 0x00, 0x00};
const uint8_t SEG_t4[] = {0x78, 0x66, 0x00, 0x00};
const uint8_t SEG_t5[] = {0x78, 0x6D, 0x00, 0x00};
const uint8_t SEG_t6[] = {0x78, 0x7D, 0x00, 0x00};
const uint8_t SEG_t7[] = {0x78, 0x07, 0x00, 0x00};
const uint8_t SEG_t8[] = {0x78, 0x7F, 0x00, 0x00};
const uint8_t SEG_t1_2[] = {0x78, 0x30, 0x40, 0x5B};
const uint8_t SEG_t1_3[] = {0x78, 0x30, 0x40, 0x4F};
const uint8_t SEG_t1_4[] = {0x78, 0x30, 0x40, 0x66};
const uint8_t SEG_t1_5[] = {0x78, 0x30, 0x40, 0x6D};
const uint8_t SEG_t2_3[] = {0x78, 0x5B, 0x40, 0x4F};
const uint8_t SEG_t3_4[] = {0x78, 0x4F, 0x40, 0x66};
const uint8_t SEG_t4_5[] = {0x78, 0x66, 0x40, 0x6D};
const uint8_t SEG_t5_6[] = {0x78, 0x6D, 0x40, 0x7D};
const uint8_t SEG_t6_7[] = {0x78, 0x7D, 0x40, 0x07};
const uint8_t SEG_t7_8[] = {0x78, 0x07, 0x40, 0x7F};
const uint8_t SEG_t8_1[] = {0x78, 0x7F, 0x40, 0x30};
const uint8_t SEG_t2_4[] = {0x78, 0x5B, 0x40, 0x66};
const uint8_t SEG_t3_5[] = {0x78, 0x4F, 0x40, 0x6D};
const uint8_t SEG_t5_7[] = {0x78, 0x6D, 0x40, 0x07};



const uint8_t SEG_b1[] = {0x7C, 0x30, 0x00, 0x00};
const uint8_t SEG_b2[] = {0x7C, 0x5B, 0x00, 0x00};
const uint8_t SEG_b3[] = {0x7C, 0x4F, 0x00, 0x00};
const uint8_t SEG_b4[] = {0x7C, 0x66, 0x00, 0x00};
const uint8_t SEG_b5[] = {0x7C, 0x6D, 0x00, 0x00};
const uint8_t SEG_b6[] = {0x7C, 0x7D, 0x00, 0x00};
const uint8_t SEG_b7[] = {0x7C, 0x07, 0x00, 0x00};
const uint8_t SEG_b8[] = {0x7C, 0x7F, 0x00, 0x00};
const uint8_t SEG_b9[] = {0x7C, 0x67, 0x00, 0x00};
const uint8_t SEG_b10[] = {0x7C, 0x30, 0x3F, 0x00};
const uint8_t SEG_b11[] = {0x7C, 0x30, 0x30, 0x00};
const uint8_t SEG_b12[] = {0x7C, 0x30, 0x5B, 0x00};
const uint8_t SEG_b13[] = {0x7C, 0x30, 0x4F, 0x00};
const uint8_t SEG_b14[] = {0x7C, 0x30, 0x66, 0x00};
const uint8_t SEG_b15[] = {0x7C, 0x30, 0x6D, 0x00};
const uint8_t SEG_b16[] = {0x7C, 0x30, 0x7D, 0x00};
const uint8_t SEG_b17[] = {0x7C, 0x30, 0x07, 0x00};
const uint8_t SEG_b18[] = {0x7C, 0x30, 0x7F, 0x00};
const uint8_t SEG_b19[] = {0x7C, 0x30, 0x67, 0x00};
const uint8_t SEG_b20[] = {0x7C, 0x5B, 0x3F, 0x00};

const uint8_t SEG_U1[] = {0x3E, 0x30, 0x00, 0x00};
const uint8_t SEG_U2[] = {0x3E, 0x5B, 0x00, 0x00};
const uint8_t SEG_U3[] = {0x3E, 0x4F, 0x00, 0x00};
const uint8_t SEG_U4[] = {0x3E, 0x66, 0x00, 0x00};
const uint8_t SEG_U5[] = {0x3E, 0x6D, 0x00, 0x00};
const uint8_t SEG_U6[] = {0x3E, 0x7D, 0x00, 0x00};
const uint8_t SEG_U7[] = {0x3E, 0x07, 0x00, 0x00};
const uint8_t SEG_U8[] = {0x3E, 0x7F, 0x00, 0x00};
const uint8_t SEG_U9[] = {0x3E, 0x67, 0x00, 0x00};
const uint8_t SEG_U10[] = {0x3E, 0x30, 0x3F, 0x00};
const uint8_t SEG_U11[] = {0x3E, 0x30, 0x30, 0x00};
const uint8_t SEG_U12[] = {0x3E, 0x30, 0x5B, 0x00};
const uint8_t SEG_U13[] = {0x3E, 0x30, 0x4F, 0x00};
const uint8_t SEG_U14[] = {0x3E, 0x30, 0x66, 0x00};
const uint8_t SEG_U15[] = {0x3E, 0x30, 0x6D, 0x00};
const uint8_t SEG_U16[] = {0x3E, 0x30, 0x7D, 0x00};
const uint8_t SEG_U17[] = {0x3E, 0x30, 0x07, 0x00};
const uint8_t SEG_U18[] = {0x3E, 0x30, 0x7F, 0x00};
const uint8_t SEG_U19[] = {0x3E, 0x30, 0x67, 0x00};
const uint8_t SEG_U20[] = {0x3E, 0x5B, 0x3F, 0x00};

const uint8_t SEG_A1[] = {0x77, 0x30, 0x00, 0x00};
const uint8_t SEG_A2[] = {0x77, 0x5B, 0x00, 0x00};
const uint8_t SEG_A3[] = {0x77, 0x4F, 0x00, 0x00};



///@brief Initialization of 4 digit 7 segment display
///@brief This function should be called In the setup function
///@return None
///@param None
void init_7segment(void)
{
  display.setBrightness(7);
}

///@brief Initially all the segment are in ON state
///@brief This function should be called In the setup function after initilization
///@return None
///@param None
void all_segments_on(void)
{
  // All segments on
  display.setSegments(data);

}

///@brief This function is used to clear the display
///@brief This function should be called whenever we want to clear the display
///@return None
///@param None
void display_clear(void)
{
  display.clear();

}


///@brief This function is used to display "t1" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor1
///@return None
///@param None
void t1_display(void)
{
  display.setSegments(SEG_t1);
}


///@brief This function is used to display "t2" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor2
///@return None
///@param None
void t2_display(void)
{
  display.setSegments(SEG_t2);
}


///@brief This function is used to display "t3" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor3
///@return None
///@param None
void t3_display(void)
{
  display.setSegments(SEG_t3);
}


///@brief This function is used to display "t4" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor4
///@return None
///@param None
void t4_display(void)
{
  display.setSegments(SEG_t4);
}


///@brief This function is used to display "t5" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor5
///@return None
///@param None
void t5_display(void)
{
  display.setSegments(SEG_t5);
}


///@brief This function is used to display "t6" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor6
///@return None
///@param None
void t6_display(void)
{
  display.setSegments(SEG_t6);
}


///@brief This function is used to display "t7" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor7
///@return None
///@param None
void t7_display(void)
{
  display.setSegments(SEG_t7);
}

///@brief This function is used to display "t8" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor8
///@return None
///@param None
void t8_display(void)
{
  display.setSegments(SEG_t8);
}


///@brief This function is used to display "t1-2" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor1 and touchsensor2
///@return None
///@param None
void t1_2_display(void)
{
  display.setSegments(SEG_t1_2);
}

///@brief This function is used to display "t1-3" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor1 and touchsensor3
///@return None
///@param None
void t1_3_display(void)
{
  display.setSegments(SEG_t1_3);
}


///@brief This function is used to display "t1-4" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor1 and touchsensor4
///@return None
///@param None
void t1_4_display(void)
{
  display.setSegments(SEG_t1_4);
}


///@brief This function is used to display "t1-5" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor1 and touchsensor5
///@return None
///@param None
void t1_5_display(void)
{
  display.setSegments(SEG_t1_5);
}


///@brief This function is used to display "t2-3" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor2 and touchsensor3
///@return None
///@param None
void t2_3_display(void)
{
  display.setSegments(SEG_t2_3);
}


///@brief This function is used to display "t2-4" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor2 and touchsensor4
///@return None
///@param None
void t2_4_display(void)
{
  display.setSegments(SEG_t2_4);
}


///@brief This function is used to display "t3-4" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor3 and touchsensor4
///@return None
///@param None
void t3_4_display(void)
{
  display.setSegments(SEG_t3_4);
}


///@brief This function is used to display "t3-5" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor3 and touchsensor5
///@return None
///@param None
void t3_5_display(void)
{
  display.setSegments(SEG_t3_5);
}

///@brief This function is used to display "t4-5" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor4 and touchsensor5
///@return None
///@param None
void t4_5_display(void)
{
  display.setSegments(SEG_t4_5);
}


///@brief This function is used to display "t5-6" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor5 and touchsensor6
///@return None
///@param None
void t5_6_display(void)
{
  display.setSegments(SEG_t5_6);
}


///@brief This function is used to display "t6-7" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor6 and touchsensor7
///@return None
///@param None
void t6_7_display(void)
{
  display.setSegments(SEG_t6_7);
}
///@brief This function is used to display "t7-8" on 7 Segment
///@brief This function should be called whenever we touch the touchsensor7 and touchsensor8
///@return None
///@param None
void t7_8_display(void)
{
  display.setSegments(SEG_t7_8);
}



///@brief This function is used to display "b1" on 7 Segment
///@brief This function is called when 1st command is given through BLE
///@return None
///@param None
void b1_display(void)
{
  display.setSegments(SEG_b1);
}


///@brief This function is used to display "b2" on 7 Segment
///@brief This function is called when 2nd command is given through BLE
///@return None
///@param None

void b2_display(void)
{
  display.setSegments(SEG_b2);
}

/*
  ///@brief This function is used to display "b3" on 7 Segment
  ///@brief This function is called when 3rd command is given through BLE
*/

void b3_display(void)
{
  display.setSegments(SEG_b3);
}

/*
  ///@brief This function is used to display "b4" on 7 Segment
  ///@brief This function is called when 4th command is given through BLE
*/

void b4_display(void)
{
  display.setSegments(SEG_b4);
}

/*
  ///@brief This function is used to display "b5" on 7 Segment
  ///@brief This function is called when 5th command is given through BLE
*/

void b5_display(void)
{
  display.setSegments(SEG_b5);
}

/*
  ///@brief This function is used to display "b6" on 7 Segment
  ///@brief This function is called when 6th command is given through BLE
*/
void b6_display(void)
{
  display.setSegments(SEG_b6);
}


///@brief This function is used to display "b7" on 7 Segment
///@brief This function is called when 7th command is given through BLE
///@return None
///@param None

void b7_display(void)
{
  display.setSegments(SEG_b7);
}

///@brief This function is used to display "b8" on 7 Segment
///@brief This function is called when 8th command is given through BLE
///@return None
///@param None
void b8_display(void)
{
  display.setSegments(SEG_b8);
}


///@brief This function is used to display "b9" on 7 Segment
///@brief This function is called when 9th command is given through BLE
///@return None
///@param None

void b9_display(void)
{
  display.setSegments(SEG_b9);
}


///@brief This function is used to display "b10" on 7 Segment
///@brief This function is called when 10th command is given through BLE
///@return None
///@param None

void b10_display(void)
{
  display.setSegments(SEG_b10);
}


///@brief This function is used to display "b11" on 7 Segment
///@brief This function is called when 11th command is given through BLE
///@return None
///@param None
void b11_display(void)
{
  display.setSegments(SEG_b11);
}


///@brief This function is used to display "b12" on 7 Segment
///@brief This function is called when 12th command is given through BLE
///@return None
///@param None
void b12_display(void)
{
  display.setSegments(SEG_b12);
}

///@brief This function is used to display "b13" on 7 Segment
///@brief This function is called when 13th command is given through BLE
///@return None
///@param None

void b13_display(void)
{
  display.setSegments(SEG_b13);
}


///@brief This function is used to display "b14" on 7 Segment
///@brief This function is called when 14th command is given through BLE
///@return None
///@param None

void b14_display(void)
{
  display.setSegments(SEG_b14);
}


///@brief This function is used to display "b15" on 7 Segment
///@brief This function is called when 15th command is given through BLE
///@return None
///@param None
void b15_display(void)
{
  display.setSegments(SEG_b15);
}


///@brief This function is used to display "b16" on 7 Segment
///@brief This function is called when 16th command is given through BLE
///@return None
///@param None
void b16_display(void)
{
  display.setSegments(SEG_b16);
}


///@brief This function is used to display "b17" on 7 Segment
///@brief This function is called when 17th command is given through BLE
///@return None
///@param None
void b17_display(void)
{
  display.setSegments(SEG_b17);
}


///@brief This function is used to display "b18" on 7 Segment
///@brief This function is called when 18th command is given through BLE
///@return None
///@param None
void b18_display(void)
{
  display.setSegments(SEG_b18);
}


///@brief This function is used to display "b19" on 7 Segment
///@brief This function is called when 19th command is given through BLE
///@return None
///@param None
void b19_display(void)
{
  display.setSegments(SEG_b19);
}

///@brief This function is used to display "b20" on 7 Segment
///@brief This function is called when 20th command is given through BLE
///@return None
///@param None
void b20_display(void)
{
  display.setSegments(SEG_b20);
}


///@brief This function is used to display "U1" on 7 Segment
///@brief This function is called when 1st command is given through UART
///@return None
///@param None
void U1_display(void)
{
  display.setSegments(SEG_U1);
}


///@brief This function is used to display "U2" on 7 Segment
///@brief This function is called when 2nd command is given through UART
///@return None
///@param None
void U2_display(void)
{
  display.setSegments(SEG_U2);
}



///@brief This function is used to display "U3" on 7 Segment
///@brief This function is called when 3rd command is given through UART
///@return None
///@param None
void U3_display(void)
{
  display.setSegments(SEG_U3);
}



///@brief This function is used to display "U4" on 7 Segment
///@brief This function is called when 4th command is given through UART
///@return None
///@param None
void U4_display(void)
{
  display.setSegments(SEG_U4);
}



///@brief This function is used to display "U5" on 7 Segment
///@brief This function is called when 5th command is given through UART
///@return None
///@param None
void U5_display(void)
{
  display.setSegments(SEG_U5);
}



///@brief This function is used to display "U6" on 7 Segment
///@brief This function is called when 6th command is given through UART
///@return None
///@param None
void U6_display(void)
{
  display.setSegments(SEG_U6);
}


///@brief This function is used to display "U7" on 7 Segment
///@brief This function is called when 7th command is given through UART
///@return None
///@param None
void U7_display(void)
{
  display.setSegments(SEG_U7);
}


///@brief This function is used to display "U8" on 7 Segment
///@brief This function is called when 8th command is given through UART
///@return None
///@param None
void U8_display(void)
{
  display.setSegments(SEG_U8);
}


///@brief This function is used to display "U9" on 7 Segment
///@brief This function is called when 9th command is given through UART
///@return None
///@param None
void U9_display(void)
{
  display.setSegments(SEG_U9);
}


///@brief This function is used to display "U10" on 7 Segment
///@brief This function is called when 10th command is given through UART
///@return None
///@param None
void U10_display(void)
{
  display.setSegments(SEG_U10);
}


///@brief This function is used to display "U11" on 7 Segment
///@brief This function is called when 11th command is given through UART
///@return None
///@param None
void U11_display(void)
{
  display.setSegments(SEG_U11);
}


///@brief This function is used to display "U12" on 7 Segment
///@brief This function is called when 12th command is given through UART
///@return None
///@param None
void U12_display(void)
{
  display.setSegments(SEG_U12);
}


///@brief This function is used to display "U13" on 7 Segment
///@brief This function is called when 13th command is given through UART
///@return None
///@param None
void U13_display(void)
{
  display.setSegments(SEG_U13);
}


///@brief This function is used to display "U14" on 7 Segment
///@brief This function is called when 14th command is given through UART
///@return None
///@param None
void U14_display(void)
{
  display.setSegments(SEG_U14);
}


///@brief This function is used to display "U15" on 7 Segment
///@brief This function is called when 15th command is given through UART
///@return None
///@param None
void U15_display(void)
{
  display.setSegments(SEG_U15);
}


///@brief This function is used to display "U16" on 7 Segment
///@brief This function is called when 16th command is given through UART
///@return None
///@param None
void U16_display(void)
{
  display.setSegments(SEG_U16);
}


///@brief This function is used to display "U17" on 7 Segment
///@brief This function is called when 17th command is given through UART
///@return None
///@param None
void U17_display(void)
{
  display.setSegments(SEG_U17);
}


///@brief This function is used to display "U18" on 7 Segment
///@brief This function is called when 18th command is given through UART
///@return None
///@param None
void U18_display(void)
{
  display.setSegments(SEG_U18);
}


///@brief This function is used to display "U19" on 7 Segment
///@brief This function is called when 19th command is given through UART
///@return None
///@param None
void U19_display(void)
{
  display.setSegments(SEG_U19);
}

///@brief This function is used to display "U20" on 7 Segment
///@brief This function is called when 20th command is given through UART
///@return None
///@param None
void U20_display(void)
{
  display.setSegments(SEG_U20);
}
