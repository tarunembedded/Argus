#ifndef _TM1637_H
#define _TM1637_H

  ///@brief Function prototypes
  
void init_7segment(void);
void all_segments_on(void);
void display_clear(void);
void t1_display(void);
void t2_display(void);
void t3_display(void);
void t4_display(void);
void t5_display(void);
void t6_display(void);
void t7_display(void);
void t8_display(void);
void t1_2_display(void);
void t1_3_display(void);
void t1_4_display(void);
void t1_5_display(void);
void t2_3_display(void);
void t3_4_display(void);
void t4_5_display(void);
void t5_6_display(void);
void t6_7_display(void);
void t7_8_display(void);
void t8_1_display(void);
void t2_4_display(void);
void t3_5_display(void);
void t5_7_display(void);



void b1_display(void);
void b2_display(void);
void b3_display(void);
void b4_display(void);
void b5_display(void);
void b6_display(void);
void b7_display(void);
void b8_display(void);
void b9_display(void);
void b10_display(void);
void b11_display(void);
void b12_display(void);
void b13_display(void);
void b14_display(void);
void b15_display(void);
void b16_display(void);
void b17_display(void);
void b18_display(void);
void b19_display(void);
void b20_display(void);

void U1_display(void);
void U2_display(void);
void U3_display(void);
void U4_display(void);
void U5_display(void);
void U6_display(void);
void U7_display(void);
void U8_display(void);
void U9_display(void);
void U10_display(void);
void U11_display(void);
void U12_display(void);
void U13_display(void);
void U14_display(void);
void U15_display(void);
void U16_display(void);
void U17_display(void);
void U18_display(void);
void U19_display(void);
void U20_display(void);


void A1_display(void);
void A2_display(void);
void A3_display(void);



#endif
