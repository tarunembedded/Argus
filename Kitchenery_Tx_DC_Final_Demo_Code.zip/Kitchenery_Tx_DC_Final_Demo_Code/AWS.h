#ifndef AWS_h
#define AWS_h


#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>


  ///@brief Below are the AWS credentials

#define THINGNAME "Esp32_IoT"                                       //change this

#define AWS_IOT_ENDPOINT "a10vg7hopzlmrs-ats.iot.us-west-2.amazonaws.com"       //change this

#define AWS_IOT_PUBLISH_TOPIC   "Esp32_IoT"
#define AWS_IOT_SUBSCRIBE_TOPIC "Esp32_IoT"

  ///@brief Function prototype

void connectAWS();
void wifi_aws_subscribe(void);


#endif
