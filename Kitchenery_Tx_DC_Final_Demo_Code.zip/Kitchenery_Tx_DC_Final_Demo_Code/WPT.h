#ifndef _WPT_h
#define _WPT_h



 ///@brief Function prototype

void Start_mc_pwm_signal(void);
void Stop_mc_pwm_signal(void);
#endif
