#ifndef _TS08N_H
#define _TS08N_H



  ///@brief Function prototypes
  \
void touch1(void);
void touch2(void);
void touch3(void);
void touch4(void);
void touch5(void);
void touch6(void);
void touch7(void);
void touch8(void);
void touch_init(void);

void port_configuration(void);
void Reset_for_TS08N_IC(void);
void input_port_init(void);
void led_outpput_ports_init(void);

void touch1_touch2(void);
void touch2_touch3(void);
void touch3_touch4(void);
void touch4_touch5(void);
void touch5_touch6(void);

void touch6_touch7(void);
void touch7_touch8(void);
void touch8_pressed(void);

void DB_send_aws_temp_data();
void HB_send_aws_temp_data();
void EXT_send_aws_temp_data();



#endif
