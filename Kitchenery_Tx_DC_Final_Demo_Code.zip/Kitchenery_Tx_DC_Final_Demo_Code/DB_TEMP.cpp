
  ///@brief  Project Name: Kitchenery
 ///@brief  Author Name: Argus Team 
  ///@brief  Task: Diode Bridge temperature sensor  
  ///@brief  Development Board:ESP WROOM 32

#include "DB_TEMP.h"



int DB_temp_sensorpin = 39;
float  DB_offset = .4;
float DB_reading;
extern char All__Sensor_Data_saved[];
char DB_temp_server_data[40];



  ///@brief This function read the ADC pin and converting bits to voltage and converting to temperature
  ///@brief This function is called when Diode bridge temp command is given through BLE,UART and touchpad 
  ///@return None
  ///@param None
void temp_sensor_reading_at_DB(void)
{

//  Sensor_falg=1;
   // Get the voltage reading from the LM35
  DB_reading = analogRead(DB_temp_sensorpin);
//  Serial.print("ADC Voltage  :");
//  Serial.print(DB_reading);
//  analogReadResolution(12);
 // if (reading <= 2350) {
    // Convert that reading into voltage
//      double voltage =  (3.3/ 4096.0) * (reading );
    double voltage =  (DB_reading/1000); //* (3.3/4095.0) ;
//    float voltage = DB_reading * (3.3 / 4095.0);
//    Serial.print(" Voltage  :");
//    Serial.print(voltage);
//    Serial.print("   :");
    // Convert the voltage into the temperature in Celsius
    float temperatureC = (voltage - DB_offset) / (0.0195);

    // print the temperature in Celsius
//    Serial.print("Temperature: ");
//    Serial.print(temperatureC);
//    Serial.print("\xC2\xB0"); // shows degree symbol
//    Serial.print("C  |  ");
    sprintf(All__Sensor_Data_saved,"DT:%.1f",temperatureC);
//    Serial.print("DT :");
    Serial.print(All__Sensor_Data_saved);
    Serial.print("  ");
//    // print the temperature in Fahrenheit
//    float temperatureF = (temperatureC * 9.0 / 3.3) + 32.0;
//    Serial.print(temperatureF);
//    Serial.print("\xC2\xB0"); // shows degree symbol
//    Serial.print("F");
  //}
  delay(1000); // wait a second between readings
}
