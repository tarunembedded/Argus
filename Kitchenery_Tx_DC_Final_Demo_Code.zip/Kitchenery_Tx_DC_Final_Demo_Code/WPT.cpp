#include "WPT.h"
#include "driver/mcpwm.h"
#include "soc/mcpwm_reg.h"
#include "soc/mcpwm_struct.h"
#include "wiring_private.h" // pinPeripheral() function
#include "relay.h"

//#define FREQ  24000
#define MOSFET 26     //pin to trigger the MOSFET (Output) pin26
static mcpwm_dev_t *mcpwm = &MCPWM0;
extern int freq;
///@brief This function generating the mc_pwm signal for wireless power with help of config strcture 
///@brief This function is called when WPT on command is given through BLE,UART and touchpad
///@return None
///@param None

void Start_mc_pwm_signal() {

  /*Initilization MCPWM GPIO pin*/
  mcpwm_gpio_init(MCPWM_UNIT_0, MCPWM0A, MOSFET);
  Serial.print("WPT FREQUENCY:");
  Serial.print(freq/1000);
  Serial.println("KHz");
  /*Scope of the MCPWM signal */
  mcpwm_config_t pwm_config;
  pwm_config.frequency = freq;                                   //frequency = 30KHz
  pwm_config.cmpr_a = 50;                                         //duty cycle of PWMxA = 50.0%
  pwm_config.counter_mode = MCPWM_UP_COUNTER;                     //MCPWM_UP_DOWN_COUNTER; // Up-down counter (triangle wave)
  pwm_config.duty_mode = MCPWM_DUTY_MODE_0;                       // Active HIGH
 
  mcpwm_init(MCPWM_UNIT_0, MCPWM_TIMER_0, &pwm_config);           //Configure PWM0A  with above settings
  mcpwm_start(MCPWM_UNIT_0, MCPWM_TIMER_0);
//  Serial.print (mcpwm->int_raw.val,BIN);
  mcpwm_sync_enable(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_SELECT_SYNC0, 0);
  MCPWM0.timer[0].sync.out_sel = 1;
  delayMicroseconds(1000);
  MCPWM0.timer[0].sync.out_sel = 0;
  mcpwm_set_duty(MCPWM_UNIT_0, MCPWM_TIMER_0, MCPWM_OPR_A, pwm_config.cmpr_a );
//   Serial.println("WPT starts ongoing :");
}
///@brief This function stop the generating the mc_pwm signal for wireless power with help of config strcture 
///@brief This function is called when WPT off command is given through BLE,UART and touchpad
///@return None
///@param None

void Stop_mc_pwm_signal(){
//   Serial.println("WPT stop :");

   mcpwm_stop(MCPWM_UNIT_0, MCPWM_TIMER_0);
   freq=60000;
//  Serial.print (mcpwm->int_raw.val,BIN);
  
  }
