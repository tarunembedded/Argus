
/*
    ///@brief  Project Name: Kitchenery
    ///@brief  Author Name: Argus Team
    ///@brief  Task: Touch Pad
    ///@brief  Development Board:ESP WROOM D32

*/
#define ENABLE_DEBUG

#ifdef ENABLE_DEBUG
#define DEBUG_ESP_PORT Serial
#define NODEBUG_WEBSOCKETS
#define NDEBUG
#endif

#include <Wire.h>
#include "TS08N.h"
#include "relay.h"
#include "DB_TEMP.h"
#include "HB_TEMP.h"
#include "DB_current_sensor.h"
#include "HB_current_sensor.h"
#include "ds3231_rtc.h"
#include <Arduino.h>
#include <TM1637Display.h>
#include "TM1637.h"
#include "WPT.h"


int data_IN = 0;
int MAX7300_Address = 64;    // MAX7300 A0=0 A1=0 A2=0 A3=0
extern uint8_t commands_flag;

uint8_t touch_DB_current_flag = 0;
uint8_t touch_HB_current_flag = 0;

uint8_t touch_DB_temp_flag = 0;
uint8_t touch_HB_temp_flag = 0;
uint8_t touch_ext_temp_flag = 0;

uint8_t touch1_flag = 0;
uint8_t touch2_flag = 0;
uint8_t touch3_flag = 0;
uint8_t touch4_flag = 0;
uint8_t touch5_flag = 0;
uint8_t touch6_flag = 0;
uint8_t touch7_flag = 0;
uint8_t touch8_flag = 0;

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop functionThis will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None

void touch1(void)
{
  //commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x35));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port
  if (1 == Wire.available()) { //if data read
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch1_flag = 1;
      touch_DB_current_flag = 1;
//      Serial.println("TOUCH 1 ");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x28));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x28));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will  ON and OFF the LED
///@return None
///@param None
void touch2(void)
{
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x36));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port

  while (Wire.available()) { //if data read
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch2_flag = 1;
      touch_HB_current_flag = 1;
//      Serial.println("TOUCH 2 ");

      //Serial.print("TOUCH 2 HIGH");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2C));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
//      Serial.print("TOUCH 2 LOW");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2C));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch3(void)
{
  //commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x37));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port

  if (1 == Wire.available()) { //if data readd
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch3_flag = 1;
      touch_DB_temp_flag = 1;
//      Serial.println("TOUCH 3 ");

      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0X29));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x29));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch4(void)
{
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x38));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port
  while (Wire.available()) { //if data read
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch4_flag = 1;
//      Serial.println("TOUCH 4 ");
      touch_HB_temp_flag = 1;
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2D));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2D));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch5(void)
{
  // commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x39));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port

  if (1 == Wire.available()) { //if data read
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch5_flag = 1;
//      Serial.println("TOUCH 5 ");
      touch_ext_temp_flag = 1;
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2A));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x2A));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}


///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch7(void)
{
  // commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x34));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port

  if (1 == Wire.available()) { //if data readd
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch7_flag = 1;
//      Serial.println("TOUCH 7");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x25));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x25));
      Wire.write(byte(0x00));
      Wire.endTransmission();

    }
  }
}
///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch6(void)
{
  //commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x33));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port

  if (1 == Wire.available()) { //if data read
    data_IN = Wire.read(); //write to int
    if (data_IN == 0) {
      touch6_flag = 1;
//      Serial.println("TOUCH 6 ");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x3D));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x3D));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief Read the respective Gpio pin through I2c
///@brief This function should be called In the loop function This will read the GPIO,Based on gpio status we will ON and OFF the LED
///@return None
///@param None
void touch8(void)
{
  //commands_flag=3;
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x3A));
  Wire.write(byte(0x00));
  Wire.endTransmission();
  uint8_t int1 = Wire.requestFrom(MAX7300_Address, 1); //read port
  if (1 == Wire.available()) { //if data readd
    data_IN = Wire.read(); //write to int
    //    Serial.print("wire read:");
    //    Serial.print(data_IN);
    if (data_IN == 0) {
      touch8_flag = 1;
//      Serial.println("TOUCH 8 ");
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x24));
      Wire.write(byte(0x01));
      Wire.endTransmission();
    }
    if (data_IN != 0) {
      Wire.beginTransmission(MAX7300_Address);
      Wire.write(byte(0x24));
      Wire.write(byte(0x00));
      Wire.endTransmission();
    }
  }
}

///@brief This is for configuration of ports
///@brief This function should be called only once Before any other ports are called
///@return None
///@param None
void port_configuration(void)
{
  //___________________________________________________ Addres to Port Configuration  ____________

  Wire.beginTransmission (MAX7300_Address);  //max7300 address
  Wire.write (byte(0x04));   //configuration port
  Wire.write (byte(0x01));    // set shutdown mode off
  Wire.endTransmission();   // close comm
}


///@brief initilize GPIO pin as Output Mode
///@brief This function should be called only once Before any other output ports are called
///@return None
///@param None
void led_outpput_ports_init(void)
{
  //_________________________________________________ Port Configuration Enable   ____________________

  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x09));   //Port Configuration for P7, P6, P5, P4
  Wire.write (byte(0x55));   //Output
  Wire.endTransmission();  // close comm

  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x0A));   //Port Configuration for P11, P10, P9, P8
  Wire.write (byte(0x55));   //Output
  Wire.endTransmission();  // close comm

  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x0B));   //Port Configuration for P15, P14, P13, P12
  Wire.write (byte(0x55));   //Output
  Wire.endTransmission();  // close comm

  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x0F));   //Port Configuration for P31, P30, P29, P28
  Wire.write (byte(0x55));  //Output
  Wire.endTransmission();  // close com

}

///@brief initilize GPIO pin as Input MOde
///@brief This function should be called only once Before any other input ports are called
///@return None
///@param None
void input_port_init(void)
{
  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x0D));   //Port Configuration for P23, P22, P21, P20
  Wire.write (byte(0xAA));   //set to schmitt trigger in with pullup r
  Wire.endTransmission();  // close comm

  Wire.beginTransmission (MAX7300_Address);   //max7300 address
  Wire.write (byte(0x0E));   //Port Configuration for P27, P26, P25, P24
  Wire.write (byte(0xAA));   //set to schmitt trigger in with pullup r
  Wire.endTransmission();  // close comm

}

///@brief initilize Reset Gpio pin
///@brief This function should be called Whenever we required reset we need to call this function
///@return None
///@param None
void Reset_for_TS08N_IC(void)
{
  delay(2000);
  delay(250);
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x2E));
  Wire.write(byte(0x01));
  Wire.endTransmission();
  delay(250);
  Wire.beginTransmission(MAX7300_Address);
  Wire.write(byte(0x2E));
  Wire.write(byte(0x00));
  Wire.endTransmission();
}
///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief    touch1 -- DB current sensor reading
///@brief    touch1 & touch2 -- 12v relay off
///@brief  touch1 & touch3 -- half bridge relay on
///@brief   touch1 & touch4 -- half bridge relay off
///@brief   touch1 & touch5 -- Read RTC data
///@return None
///@param None
void touch1_touch2(void)
{
  touch1();
  touch2();
  touch3();
  touch4();
  touch5();
  if (touch1_flag == 1)
  {
    touch1_flag = 0;
    if (touch2_flag == 1)
    {

      touch2_flag = 0;
            Serial.println("TOUCH 1 AND 2 ");
      t1_2_display();
      Serial.print("volt12_relay_off\r\n");
      volt12_relay_off();
      delay(1000);
      display_clear();

    }
    else if (touch3_flag == 1)
    {
      touch3_flag = 0;
      Serial.println("TOUCH 1 AND 3 ");
      t1_3_display();
      Serial.print("half bridge relay on\r\n");
      half_bridge_relay_on();
      delay(1000);
      display_clear();
    }
    else if (touch4_flag == 1)
    {
      touch4_flag = 0;
      Serial.println("TOUCH 1 AND 4 ");
      t1_4_display();
      Serial.print("half bridge relay off\r\n");
      half_bridge_relay_off();
      delay(1000);
      display_clear();
    }

    else if (touch5_flag == 1)
    {
      touch5_flag = 0;
      Serial.println("TOUCH 1 AND 5 ");
      t1_5_display();
      Serial.print("RTC TIME\r\n");
      RTC_ON();
      delay(1000);
      display_clear();
    }
    else  {
      t1_display();
      Serial.println("TOUCH 1");
      delay(1000);
      display_clear();
      Serial.print("Diode Bridge Current \r\n");
      DB_send_aws_current_data();
    }

  }
}

///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief     touch2 -- HB current sensor reading
///@brief      touch2 & touch3 -- power relay on
///@brief      touch2 & touch4 -- power relay off
///@return None
///@param None

void touch2_touch3(void)
{
  touch2();
  touch3();
  touch4();
  if (touch2_flag == 1)
  {
    touch2_flag = 0;
    if (touch3_flag == 1)
    {
      touch3_flag = 0;
      Serial.println("TOUCH 2 AND 3 ");
      t2_3_display();
      Serial.print("fan1 relay on\r\n");
      k1_power_relay_on();
      delay(1000);
      display_clear();

    }
    else if (touch4_flag == 1)
    {
      t2_4_display();
            Serial.println("TOUCH 2 AND 4 ");
      touch4_flag = 0;
      Serial.print("fan1 relay off\r\n");
      k1_power_relay_off();
      delay(1000);
      display_clear();
    }
    else  {
      t2_display();
      Serial.println("TOUCH 2");
      delay(1000);
      display_clear();
      Serial.print("Half Bridge Current \r\n");
      HB_send_aws_current_data();

    }

  }
}

///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief   touch3 -- DB Temperature sensor reading
///@brief   touch3 & touch4 -- IND on
///@brief   touch3 & touch5 -- IND off
///@return None
///@param None
void touch3_touch4(void)
{
  touch3();
  touch4();
  touch5();

  if (touch3_flag == 1)
  {
    touch3_flag = 0;
    if (touch4_flag == 1)
    {
      touch4_flag = 0;
      Serial.println("TOUCH 3 AND 4 ");
      t3_4_display();
       Start_mc_pwm_signal();
      Serial.print("IND ON\r\n");
      delay(1000);
      display_clear();

    }
    else if (touch5_flag == 1)
    {
      t3_5_display();
      Serial.println("TOUCH 3 AND 5 ");
      touch5_flag = 0;
      Stop_mc_pwm_signal();
      Serial.print("IND OFF\r\n");
      delay(1000);
      display_clear();
    }
    else  {
      t3_display();
      Serial.println("TOUCH 3");
      delay(1000);
      display_clear();
      Serial.print("Diode Bridge Temp\r\n");
      DB_send_aws_temp_data();

    }

  }
}
///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief      touch4 -- HB Temperature sensor reading
///@brief      touch4 & touch5 -- WPT on
///@return None
///@param None
void touch4_touch5(void)
{
  touch4();
  touch5();

  if (touch4_flag == 1)
  {
    touch4_flag = 0;
    if (touch5_flag == 1)
    {
      touch5_flag = 0;
      Serial.println("TOUCH 4 AND 5 ");
      t4_5_display();
      Serial.print("WPT ON\r\n");
      Start_mc_pwm_signal();

      delay(1000);
      display_clear();

    }
    else  {
      t4_display();
      Serial.println("TOUCH 4");
      delay(1000);
      display_clear();
      Serial.print("Half Bridge Temp ON\r\n");
      HB_send_aws_temp_data();

    }

  }
}
///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief         touch5 -- EXT Temperature sensor reading
///@brief         touch5 & touch6 -- WPT off
///@return None
///@param None
void touch5_touch6(void)
{
  touch5();
  touch6();
  if (touch5_flag == 1)
  {
    touch5_flag = 0;
    if (touch6_flag == 1)
    {
      touch6_flag = 0;
      Serial.println("TOUCH 5 AND 6 ");
      t5_6_display();
      Serial.println("WPT OFF");
     Stop_mc_pwm_signal();

      delay(1000);
      display_clear();


    }
    else  {
      t5_display();
Serial.println("TOUCH 5");
      delay(1000);
      display_clear();
      Serial.print("PT100 temp\r\n");
      EXT_send_aws_temp_data();

    }

  }
}
///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief          touch6 -- power relay on
///@brief          touch6 & touch7 -- fan2 relay on
///@return None
///@param None
void touch6_touch7(void)
{
  touch6();
  touch7();
  if (touch6_flag == 1)
  {
    touch6_flag = 0;
    if (touch7_flag == 1)
    {
      touch7_flag = 0;
      Serial.println("TOUCH 6 AND 7 ");
      t6_7_display();
      Serial.print("fan2 relay on\r\n");
      volt12_relay_on();
      //fan2_relay_on();
      delay(1000);
      display_clear();

    }
    else  {
      t6_display();
      Serial.println("TOUCH 6");
      Serial.print("K1 Power Relay on\r\n");
      k1_power_relay_on();
      delay(1000);
      display_clear();

    }
  }
}

///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief         touch7 -- power relay off
///@brief          touch7 & touch8 -- fan2 relay off
///@return None
///@param None
void touch7_touch8(void)
{
  touch7();
  touch8();
  if (touch7_flag == 1)
  {
    touch7_flag = 0;
    if (touch8_flag == 1)
    {
      touch8_flag = 0;
      Serial.println("TOUCH 7 AND 8 ");
      t7_8_display();
      Serial.print("fan2 relay off\r\n");
      volt12_relay_off();
      //fan2_relay_off();
      delay(1000);
      display_clear();

    }
    else  {
      t7_display();
      Serial.println("TOUCH 7");
      Serial.print("K1 Power Relay off\r\n");
      k1_power_relay_off();
      delay(1000);
      display_clear();
    }

  }
}

///@brief Based on the touch flag we will do respective action
///@brief This function should be called In the loop function
///@brief         touch8 -- 12v relay on
///@return None
///@param None
void touch8_pressed(void)
{
  touch8();
  if (touch8_flag == 1)
  {
    touch8_flag = 0;
    Serial.println("TOUCH 8");
    t8_display();
    Serial.print("volt12_relay_on\r\n");
    volt12_relay_on();
    delay(1000);
    display_clear();
  }
}

///@brief Initialize the touch pad
///@brief This function should be called In the SETUPs function
///@brief       If not initialize the touchpad it will print ERROR-6
///@return None
///@param None
void touch_init(void)
{
  Wire.beginTransmission(MAX7300_Address);
  if (Wire.endTransmission() != 0)
  {
    Serial.println("ERROR 6");
  }
  else {
    Serial.println("TOUCH PAD INITIALIZED");
  }

}
