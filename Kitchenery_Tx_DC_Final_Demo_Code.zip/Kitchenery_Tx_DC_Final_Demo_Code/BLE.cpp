
///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: UART Commands from BLE ESP32 and debug UART
///@brief  Development Board:ESP WROOM 32

#include <SoftwareSerial.h>
//#include "string.h"
#include "BLE.h"
#include "TTP229.h"
#include "aws.h"
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "DB_current_sensor.h"
#include "HB_current_sensor.h"
#include "device_debug_handler.h"
#include "DB_TEMP.h"
#include "HB_TEMP.h"
#include "relay.h"
#include "ds3231_rtc.h"
#include "TM1637.h"
#include "flash.h"
#include "WPT.h"
#include "device_debug_handler.h"
#include "eeprom_param_handler.h"
#include "device_eeprom_handler.h"
#include "device_getchipid_handler.h"

extern char current_data[8];
extern WiFiClientSecure net; // = WiFiClientSecure();
extern PubSubClient client;

String inputString = "";         // a String to hold incoming data
bool stringComplete = false;  // whether the string is complete

String debuginputString = "";         // a String to hold incoming data
bool debugstringComplete = false;  // whether the string is complete

char sample_buff[18] = "$BLE,GET,CURR,01";
char sample_buff1[18] = "$BLE,GET,TEMP,01";
char sample_buff2[19] = "$BLE,SET,PR,01";
char sample_buff3[19] = "$BLE,SET,PR,00";
uint8_t parse_buff[50];
uint8_t debug_parse_buff[50];
char *rest = NULL;
char *debugrest = NULL;

char *parsing = NULL;
char *debugparsing = NULL;
uint8_t BLE_command_flag = 0;
String rx_data_receving = "";
extern uint8_t current_sensor_flag ;
extern uint8_t server_send_data;

extern uint8_t touch_relay_flag;
extern uint8_t touch_wpt_flag;

uint8_t device_select = 0;
uint8_t device_select1 = 0;
uint8_t device_select2 = 0;
bool  device_select3 = 0;
uint8_t ble_ext_temp_flag = 0;
uint8_t ble_DB_temp_flag = 0;
uint8_t ble_HB_temp_flag = 0;
uint8_t ble_HB_current_flag = 0;
uint8_t ble_DB_current_flag = 0;
//uint8_t ble_k1_power_relay_flag = 0;
//uint8_t ble_volt12_relay_flag = 0;
//uint8_t ble_half_bridge_relay_flag = 0;
//uint8_t ble_fan1_relay_flag = 0;
//uint8_t ble_fan2_relay_flag = 0;
uint8_t Rx_Sensor_flag =0;
uint8_t uart_ext_temp_flag = 0;
uint8_t uart_DB_temp_flag = 0;
uint8_t uart_HB_temp_flag = 0;
uint8_t uart_HB_current_flag = 0;
uint8_t uart_DB_current_flag = 0;
bool Ble_Connection_flag = 0;
extern char All__Sensor_Data_saved[];
char Rx_data[15];
uint8_t datasend_flag = 0;
volatile uint8_t debug_command_flag = 0;

char Power_relay[50];
int freq1;
//int freq=25000;
int freq=60000;

//WiFiClientSecure net = WiFiClientSecure();
//PubSubClient client(net);
///@brief This function is used to send the AT commands to BLE ESP32
///@brief This function should called for sending AT commands to BLE ESP32 module
///@return None
///@param char* msg
void issueCommand(char* msg)
{
  Serial2.println(msg);
  Serial.println(msg);

}

///@brief This function is used to GET event on serial2
///@brief This function should called at whenever we want  data on the serial2
///@return None
///@param None

void serialEvent() {
  if (Serial2.available()) {
    while (Serial2.available()) {
      // get the new byte:
      char inChar = Serial2.read();

      // add it to the inputString:
      inputString += inChar;
      //      Serial.print("rx  data:");
      //      Serial2.print("RX  data:");
      //      Serial2.print(inputString);
      // if the incoming character is a newline, set a flag so the main loop can
      // do something about it:
      if (inChar == '\n') {
        stringComplete = true;
      }
    }
  }
}



///@brief This function is used to GET event on debugserial
///@brief This function should called at whenever we want data on the debugserial
///@return None
///@param None
void serialdebugEvent(void) {
  if (Serial.available()) {
    while (Serial.available()) {
      // get the new byte:
      char inChar1 = Serial.read();
      // add it to the inputString:
      debuginputString += inChar1;

      // if the incoming character is a newline, set a flag so the main loop can
      // do something about it:
      if (inChar1 == '\n') {
        debugstringComplete = true;
      }
    }
  }
}


///@brief This function is used to read the command on debugserial and parsing the command and do respective action
///@brief This function should called in the while loop
///@return None
///@param None
void debug_reading_data(void)
{
  serialdebugEvent();
  memcpy(debug_parse_buff, debuginputString.c_str(), 50);
  debugparsing = (char *)debug_parse_buff;
  if (debugstringComplete)
  {
    //    Serial.print(debugparsing);
    debugrest = strtok(debugparsing, ",");
    if (!strncmp("$UART", debugrest, 5))
    {
      debugrest = strtok(NULL, ",");
      if (!strncmp("SET", debugrest, 3))
      {
        debugrest = strtok(NULL, ",");
        if (!strncmp("IND", debugrest, 3))
        {
          debugrest = strtok(NULL, ",");
          if (!strncmp("01", debugrest, 2))
          {
            U1_display();
             Start_mc_pwm_signal();
            Serial.println("debug IND ON");
            delay(2000);
          }
          else if (!strncmp("00", debugrest, 2))
          {
            U2_display();
             Stop_mc_pwm_signal();
            Serial.println("debug IND OFF");
            delay(2000);
          }
        }
        else if (!strncmp("WPT", debugrest, 3))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U3_display();
            Start_mc_pwm_signal();
            Serial.println("WPT ON");
            delay(2000);
          }
          else
          {
            U4_display();
            Stop_mc_pwm_signal();
            Serial.println("WPT OFF");
            delay(2000);
          }
        }
        else if (!strncmp("PRELAY", debugrest, 6))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U5_display();
            Serial.println("POWER RELAY ON");
            k1_power_relay_on();
            delay(2000);
          }
          else
          {
            U6_display();
            k1_power_relay_off();
            Serial.println("POWER RELAY OFF");
            delay(2000);
          }
        }

        else if (!strncmp("12VRELAY", debugrest, 11))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U7_display();
            volt12_relay_on();
            Serial.println("12VRELAY ON");
            delay(2000);
          }
          else
          {
            U8_display();
            volt12_relay_off();
            Serial.println("12VRELAY OFF");
            delay(2000);
          }
        }

        else if (!strncmp("HBRELAY", debugrest, 7))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U9_display();
            half_bridge_relay_on();
            Serial.println("HBRELAY ON");
            delay(2000);
          }
          else
          {
            U10_display();
            half_bridge_relay_off();
            Serial.println("HBRELAY OFF");
            delay(2000);
          }
        }

        else if (!strncmp("FAN1", debugrest, 4))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U11_display();
            Serial.println("FAN1 ON");
            fan1_relay_on();
            delay(2000);
          }
          else
          {
            U12_display();
            fan1_relay_off();
            Serial.println("FAN1 OFF");
            delay(2000);
          }
        }

        else if (!strncmp("FAN2", debugrest, 4))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U13_display();
            fan2_relay_on();
            Serial.println("FAN2 ON");
            delay(2000);

          }
          else
          {
            U14_display();
            fan2_relay_off();
            Serial.println("FAN2 OFF");
            delay(2000);
          }
        }
         else if (!strncmp("DCFQ", debugrest, 4))
        {
          debugrest = strtok(NULL, "\n");
          
         freq1=atoi(debugrest);
         if(freq1<=20000 && freq1>= 17000){
          
          freq=freq1;
          }
          else {
            Serial.println("Enter valid DC frequency");
            }
        }


//____________________________

else if (!strncmp("ACFQ", debugrest, 4))
        {
          debugrest = strtok(NULL, "\n");
           
         freq1=atoi(debugrest);

         if(freq1<=60000 && freq1>= 24000){
             freq=freq1;
          }
          else {
            Serial.println("Enter valid AC frequency");
            }
        }

//_____________
//          if (!strncmp("01", debugrest, 2))
//          {
//          freq1=60000;
//          
//          Serial.print("Freq  :");
//          Serial.println(freq1);
//            delay(2000);
//
//          }
//          else if(!strncmp("02", debugrest, 2))
//          {
//          freq1=50000;
//          
//          Serial.print("Freq  :");
//          Serial.println(freq1);
//            delay(2000);
//
//          } 
//            else if(!strncmp("03", debugrest, 2))
//          {
//          freq1=40000;
//          
//          Serial.print("Freq  :");
//          Serial.println(freq1);
//            delay(2000);
//
//          } 
//           else if(!strncmp("04", debugrest, 2))
//          {
//          freq1=30000;
//          
//          Serial.print("Freq  :");
//          Serial.println(freq1);
//            delay(2000);
//
//          } 
//      }

      else if (!strncmp("WAPMODE", debugrest, 6))
      {
        
          debugrest = strtok(NULL, "\n");
            if (!strncmp("01", debugrest, 2))
            {
//          Serial.println(debugrest);
Serial.println("Wi-Fi AP-MODE ACTIVATED");
          Eeprom_Clear();

            }
 
      }
      }
      if (!strncmp("GET", debugrest, 3))
      {
        debugrest = strtok(NULL, ",");
        if (!strncmp("CURR", debugrest, 4))
        {
          debugrest = strtok(NULL, "\n");
          if (!strncmp("01", debugrest, 2))
          {
            U15_display();
                        
            uart_DB_current_flag = 1;
            Serial.println("DIODE Bridge CURRE ON");
            delay(2000);

          }
          else if (!strncmp("02", debugrest, 2))
          {
            U16_display();
            uart_HB_current_flag = 1;
            Serial.println("HALF Bridge CURRE ON");
            delay(2000);

          }
        }
        else if (!strncmp("TEMP", debugrest, 4))
        {
          debugrest = strtok(NULL, ",");
          if (!strncmp("01", debugrest, 2))
          {
            U17_display();
            uart_DB_temp_flag = 1;
            Serial.println("DIODE TEMP ON");
            delay(2000);

          }
          else if (!strncmp("02", debugrest, 2))
          {
            U18_display();
            uart_HB_temp_flag = 1;
            Serial.println("HALF BRIDGE TEMP ON");
            delay(2000);

          }
          else if (!strncmp("03", debugrest, 2))
          {
            U19_display();
            uart_ext_temp_flag = 1;
            Serial.println("EXTERNAL TEMP ON");
            delay(2000);

          }
        }
        else if (!strncmp("TIME", debugrest, 4))
        {
          debugrest = strtok(NULL, ",");
          if (!strncmp("01", debugrest, 2))
          {
            U20_display();
            Serial.println("RTC TIME ON");
            RTC_ON();

            delay(2000);

          }
        }


      }

    }
    display_clear();
    debuginputString = "";
    debugstringComplete = false;
  }
}

///@brief This function is used to read the command on serial2 and parsing the command and do respective action
///@brief This function should called in the while loop
///@return None
///@param None
void reading_data()
{
  serialEvent();
  memcpy(parse_buff, inputString.c_str(), 50);
  parsing = (char *)parse_buff;
  // print the string when a newline arrives:
  if (stringComplete) {
        Serial.print(parsing);
    rest = strtok(parsing, ":");
    if (!strncmp("+WRITE", rest, 6))
    {
      rest = strtok(NULL, ",");
      rest = strtok(NULL, ",");;
      rest = strtok(NULL, ",");
      rest = strtok(NULL, ",");
      rest = strtok(NULL, ",");
      if (!strncmp("$BLE", rest, 4))
      {
        rest = strtok(NULL, ",");
        if (!strncmp("SET", rest, 3))
        {
          rest = strtok(NULL, ",");
          if (!strncmp("IND", rest, 3))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b1_display();
              Start_mc_pwm_signal();
              Serial.println("IND ON");
              delay(2000);
            }
            else if (!strncmp("00", rest, 2))
            {
              b2_display();
              Stop_mc_pwm_signal();
              Serial.println("IND OFF");
              delay(2000);

            }
          }
          else if (!strncmp("WPT", rest, 3))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b3_display();
              Start_mc_pwm_signal();
              Serial.println("WPT ON");
              delay(2000);

            }
            else
            {
              b4_display();
              Stop_mc_pwm_signal();
              Serial.println("WPT OFF");
              delay(2000);
            }
          }
          else if (!strncmp("PRELAY", rest, 6))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b5_display();
              k1_power_relay_on();
              Serial.println("POWER RELAY ON");
              delay(2000);
            }
            else
            {
              b6_display();
              k1_power_relay_off();
              Serial.println("POWER RELAY OFF");
              delay(2000);
            }
          }

          else if (!strncmp("12VRELAY", rest, 11))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b7_display();
              volt12_relay_on();
              Serial.println("12VRELAY ON");
              delay(2000);
            }
            else
            {
              b8_display();
              volt12_relay_off();
              Serial.println("12VRELAY OFF");
              delay(2000);
            }
          }

          else if (!strncmp("HBRELAY", rest, 7))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b9_display();
              half_bridge_relay_on();
              Serial.println("HBRELAY ON");
              delay(2000);
            }
            else
            {
              b10_display();
              half_bridge_relay_off();
              Serial.println("HBRELAY OFF");
              delay(2000);
            }
          }

          else if (!strncmp("FAN1", rest, 4))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b11_display();
              fan1_relay_on();
              Serial.println("FAN1 ON");
              delay(2000);

            }
            else
            {
              b12_display();
              fan1_relay_off();
              Serial.println("FAN1 OFF");
              delay(2000);
            }
          }

          else if (!strncmp("FAN2", rest, 4))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b13_display();
              fan2_relay_on();
              Serial.println("FAN2 ON");
              delay(2000);

            }
            else
            {
              b14_display();
              fan2_relay_off();
              Serial.println("FAN2 OFF");
              delay(2000);
            }
          }

          
      else if (!strncmp("WAPMODE", rest, 6))
      {
        
          rest = strtok(NULL, "\n");
             if (!strncmp("01", rest, 2))
            {
              Serial.println("Wi-Fi AP-MODE ACTIVATED");
              delay(200);
//          Serial.println(debugrest);
          Eeprom_Clear();
              delay(200);

            }
        
      }

      //____________________________________________

      else if (!strncmp("AWS", rest, 3))
      {
        
          rest = strtok(NULL, "\n");
             if (!strncmp("01", rest, 2))
            {
              char AWS[20]="Wi-Fi is available";
              client.publish(AWS_IOT_PUBLISH_TOPIC, AWS);

              delay(200);

            }
        
      }

      //___________________________________
      //______________________

 else if (!strncmp("DCFQ", rest, 4))
        {
          rest = strtok(NULL, "\n");
            
         freq1=atoi(rest);

         if(freq1<=20000 && freq1>= 17000){
          
          freq=freq1;
          
         Serial.print("Enter DC frequency:");
         Serial.println(freq);
          }
          else {
            Serial.println("Enter valid DC frequency");
            }
        }


//____________________________

else if (!strncmp("ACFQ", rest, 4))
        {
          rest = strtok(NULL, "\n");
         freq1=atoi(rest);
         if(freq1<=60000 && freq1>= 24000){
          freq=freq1;

          }
          else {
            Serial.println("Enter valid AC frequency");
            }
        }
      //_____________________
        }
        if (!strncmp("GET", rest, 3))
        {
          rest = strtok(NULL, ",");
          if (!strncmp("CURR", rest, 4))
          {
            rest = strtok(NULL, "\n");
            if (!strncmp("01", rest, 2))
            {
              b15_display();
              ble_DB_current_flag = 1;
              Serial.println("DIODE Bridge CURRE ON");
              delay(2000);
            }
            else if (!strncmp("02", rest, 2))
            {
              b16_display();
              ble_HB_current_flag = 1;
              Serial.println("HALF Bridge CURRE ON");
              delay(2000);
            }
          }
          else if (!strncmp("TEMP", rest, 4))
          {
            rest = strtok(NULL, ",");
            if (!strncmp("01", rest, 2))
            {
              b17_display();
              ble_DB_temp_flag = 1;
              Serial.println("DIODE TEMP ON");
              delay(2000);

            }
            else if (!strncmp("02", rest, 2))
            {
              b18_display();
              ble_HB_temp_flag = 1;
              Serial.println("HALF BRIDGE TEMP ON");
              delay(2000);

            }
            else if (!strncmp("03", rest, 2))
            {
              b19_display();
              ble_ext_temp_flag = 1;
              Serial.println("EXTERNAL TEMP ON");
              delay(2000);
            }
          }
          else if (!strncmp("TIME", rest, 4))
          {
            rest = strtok(NULL, ",");
            if (!strncmp("01", rest, 2))
            {
              b20_display();
              Serial.println("RTC TIME ON");
              RTC_ON();

              delay(2000);


            }
          }
        }
        

      }
else if(!strncmp("BLE", rest,3)){
//  Serial.println("Rajendra");
  Rx_Sensor_flag = 1;
  
  }
      else {

        memcpy(All__Sensor_Data_saved, rest, 15);
       connectAWS();
        if (client.publish(AWS_IOT_PUBLISH_TOPIC, All__Sensor_Data_saved) &&  WiFi.status() == WL_CONNECTED)
        {
          DEBUG_TEST_SERIAL.println("BLE  AWS_IOT_PUBLISH : SUCCESS");
          Serial.println(" ");
        }
        else
        {
          DEBUG_TEST_SERIAL.println("BLE  AWS_IOT_PUBLISH : FAILED");
          SPI_FLASH_WRITE_ALL_Sensor_Data();

        }
        memset(All__Sensor_Data_saved, '\0', strlen(All__Sensor_Data_saved));

      }
    }
    else if (!strncmp("+BLEDISCONN", rest, 11))
    {
      Ble_Connection_flag = 0;
      Serial.println("BLE Disconnected");
      Rx_Sensor_flag = 0;
      //send_AT_BLEADVSTART();

    }
  else if(!strncmp("+BLECONN", rest, 8))
    {
      device_select = 1;
      if(!strncmp("+BLECONNPARAM", rest, 13))
      {
        device_select1 = 1;
        if((device_select == 1) && (device_select1 == 1))
        { 
          device_select = 0;
          device_select1 = 0;
          Serial.println("mobile connected"); 
        }

      }
         else if(device_select == 1)
      {
          device_select3=1;
       }
 
   }
        else if((device_select == 1) && (device_select3 == 1))
      {
        device_select = 0;
        device_select3=0;
        Ble_Connection_flag = 1;
        Serial.println("RX connected");
      }
    
    display_clear();
    inputString = "";
    stringComplete = false;
  }
  
  delay(300);
  *rest = NULL;
}


///@brief This function is AT command sent to BLE ESP32  based on the response send the next command
///@brief This function should called in the setup function
///@return None
///@param None

///@brief This function is AT command sent to BLE ESP32  based on the response send the next command
///@brief This function should called in the setup function
///@return None
///@param None
void send_AT()
{
  Serial.println(" ");
  issueCommand("AT");
  //reading_data();
  delay(10);
  if (Serial2.find("OK"))
  {
    delay(2000);
    send_AT_BLEINIT();
  }
  else
  {
    delay(2000);
    send_AT();
  }

}


///@brief This function is for initializing the BLE based on the response send the next command
///@brief This function should called in the send_AT function
///@return None
///@param None
void send_AT_BLEINIT()
{
  issueCommand("AT+BLEINIT=2");
  delay(10);
  if (Serial2.find("OK"))
  {
    delay(2000);
    send_AT_BLEGATTSSRVCRE();
  }
  else
  {
    delay(2000);
    send_AT_BLEINIT();
  }

}


///@brief This function is for create the services based on the response send the next command
///@brief This function should called in the send_AT_BLEINIT function
///@return None
///@param None
void send_AT_BLEGATTSSRVCRE()
{
  issueCommand("AT+BLEGATTSSRVCRE");
  //reading_data();
  delay(10);
  if (Serial2.find("OK"))
  {
    delay(2000);
    send_AT_BLEGATTSSRVSTART();
  }
  else
  {
    delay(2000);
    send_AT_BLEGATTSSRVCRE();
  }

}


///@brief This function is for start the services  based on the response send the next command
///@brief This function should called in the send_AT_BLEGATTSSRVCRE function
///@return None
///@param None
void send_AT_BLEGATTSSRVSTART()
{
  issueCommand("AT+BLEGATTSSRVSTART");
  delay(10);
  if (Serial2.find("OK"))
  {
    delay(2000);
    send_AT_BLEADVDATA();
  }
  else
  {
    delay(2000);
    send_AT_BLEGATTSSRVSTART();
  }

}


///@brief This function is for configure advertisement data based on the response send the next command
///@brief This function should called in the send_AT_BLEGATTSSRVSTART function
///@return None
///@param None
void send_AT_BLEADVDATA()
{
  issueCommand("AT+BLEADVDATA=\"0201060A09457370726573736966030302A0\"");
  delay(10);
  if (Serial2.find("OK"))
  {
    delay(2000);
    send_AT_BLEADVSTART();
  }
  else
  {
    delay(2000);
    send_AT_BLEADVDATA();
  }

}


///@brief This function is for Start advertising based on the response send the next command
///@brief This function should called in the send_AT_BLEADVDATA function
///@return None
///@param None
void send_AT_BLEADVSTART()
{
  Serial.println(" ");
  issueCommand("AT+BLEADVSTART");
  //reading_data();
  delay(10);
  if (Serial2.find("OK"))
  {

  }
  else
  {
    delay(2000);
    send_AT_BLEADVSTART();
  }

}


///@brief This function is for notification based on the response send the next command
///@brief This function should called in the loop function
///@return None
///@param None
void send_AT_BLEGATTSNTFY()
{
  issueCommand("AT+BLEGATTSNTFY=0,1,6,16");
  //delay(10);
  if (Serial2.find('>'))
  {
    Serial2.println(sample_buff);
  }
}


///@brief This function is for notification for temperature based on the response send the next command
///@brief This function should called in the loop function
///@return None
///@param None
void send_AT_BLEGATTSNTFY_For_Temp()
{
  issueCommand("AT+BLEGATTSNTFY=0,1,6,16");
  if (Serial2.find('>'))
  {
    Serial2.println(sample_buff1);
  }
}
void send_AT_BLEGATTSNTFY_For_Power_On()
{
  issueCommand("AT+BLEGATTSNTFY=0,1,6,16");
  if (Serial2.find('>'))
  {
    Serial2.println(sample_buff2);
  }
}

void send_AT_BLEGATTSNTFY_For_Power_Off()
{
  issueCommand("AT+BLEGATTSNTFY=0,1,6,16");
  if (Serial2.find('>'))
  {
    Serial2.println(sample_buff3);
  }
}
