#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include "eeprom_param_handler.h"
#include "wifi_credentials_handler.h"
#include "device_debug_handler.h"
volatile wifiData_timer_t wifiData_timer;
//Variables
int i = 0, n;
int statusCode;
char ssid[32], passphrase[32];
String st;
String content;
String esid;
String epass = "";
//Function Decalration
void WiFi_Init(void);
void launchWeb(void);
void setupAP(void);
void createWebServer(void);
void Create_Server(void);
bool testWifi();
extern char uart_ssid[30], uart_pwd[30];
//Establishing Local server at port 80
WebServer server(80);

uint8_t check_bit = 0;

///@brief This function is initializing the wifi
///@brief This function is called in setup function
///@return None
///@param None
void WiFi_Init()
{
  check_bit = gSystemConfiguration.Wificheckbit;
  //check_bit=1;
  if (check_bit == 1)
  {
    check_bit = 0;

    sprintf(ssid, "%s", gSystemConfiguration.WifiUsername, sizeof(gSystemConfiguration.WifiUsername));
    sprintf(passphrase, "%s", gSystemConfiguration.WifiPassword, sizeof(gSystemConfiguration.WifiUsername));

    DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n", ssid);
    DEBUG_TEST_SERIAL.printf("WIFI_USEPASSWORD: %s \r\n", passphrase);
    WiFi.mode(WIFI_STA);
    WiFi.begin(ssid, passphrase);
    if (testWifi() == true)
    {
      DEBUG_TEST_SERIAL.print("Connected to ");
      DEBUG_TEST_SERIAL.print(ssid);
      DEBUG_TEST_SERIAL.println(" Successfully");
      delay(100);
    }
  }
  else
  {
    WiFi.softAP(Default_SSID, Default_Password); // Setup HotSpot
    Serial.print(WiFi.softAP(Default_SSID, Default_Password));
    Create_Server();
  }
}
   ///@brief This function is to check the wifi connection and entering in to hotspot mode
   ///@brief This function is called in wifi init function
  ///@return None
  ///@param None
void Create_Server() {
  WiFi.disconnect();
  DEBUG_TEST_SERIAL.println("Connection Status Negative / Check bit Low");
  DEBUG_TEST_SERIAL.println("Turning the HotSpot On");
  setupAP();
  launchWeb();
 // DEBUG_TEST_SERIAL.print();
  DEBUG_TEST_SERIAL.print("Waiting.");

  while ((WiFi.status() != WL_CONNECTED))
  {
    DEBUG_TEST_SERIAL.print(".");
    delay(100);
    server.handleClient();
  }
  WiFi.softAPdisconnect(true);
  delay(1000);
}

   ///@brief This function is to check the wifi connectin for ten itarations
   ///@brief This function is called in wifi init for connection of wifi
  ///@return None
  ///@param None
bool testWifi(void)
{
  int c = 0;
  DEBUG_TEST_SERIAL.print(F("CONNECTING TO SAVED Wi-Fi CONNECTION"));
  while ( c < 10 ) {
    if (WiFi.status() == WL_CONNECTED)
    {
      DEBUG_TEST_SERIAL.println("");
      return true;
    }
    delay(500);
    DEBUG_TEST_SERIAL.print(".");
    c++;
  }
  DEBUG_TEST_SERIAL.println("");
  DEBUG_TEST_SERIAL.println("ERROR 1");
  DEBUG_TEST_SERIAL.print("Connection timed out");
  return false;
}
   ///@brief This function is to print the local ip and softip
   ///@brief This function is called in create server function
  ///@return None
  ///@param None
void launchWeb()
{
  DEBUG_TEST_SERIAL.print("Local IP: ");
  DEBUG_TEST_SERIAL.print(WiFi.localIP());

  DEBUG_TEST_SERIAL.print("SoftAP IP: ");
  DEBUG_TEST_SERIAL.print(WiFi.softAPIP());
  createWebServer();

  // Start the server
  server.begin();
  DEBUG_TEST_SERIAL.print("Server started");
}

   ///@brief This function is used to scan the available devices
   ///@brief This function is called in create server function
  ///@return None
  ///@param None
void setupAP(void)
{
  delay(100);
  n = WiFi.scanNetworks();
  //DEBUG_TEST_SERIAL.print(n);
  DEBUG_TEST_SERIAL.print("scan done");
  if (n == 0)
  {
    DEBUG_TEST_SERIAL.print("no networks found");
  }
  else
  {
    DEBUG_TEST_SERIAL.print(n);
    DEBUG_TEST_SERIAL.print(" networks found");
    for (int i = 0; i < n; ++i)
    {
      // print SSID and RSSI for each network found
      DEBUG_TEST_SERIAL.print(i + 1);
      DEBUG_TEST_SERIAL.print(": ");
      DEBUG_TEST_SERIAL.print(WiFi.SSID(i));
      DEBUG_TEST_SERIAL.print(" (");
      DEBUG_TEST_SERIAL.print(WiFi.RSSI(i));
      DEBUG_TEST_SERIAL.print(")");
      delay(10);
    }
  }
  DEBUG_TEST_SERIAL.print("");
  st = "<ol>";
  for (int i = 0; i < n; ++i)
  {
    // print SSID and RSSI for each network found
    st += "<li>";
    st += WiFi.SSID(i);
    st += " (";
    st += WiFi.RSSI(i);
    st += ")";
    st += "</li>";
  }
  st += "</ol>";
  delay(100);
  DEBUG_TEST_SERIAL.print("Initializing_softap_for_wifi credentials_modification");
  DEBUG_TEST_SERIAL.print("over");
}
   ///@brief This function is used to open the HTML page and  display the available devices and select the wifi device
   ///@brief This function is called in launch web function
  ///@return None
  ///@param None
void createWebServer()
{
  {
    server.on("/", []() {
      IPAddress ip = WiFi.softAPIP();
      String ipStr = String(ip[0]) + '.' + String(ip[1]) + '.' + String(ip[2]) + '.' + String(ip[3]);
      content = "<!DOCTYPE HTML>\r\n<html>Welcome to Kitchenery project Wifi Credentials Update page";
      content += "<p>";
      content += "scan done ";
      content += n;
      content += " networks found";
      content += "<p>";
      content += st;
      content += "</p><form method='get' action='setting1'><label>SSID:<li></label><input name='ssid'length=32><input name='pass'length=64><input type=\"submit\" value=\"update\"></form>";
      content += "<p>";
      content += "<p>";
      content += "<p>";
      content += "<p>";
      content += "<form action=\"/exit\" method=\"POST\"><input type=\"submit\" value=\"exit\"></form>";
      content += "</html>";
      server.send(200, "text/html", content);
    });

    //scan
    server.on("/scan", []() {
      setupAP();
      IPAddress ip = WiFi.softAPIP();
      String ipStr = String(ip[0]) + '.' + String(ip[1]) + '.' + String(ip[2]) + '.' + String(ip[3]);
      content = "<!DOCTYPE HTML>\r\n<html>go back";
      server.send(200, "text/html", content);
    });
    //exit
    server.on("/exit", []() {
      content = "<!DOCTYPE HTML>\r\n<html>Thank you";
      server.send(200, "text/html", content);
      delay(1000);
      ESP.restart();
    });

    //setting1
    server.on("/setting1", []() {
      String qsid = server.arg("ssid");
      String qpass = server.arg("pass");

      if (qsid.length() > 0 && qpass.length() > 0) {
        DEBUG_TEST_SERIAL.print(qsid);
        DEBUG_TEST_SERIAL.print("");
        DEBUG_TEST_SERIAL.print(qpass);
        DEBUG_TEST_SERIAL.print("");

        DEBUG_TEST_SERIAL.print("writing eeprom ssid:");
        qsid.toCharArray((char *)gSystemConfiguration.WifiUsername, sizeof(gSystemConfiguration.WifiUsername));
        DEBUG_TEST_SERIAL.print("writing eeprom pass:");
        qpass.toCharArray((char *)gSystemConfiguration.WifiPassword, sizeof(gSystemConfiguration.WifiPassword));
        DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n", (char*)gSystemConfiguration.WifiUsername);
        DEBUG_TEST_SERIAL.printf("WIFI_USERNAME: %s \r\n", (char*)gSystemConfiguration.WifiPassword);

        gSystemConfiguration.Wificheckbit = 1; //Saved SSID & Password
        cfg_param_write();

        content = "{\"Success\":\"saved to eeprom... go back for exit or update anothe parameters\"}";
        statusCode = 200;
        //ESP.restart();
      }
      else {
        content = "{\"Error\":\"404 not found\"}";
        statusCode = 404;
        DEBUG_TEST_SERIAL.print("Sending 404");
      }
      server.sendHeader("Access-Control-Allow-Origin", "*");
      server.send(statusCode, "application/json", content);
    });
  }
}
