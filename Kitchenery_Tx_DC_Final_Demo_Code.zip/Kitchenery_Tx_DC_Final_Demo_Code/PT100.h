#ifndef _PT100_H
#define _PT100_H

#include "Arduino.h"


///@brief Function prototype


void temp_sensor_reading_EXT();


#endif
