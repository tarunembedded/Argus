
///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: Relay's
///@brief  Development Board:ESP WROOM 32

#include "Arduino.h"
#include "relay.h"
#include "WPT.h"

uint8_t k1_power_relay_pin = 25;
uint8_t k2_12v_relay_pin = 23;
uint8_t k3_half_bridge_relay_pin = 4;
uint8_t fan1_relay_pin = 18;
uint8_t fan2_relay_pin = 5;

///@brief Initializing the All Relay's
///@brief This function should be called In the setup function
///@return None
///@param None
void relay_init(void)
{
  pinMode(k1_power_relay_pin, OUTPUT);
  pinMode(k2_12v_relay_pin, OUTPUT);
  pinMode(k3_half_bridge_relay_pin, OUTPUT);
  pinMode(fan1_relay_pin, OUTPUT);
  pinMode(fan2_relay_pin, OUTPUT);
}


///@brief This function is used to Turn ON the 12V relay
///@brief This function is called when 12V relay    command is given through BLE,UART and touchpad
///@return None
///@param None
void volt12_relay_on(void)
{
  digitalWrite(k2_12v_relay_pin, HIGH);
}

///@brief This function is used to Turn OFF the 12V relay
///@brief This function is called when 12V relay   command is given through BLE,UART and touchpad
///@return None
///@param None
void volt12_relay_off(void)
{
  digitalWrite(k2_12v_relay_pin, LOW);
}

///@brief This function is used to Turn ON the Power relay
///@brief This function is called when Power relay  command is given through BLE,UART and touchpad
///@return None
///@param None
void k1_power_relay_on(void)
{
  digitalWrite(k1_power_relay_pin, HIGH);

}

///@brief This function is used to Turn OFF the Power relay
///@brief This function is called when Power relay   command is given through BLE,UART and touchpad
///@return None
///@param None
void k1_power_relay_off(void)
{
  digitalWrite(k1_power_relay_pin, LOW);

}

///@brief This function is used to Turn ON the Half Bridge relay
///@brief This function is called when Half Bridge relay   command is given through BLE,UART and touchpad
///@return None
///@param None
void half_bridge_relay_on(void)
{
  digitalWrite(k3_half_bridge_relay_pin, HIGH);

}

///@brief This function is used to Turn OFF the Half Bridge relay
///@brief This function is called when Half Bridge relay    command is given through BLE,UART and touchpad
///@return None
///@param None
void half_bridge_relay_off(void)
{
  digitalWrite(k3_half_bridge_relay_pin, LOW);

}

///@brief This function is used to Turn ON the FAN1 relay
///@brief This function is called when FAN1 relay  command is given through BLE,UART and touchpad
///@return None
///@param None
void fan1_relay_on(void)
{
  digitalWrite(fan1_relay_pin, HIGH);
}

///@brief This function is used to Turn OFF the FAN1 relay
///@brief This function is called when FAN1 relay   command is given through BLE,UART and touchpad
///@return None
///@param None
void fan1_relay_off(void)
{
  digitalWrite(fan1_relay_pin, LOW);
}

///@brief This function is used to Turn ON the FAN2 relay
///@brief This function is called when FAN1 relay   command is given through BLE,UART and touchpad
///@return None
///@param None
void fan2_relay_on(void)
{
  digitalWrite(fan2_relay_pin, HIGH);
}

///@brief This function is used to Turn OFF the FAN2 relay
///@brief This function is called when FAN1 relay  command is given through BLE,UART and touchpad
///@return None
///@param None
void fan2_relay_off(void)
{
  digitalWrite(fan2_relay_pin, LOW);
}


///@ For testing

void Testing_relay() {

  volt12_relay_on();
//  k1_power_relay_on();
  Start_mc_pwm_signal();
  half_bridge_relay_on();
}
