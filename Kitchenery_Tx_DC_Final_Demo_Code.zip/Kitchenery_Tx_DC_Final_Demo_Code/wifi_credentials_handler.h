#ifndef _wifi_credentials_handler_h
#define _wifi_credentials_handler_h

#define Default_SSID "kitchenery"           //Defaults AP SSID when switched On your Device
#define Default_Password "kitchenery@123"        //Default AP Password when switched on your Device


//I often use the WifiManager library for this configuration method
typedef struct
{
  uint16_t       wifi_update_time;
  uint16_t       wifi_update_event;
} wifiData_timer_t;

extern volatile wifiData_timer_t wifiData_timer;

void WiFi_Init(void);
void launchWeb(void);
void setupAP(void);
void createWebServer(void);
void Create_Server(void);
bool testWifi();

#endif
