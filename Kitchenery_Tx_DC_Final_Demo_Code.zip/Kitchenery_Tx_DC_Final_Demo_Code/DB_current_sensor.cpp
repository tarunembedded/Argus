
///@brief  Project Name: Kitchenery
///@brief  Author Name: Argus Team
///@brief  Task: Diode Bridge current sensor
///@brief  Development Board:ESP WROOM 32

#include <SoftwareSerial.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include "DB_current_sensor.h"


int DB_current_sensorpin = 36;
int DB_mVperAmp = 66; // use 100 for 20A Module and 66 for 30A Module

double DB_Voltage = 0;
double DB_VRMS = 0;
double DB_AmpsRMS = 0;
double DB_AmpsRMS1 = 0;
char DB_current_data[110];

uint8_t DB_rms1 = 0;
extern char All__Sensor_Data_saved[];

//uint8_t server_send_data = 0;


///@brief This function convert the ADC values to voltage and that convert to AMPS using root mean square formule
///@brief This function is called when Diode bridge current command is given through BLE,UART and touchpad
///@return None
///@param None
void DB_current_reading(void)
{
  //  Sensor_falg = 1;
  DB_Voltage = DB_getVPP();
  DB_VRMS = ((DB_Voltage / 2.0) * 0.707); //root 2 is 0.707
  DB_AmpsRMS = (DB_VRMS * 1000) / DB_mVperAmp;

  //   Serial.print(AmpsRMS);
  //   Serial.print(" AmpsRMS1");

  DB_AmpsRMS1 = DB_AmpsRMS - 0.39;
  if (DB_AmpsRMS1 < 0.2) {
    DB_AmpsRMS1 = 0;
  }
  sprintf(All__Sensor_Data_saved, "DC:%.1f", DB_AmpsRMS1);
  //  Serial.print("DC :");
  //sprint((char *)aws_server_data,"DB current sensor data :%0.2f",DB_AmpsRMS1);
  Serial.print(All__Sensor_Data_saved);
  Serial.print("  ");

}


///@brief This function read the ADC pin
///@brief This function is called at the time of cerrent calculations
///@return Float
///@param None
float DB_getVPP()
{
  float DB_result, DB_result1;
  int DB_readValue;             //value read from the sensor
  int DB_maxValue = 0;          // store max value here
  int DB_minValue = 4096;          // store min value here

  uint32_t DB_start_time = millis();
  while ((millis() - DB_start_time) < 2000) //sample for 1 Sec
  {
    DB_readValue = analogRead(DB_current_sensorpin);

    // see if you have a new maxValue
    if (DB_readValue > DB_maxValue)
    {
      /*record the maximum sensor value*/
      DB_maxValue = DB_readValue;

    }
    if (DB_readValue < DB_minValue)
    {
      /*record the minimum sensor value*/
      DB_minValue = DB_readValue;

    }
  }

  // Subtract min from max
  DB_result = ((DB_maxValue - DB_minValue) * 5.0) / 4096.0;


  DB_result1 = (DB_maxValue - DB_minValue);


  return DB_result;
}
