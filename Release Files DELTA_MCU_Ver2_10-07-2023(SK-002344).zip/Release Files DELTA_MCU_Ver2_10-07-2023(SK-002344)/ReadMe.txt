Changed to 22V Power supply as ADC
