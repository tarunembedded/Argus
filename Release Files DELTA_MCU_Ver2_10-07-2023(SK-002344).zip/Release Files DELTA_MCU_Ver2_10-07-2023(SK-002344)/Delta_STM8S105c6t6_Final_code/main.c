
/* MAIN.C file desk
 * 
 * Copyright (c) 2002-2005 STMicroelectronics
 */

#include <stm8s.h>
#include <stm8s_gpio.h>
#include <stm8s_uart2.h>
#include <stm8s_rst.h>
#include <stm8s_iwdg.h>
#include <stdio.h>

#define PUTCHAR_PROTOTYPE char putchar (char c)
#define GETCHAR_PROTOTYPE char getchar (void)

#define CF_LED_PORT    GPIOC//GPIOB
#define CF_LED_GPIO    GPIO_PIN_7//GPIO_PIN_5


#define CF_SCADA_PORT  GPIOE
#define CF_SCADA_GPIO  GPIO_PIN_3        //2

#define MO_SCADA_PORT  GPIOD             //GPIOE
#define MO_SCADA_GPIO  GPIO_PIN_0        //3

#define HP_SCADA_PORT  GPIOA//GPIOE
#define HP_SCADA_GPIO  GPIO_PIN_2//GPIO_PIN_2        //0 

#define LP_SCADA_PORT  GPIOE              //GPIOD
#define LP_SCADA_GPIO  GPIO_PIN_0         //0

#define EXT_DIS_ADD       0x4120
#define DIS_EXT           5

//#define LAST_ERR_CODE     0x4130

#define LOW_24V						820
#define VERY_LOW_24V			730  

#define LOW_3P6V_B				939  
#define VERY_LOW_3P6V_B	  920  

//#define LOW_3P6V_E				915
//#define VERY_LOW_3P6V_E	  856	

//__IO int ext24_var_track =0;
//__IO int ext24_var_track_test =0;
//__IO int bat24_var_delay=0;
__IO uint32_t LsiFreq = 0;

static void CLK_Config(void);
static void UART2_Config(void);
static void ADC_Config(void);
static void Gpio_Config(void);
static void System_shutdown(void);
static void Read_Status(void);
static void Test_LED(void);
static void Solanoid_On(void);
static void Solanoid_Off(void);

static void ADC_CH1(void);
//static void ADC_CH2(void);
static void ADC_CH6(void);
static void ADC_CH7(void);
static void ADC_CH8(void);

static void IWDG_Config(void);
static void High_Pressure_led(void);
static void Low_Pressure_led(void);
static void Esd_Scada_led(void);
static void System_Normal_led(void);
static void Manual_Override_led(void);
static void Low_Battery_led(void);
static void Common_fault_led(void);

void User_Delay(uint32_t Time);

volatile int Test_knob_pressed=0;
volatile int Reset_knob_pressed=0;
volatile int ESD_from_scada=0;

unsigned int A1 = 0x0000;
//unsigned int A2 = 0x0000;
unsigned int A6 = 0x0000;
unsigned int A7 = 0x0000;
unsigned int A8 = 0x0000;

int Ctr_1sec=0;
int Ctr_1sec_2=0;
int Ctr_1sec_led=0;
int Solanoid_delay=0,solanoid_off_pos=0;
int pressure_sensor_delay=0;

int loop = 0;
int Error_signal=0;
//int manual_attention=0;
//int manual_attention_solved=0;

char ESD_ON=0;
char Reset_on=0;
int Last_error=0;
int manual_clear=0;
int Manual_on = 0;
int LED_clear=0;

unsigned long int i;
unsigned long int j = 0;
unsigned long int x = 0;
unsigned int reset_test = 0;
unsigned int testswitch_test = 0;

u32 LSIMeasurment(void);

char Svalve_on=0;
char Svalve_off=0;
char Svalve_fun_off=0;
char Svalve_fun1_off=0;
char Svalve_Batlow=0;
char svalve_templow=0;

int Temperature=0;

int hp_var = 0;
int lp_var = 0;
int lb_var = 0;
int mo_var = 0;
int sn_var = 0;
int esd_var = 0;
//int ext24_var =0;
//int bat24_var =0;
int cf_var=0;
int cf_var_stable=0;

int val = 0x00;
int Error_track=0;
int Test_track=0;
int delay_var=0;
int scada_var=0;
int led_check=0;
int System_shutdown_var =0;
int System_shutdown_var_temp =0;

BitStatus Pressure_High=1;
BitStatus Preasure_Low=1;
BitStatus ESD_scada=0;
BitStatus Manual_override_on=0;

void main()
{
	
		UART2_DeInit();
	 
	  /* Clock configuration -----------------------------------------*/
		CLK_Config();  
	  
    /* UART1 configuration -----------------------------------------*/
		UART2_Config();
		/* Get measured LSI frequency */
    LsiFreq = LSIMeasurment();
    //LsiFreq =	LsiFreq *8;
		/* IWDG Configuration */
		IWDG_Config();
		/* Initialization of AWU */
		/* LSI calibration for accurate auto wake up time base*/
		AWU_LSICalibrationConfig(LsiFreq);
    
		/* The delay corresponds to the time we will stay in Halt mode */
		AWU_Init(AWU_TIMEBASE_512MS);
		 
		EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOA, EXTI_SENSITIVITY_FALL_ONLY);
    EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOD, EXTI_SENSITIVITY_FALL_ONLY);
		
		Gpio_Config();
		//GPIO_WriteLow(CF_SCADA_PORT, CF_SCADA_GPIO);
		GPIO_WriteLow(HP_SCADA_PORT, HP_SCADA_GPIO);
		
		printf("\n\rWelcome to Delta Project\n\r");
		
    /* Define FLASH programming time */
    FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
    /* Unlock Data memory */
    FLASH_Unlock(FLASH_MEMTYPE_DATA);

		/* Read a byte at a specified address */
    val = FLASH_ReadByte(EXT_DIS_ADD);
		printf("FLASH_ReadByte = %d\r\n",	val);
		
		//Error_track=FLASH_ReadByte(LAST_ERR_CODE);
		
		if(val==DIS_EXT)
		{
			/* Generate ERROR Signal*/
			Error_signal=4;
			Error_track=4;
			//cf_var=1;
			cf_var_stable=1;
			pressure_sensor_delay=10;
			/*Erase Error*/
		//	FLASH_EraseByte(EXT_DIS_ADD);
		//	FLASH_ProgramByte(EXT_DIS_ADD, 0);
		}

		printf("esd_var 1 = %d\r\n",	esd_var);
		//printf("ext24_var 1 =%d\r\n", ext24_var);
		//printf("bat24_var 1 =%d\r\n", bat24_var);
		printf("cf_var 1 = %d\r\n",	sn_var);
		printf("sn_var 1 = %d\r\n",	sn_var);
		printf("hp_var 1 = %d\r\n",hp_var);
		printf("lp_var 1 = %d\r\n",	lp_var);
		printf("lb_var 1 = %d\r\n",	lb_var);
		printf("mo_var 1 = %d\r\n",	mo_var);
  
	 sn_var = 1;
        User_Delay(300);		
		//GPIO_WriteHigh(GPIOG, GPIO_PIN_0);
		Ctr_1sec_2 = 2;

	 while(1)
    {
			printf("manual_clear = %d\r\n",manual_clear);
			//printf("manual_attention = %d\r\n",manual_attention);
      /* Reload IWDG counter */
			IWDG_ReloadCounter(); 
			
			if(System_shutdown_var == 0 && Ctr_1sec_2 >= 2)
			{
					Ctr_1sec_2=0;
					printf("\n\rWhile loop\n\r");
					if(pressure_sensor_delay==0)
				  Read_Status();

						Manual_override_on = GPIO_ReadInputPin(GPIOE,GPIO_PIN_5);
			      if(!Manual_override_on)
			        {
								printf("Manual override mode on\r\n");
								
								//printf("manual_attention = %d\r\n",manual_attention);
								//if(manual_attention==1)
								//{
								//	FLASH_EraseByte(EXT_DIS_ADD);
								//	FLASH_ProgramByte(EXT_DIS_ADD, 0);
								//	manual_attention=0;
								//	manual_attention_solved=1;
							  //}
								printf("Manual override mode on\r\n");
							if(Manual_on == 0)
								{	
								printf("manual_on==0\r\n");
								  if(Error_signal == 1)
									  {
										  hp_var = 1;
										  LED_clear=1;
										}
								  else if (Error_signal == 2)
										{
											lp_var = 1;
											LED_clear=1;
										}
									  else if (Error_signal == 3)
										{
											esd_var = 1;
											LED_clear=1;
										}
										else if (Error_signal == 4)
										{
											LED_clear=1;
											//cf_var_stable=0;
											FLASH_EraseByte(EXT_DIS_ADD);
											FLASH_ProgramByte(EXT_DIS_ADD, 0);
										}
    								else if (Error_signal == 5)
										{
											Error_signal=0;
											LED_clear=1;
											//cf_var_stable=0;
										}

										
										GPIO_WriteHigh(MO_SCADA_PORT, MO_SCADA_GPIO);
										manual_clear=1;
										Manual_on = 1;
										led_check=4;
										Solanoid_On();
										printf("svalve on for Manual_override_on\r\n");
						          

										mo_var =1;
										sn_var = 0;
										
										Reset_knob_pressed=0;
										Test_knob_pressed=0;
											
								}
							}
						else 
							{
								  if(manual_clear == 1)	
										{
											printf("manual_clear==0\r\n");
											manual_clear=0;
											Svalve_off=0;
											Manual_on= 0;
											Error_signal=0;
									  }
								
									printf("Reading the status of switches\r\n");
									printf("INSERVICE MODE\r\n");
									mo_var = 0;
									
									if(Pressure_High && Preasure_Low && Error_signal==0 && LED_clear==0)
									{
										GPIO_WriteLow(MO_SCADA_PORT, MO_SCADA_GPIO);
									}
									
								 	if((!Pressure_High) && Error_signal==0)
										{
											printf("Pressure_high\r\n");
											led_check=1;
											Error_signal=1;
											hp_var = 1;
											//cf_var = 1;
											//GPIO_WriteHigh(CF_SCADA_PORT, CF_SCADA_GPIO);
											GPIO_WriteHigh(HP_SCADA_PORT, HP_SCADA_GPIO);
											Error_track=1;
										}
									else if((!Preasure_Low) && Error_signal==0)
										{
											printf("Preasure_Low\r\n");
											led_check=2;
											Error_signal=2;
											lp_var = 1;
											//cf_var = 1;
											
											//GPIO_WriteHigh(CF_SCADA_PORT, CF_SCADA_GPIO);
											GPIO_WriteHigh(LP_SCADA_PORT, LP_SCADA_GPIO);   //Low pressure signal to SCADA
											Error_track=2;
										}										
									else if((ESD_scada) && Error_signal==0)
											{
												printf("\r\nESD Request\r\n");
												led_check=3;
												Error_signal=3;
												esd_var = 1;
												//cf_var = 1;	
												
												//GPIO_WriteHigh(CF_SCADA_PORT, CF_SCADA_GPIO);
												//GPIO_WriteHigh(GPIOE, GPIO_PIN_3);
												Error_track=3;
											}
										
		              printf("\r\n");
								
									if(Error_signal > 0)
										{

													sn_var = 0;
													
													if(Svalve_off == 0)
													{
													  Solanoid_Off();
														printf("svalve off for reset\r\n");
													  Svalve_off=1;
													}
				                
								    }
									else
										{
											if(LED_clear==0)
												{
													if(solanoid_off_pos==0)
													{
													 sn_var = 1;
											  	 printf("clear led loop\r\n");
													}
												}

											if(Svalve_on == 0)
												{
													//printf("issue\r\n");
													Solanoid_On();
													Svalve_on = 1;
												}
										}
									
						  }
									
				}				

					if(Reset_knob_pressed)
						{
						
					  User_Delay(10);
						reset_test =  GPIO_ReadInputPin(GPIOD,GPIO_PIN_2);
					  if(reset_test==0)
					   {
								if(manual_clear == 0)
								{
							
							  //if(manual_attention==0)
								//{
								GPIO_WriteLow(MO_SCADA_PORT, MO_SCADA_GPIO);
								GPIO_WriteLow(HP_SCADA_PORT, HP_SCADA_GPIO);
								//}	
								GPIO_WriteLow(LP_SCADA_PORT, LP_SCADA_GPIO);
								if(Error_signal==5)
							  {}
								else
							  {GPIO_WriteLow(CF_SCADA_PORT, CF_SCADA_GPIO);}
                GPIO_WriteLow(GPIOB, GPIO_PIN_0);
								
								//printf("Last_error = %d\r\n",Error_signal);
								printf("Reset switch pressed\r\n");
								Last_error=0;
								
											if(Error_signal==1|Error_signal==2|Error_signal==3|Error_signal==4|Error_signal==5| Test_track ==1)
												{
													
													 Last_error = Error_signal;
													 
													 //blink.system_normal_led = 1;
												   sn_var = 1;
												
													 
													// blink.low_pressure_led = 0;
													 lp_var = 0;
													
													 //blink.esd_scada_led = 0;
													 esd_var = 0;
													 
													 // blink.high_pressure_led = 0;
													 hp_var = 0;
													 
													 cf_var = 0;
													 //if(cf_var_stable==1)
												   //{}
												   //else {cf_var = 0;
													 ////GPIO_WriteLow(CF_SCADA_PORT, CF_SCADA_GPIO);
													 //}
												   if(Error_signal==5)
												   {}
													 else
													 {Error_signal=0;}
													 
													 Test_track=0;
											     //if(ext24_var_track_test==1)
													 //{
													 //	ext24_var_track = 0;
													 //	ext24_var_track_test=0;
													 //}
													 //if(manual_attention==0)
												   //{Error_signal=0;}
													 //Test_track=0;
												}		
											else
												{
													 printf("\r\nErrors not found\r\n");
												}
											ESD_ON=0;
											Reset_on=1;
											System_shutdown_var=0;
											System_shutdown_var_temp=0;
											if(System_shutdown_var==0)
											{
											System_shutdown();  // LEDs off
										  }
											Reset_knob_pressed=0;
											Test_knob_pressed=0;
											LED_clear=0;
											Svalve_Batlow=0;
											svalve_templow=0;
											Svalve_fun_off=0;
											Svalve_fun1_off=0;
											lb_var = 0;
											//FLASH_ProgramByte(EXT_DIS_ADD, 0);											
								}
								else
								{
									System_shutdown_var=0;
									Svalve_off=0;
									Manual_on= 0;
								}
							}
					}
						
						if(Test_knob_pressed)
				      {
							 
							User_Delay(5);
							testswitch_test =  GPIO_ReadInputPin(GPIOA,GPIO_PIN_5);
							if(testswitch_test == 0)
							{
								printf("Test switch pressed\r\n");
									if(j<3)
										{
											//User_Delay(10);
											User_Delay(100);
											printf("Test switch pressed single time\r\n");
											x =  GPIO_ReadInputPin(GPIOA,GPIO_PIN_5);
									
											if(x==0)
												{
													j++;
													printf("x=0\r\n");
												}
											else
											{
												printf("x=1\r\n");
												j=0;
											}
										}
									
									if(j == 2)
										{
											printf("Test switch pressed 3 sec\r\n");
											Test_LED();
											j=0;
											Test_knob_pressed=0;
										}
									else if(j==0)
										{
											Test_knob_pressed=0;
											Test_track=1;
											//printf("pressure high = %d\r\n",Last_error);
											if(Last_error==1 || Error_track==1)
												{
													hp_var = 1;
												}
											else if(Last_error==2 || Error_track==2)
												{
													lp_var = 1;
												}
											else if(Last_error==3 || Error_track==3)
												{
													esd_var =1;
												}
											//else if(Last_error==4 || Error_track==4)
											//	{
											//		ext24_var_track =1;
											//		ext24_var_track_test=1;
											//	}
											else if(Last_error==5 || Error_track==5)
												{
													cf_var =1;
												}
										}
								}	 
						  }
		
					
				  Ctr_1sec_2++;//printf("Ctr_1sec_2 %d\r\n",Ctr_1sec_2);
					Ctr_1sec++;//printf("Ctr_1sec %d\r\n",Ctr_1sec);
					Ctr_1sec_led++;printf("Ctr_1sec_led %d\r\n",Ctr_1sec_led);
					if(Solanoid_delay!=0)
					{
						Solanoid_delay--;
					}
					
						if(pressure_sensor_delay!=0)
					{
						pressure_sensor_delay--;
					}
					
					if(Ctr_1sec>= 2 && System_shutdown_var_temp == 0 && Error_signal!=4 && Solanoid_delay==0)
						{
							GPIO_WriteHigh(GPIOA, GPIO_PIN_3);
							GPIO_WriteHigh(GPIOD, GPIO_PIN_7);
							GPIO_WriteHigh(GPIOA, GPIO_PIN_4);
							//GPIO_WriteHigh(GPIOG, GPIO_PIN_0);
							printf("\r\nreferance control\r\n");
							
							ADC_CH1();
							//ADC_CH2();
							ADC_CH7();
							ADC_CH8();
								 
							ADC_CH1();
              //ADC_CH2();							
							ADC_CH7();
							ADC_CH8();
								 
							GPIO_WriteLow(GPIOD, GPIO_PIN_7);
							GPIO_WriteLow(GPIOA, GPIO_PIN_4);
							//GPIO_WriteLow(GPIOG, GPIO_PIN_0);
						  GPIO_WriteLow(GPIOA, GPIO_PIN_3);
							
							ADC_CH6();
							ADC_CH6();
								
							Ctr_1sec=0;
							
						
				if(A1>883)
				{
					/*
							if(A7==0 || A8==0)       //battery check
							{
								//Solanoid_Off();          //
								//printf("svalve off for Battery check\r\n");
								//bat24_var=0;
								lb_var = 1;
								GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
							}
						if(A7<VERY_LOW_3P6V_B || A8<VERY_LOW_24V)    //battery check
							{
								lb_var = 1;
								//sn_var = 0;
								GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
								//if(Svalve_Batlow == 0)
									//{
										//System_shutdown_var=1;
										//Solanoid_Off();
										//Svalve_Batlow=1;
										//FLASH_ProgramByte(EXT_DIS_ADD, DIS_EXT);
									//}
								//printf("svalve off for Low battery\r\n");
							}
							else if(A7<LOW_3P6V_B || A8<LOW_24V)
							{
									lb_var = 1;
									GPIO_WriteHigh(GPIOB, GPIO_PIN_0);									
									printf("Low battery\r\n");
							}*/
				}
				else
				{
						if(A7==0 || A8==0)       //battery check
							{
								Solanoid_Off();          //
								printf("svalve off for Battery check\r\n");
								//bat24_var=0;
								lb_var = 1;
								GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
							}
						if(A7<VERY_LOW_3P6V_B || A8<VERY_LOW_24V)    //battery check
							{
								lb_var = 1;
								sn_var = 0;
								GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
								if(Svalve_Batlow == 0)
									{
										System_shutdown_var=1;
										Solanoid_Off();
										Svalve_Batlow=1;
										FLASH_ProgramByte(EXT_DIS_ADD, DIS_EXT);
									}
								printf("svalve off for Low battery\r\n");
							}
							else if(A7<LOW_3P6V_B || A8<LOW_24V)
							{
									lb_var = 1;
									GPIO_WriteHigh(GPIOB, GPIO_PIN_0);									
									printf("Low battery\r\n");
							}
				}
								

					if(A6<350)
								{
									Temperature = A6 ;
									Temperature = (Temperature*2.9)/10;
									printf("Temperature is %d\r\n",Temperature);
								}
								
						}
						
					if(Temperature >= 85 && System_shutdown_var ==0)
						{		
							System_shutdown_var =1;
							System_shutdown_var_temp=1;
							
							if(svalve_templow == 0)
									{
										//hp_var = 1;
										//lp_var = 1;
										cf_var = 1;
										//cf_var_stable=1;
										sn_var = 0;
										Solanoid_Off();
										svalve_templow = 1;
										Error_signal=5;
										Error_track=5;
										//manual_attention=1;
										//GPIO_WriteHigh(GPIOE, GPIO_PIN_3);     //Common Fault
										GPIO_WriteHigh(CF_SCADA_PORT, CF_SCADA_GPIO);
									}
							printf("\r\nsvalve off for Temperature check\r\n");							
						}
			
			printf("\r\n Scan status = %d\r\n",System_shutdown_var);
			CLK_SlowActiveHaltWakeUpCmd(ENABLE);//printf("\r\nCase 1\r\n");	
			FLASH_SetLowPowerMode(FLASH_LPMODE_POWERDOWN);//printf("\r\nCase 2\r\n");	
			halt();  /*Program halted */
			IWDG_ReloadCounter(); 
			halt();
			//printf("\r\nCase 3\r\n");	
			
						if(Ctr_1sec_led == 2)
						{
							if(hp_var == 1)
								{
									High_Pressure_led();
								}
							if(lp_var == 1)
								{
									Low_Pressure_led();
								}
							if(esd_var == 1)
								{
									Esd_Scada_led();
								}
							if(mo_var == 1)
							  {
									Manual_Override_led();
								}
							if(lb_var == 1)
							  {
									Low_Battery_led();
								}
							if(sn_var == 1)
								{
									System_Normal_led();
								}
							if(cf_var == 1)
							 {
								 Common_fault_led();
							 }
								
								Ctr_1sec_led=0;
						}
							
		printf("\r\nProgram halted\r\n");	
	}

}

static void CLK_Config(void)
{
    /* Initialization of the clock */
    /* Clock divider to HSI/1 */
	CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV8);
}
/**
  * @brief  Configures the IWDG to generate a Reset if it is not refreshed at the
  *         correct time. 
  * @param  None
  * @retval None
  */
static void IWDG_Config(void)
{
  /* Enable IWDG (the LSI oscillator will be enabled by hardware) */
  IWDG_Enable();
  
  /* IWDG timeout equal to 250 ms (the timeout may varies due to LSI frequency
     dispersion) */
  /* Enable write access to IWDG_PR and IWDG_RLR registers */
  IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
  
  /* IWDG counter clock: LSI/128 */
  IWDG_SetPrescaler(IWDG_Prescaler_256);
  
  /* Set counter reload value to obtain 250ms IWDG Timeout.
    Counter Reload Value = 250ms/IWDG counter clock period
                         = 250ms / (LSI/128)
                         = 0.25s / (LsiFreq/128)
                         = LsiFreq/(128 * 4)
                         = LsiFreq/512
   */
  IWDG_SetReload((uint8_t)(255));
  
  /* Reload IWDG counter */
  IWDG_ReloadCounter();
}

static void Gpio_Config(void)
{
// ***** inputs ****** //


		GPIO_Init(GPIOB, GPIO_PIN_3,GPIO_MODE_IN_PU_NO_IT); 	// pressure low alarm
		GPIO_Init(GPIOB, GPIO_PIN_4,GPIO_MODE_IN_PU_NO_IT); 	// pressure high alarm
   
	  GPIO_Init(GPIOE, GPIO_PIN_6,GPIO_MODE_IN_FL_NO_IT);  	// ESD from scada
	
		GPIO_Init(GPIOD, GPIO_PIN_2,GPIO_MODE_IN_PU_IT); 			// Reset Knob
		GPIO_Init(GPIOA, GPIO_PIN_5,GPIO_MODE_IN_PU_IT); 			// Test Knob
		GPIO_Init(GPIOE, GPIO_PIN_5,GPIO_MODE_IN_PU_NO_IT ); 	// Manualoverride
			
		GPIO_Init(GPIOB, GPIO_PIN_6,GPIO_MODE_IN_FL_NO_IT); 	// Temperature
    GPIO_Init(GPIOE, GPIO_PIN_7,GPIO_MODE_IN_FL_NO_IT );  // Battery ADC Status
	  GPIO_Init(GPIOB, GPIO_PIN_7,GPIO_MODE_IN_FL_NO_IT); 	// Battery status 3.6v
	  GPIO_Init(GPIOB, GPIO_PIN_1,GPIO_MODE_IN_FL_NO_IT); 	// external power status 24V -----------Newly added
		GPIO_Init(GPIOB, GPIO_PIN_2,GPIO_MODE_IN_FL_NO_IT); 	// Battery adc status  after switch //ctrl ext 24V---------------Newly added
	
	
// ***** outputs ****** //

		
		GPIO_Init(GPIOC, GPIO_PIN_5,GPIO_MODE_OUT_PP_LOW_FAST); // pulse current to pressure high
		GPIO_Init(GPIOC, GPIO_PIN_6,GPIO_MODE_OUT_PP_LOW_FAST); // pulse current to pressure low
	
		GPIO_Init(GPIOA, GPIO_PIN_6,GPIO_MODE_OUT_PP_LOW_FAST); // Solanoid valve enable
		GPIO_Init(GPIOG, GPIO_PIN_1,GPIO_MODE_OUT_PP_LOW_FAST); // Solanoid valve disable
		
    GPIO_Init(GPIOD, GPIO_PIN_5,GPIO_MODE_OUT_PP_LOW_FAST); // UART2 TX LINE 
		GPIO_Init(GPIOD, GPIO_PIN_6,GPIO_MODE_IN_PU_NO_IT);     // UART2 RX LINE
		GPIO_Init(GPIOD, GPIO_PIN_7,GPIO_MODE_OUT_PP_LOW_FAST); // for testing
			
		GPIO_Init(MO_SCADA_PORT,MO_SCADA_GPIO,GPIO_MODE_OUT_PP_LOW_FAST);   // Common falult to scada
		GPIO_Init(HP_SCADA_PORT,HP_SCADA_GPIO, GPIO_MODE_OUT_PP_LOW_FAST);  // 24V status to scada--------Newly added
		GPIO_Init(LP_SCADA_PORT,LP_SCADA_GPIO,GPIO_MODE_OUT_PP_LOW_FAST);  // LP SCADA
		GPIO_Init(GPIOB, GPIO_PIN_0,GPIO_MODE_OUT_PP_LOW_FAST);  // Power suppy fault to scada
	  GPIO_Init(CF_SCADA_PORT, CF_SCADA_GPIO,GPIO_MODE_OUT_PP_LOW_FAST ); //CF SCADA 

    GPIO_Init(GPIOB, GPIO_PIN_1,GPIO_MODE_OUT_PP_LOW_FAST); // for testing
		
		GPIO_Init(GPIOD, GPIO_PIN_7,GPIO_MODE_OUT_PP_LOW_FAST); // ctrl_24v
		GPIO_Init(GPIOA, GPIO_PIN_4,GPIO_MODE_OUT_PP_LOW_FAST); // ctrl 3.6v
		GPIO_Init(GPIOA, GPIO_PIN_3,GPIO_MODE_OUT_PP_LOW_FAST); // ref_ctrl
		GPIO_Init(GPIOG, GPIO_PIN_0,GPIO_MODE_OUT_PP_LOW_FAST); // Diagnostic LED
		
		GPIO_Init(GPIOC, GPIO_PIN_1,GPIO_MODE_OUT_PP_LOW_FAST ); //ESD/SCADA LED
		GPIO_Init(GPIOC, GPIO_PIN_2,GPIO_MODE_OUT_PP_LOW_FAST ); //System normal led
		GPIO_Init(GPIOC, GPIO_PIN_3,GPIO_MODE_OUT_PP_LOW_FAST ); //Manual override led
		GPIO_Init(GPIOC, GPIO_PIN_4,GPIO_MODE_OUT_PP_LOW_FAST ); //Low Battery led
		GPIO_Init(GPIOD, GPIO_PIN_3,GPIO_MODE_OUT_PP_LOW_FAST ); //High Pressure_led
		GPIO_Init(GPIOD, GPIO_PIN_4,GPIO_MODE_OUT_PP_LOW_FAST ); //Low Pressure led
		
		GPIO_Init(CF_LED_PORT,CF_LED_GPIO,GPIO_MODE_OUT_PP_LOW_FAST ); //external power 24V led---------Newly LED
    //GPIO_Init(GPIOC, GPIO_PIN_7,GPIO_MODE_OUT_PP_LOW_FAST ); //Battery status 24V led---------Newly added
} 

u32 LSIMeasurment(void)
{
  
  u32 lsi_freq_hz = 0x0;
  u32 fmaster = 0x0;
  u16 ICValue1 = 0x0;
  u16 ICValue2 = 0x0;

  /* Get master frequency */
  fmaster = CLK_GetClockFreq();

  /* Enable the LSI measurement: LSI clock connected to timer Input Capture 1 */
  AWU->CSR |= AWU_CSR_MSR;

#if defined (STM8S903) || defined (STM8S103)
  /* Measure the LSI frequency with TIMER Input Capture 1 */
  
  /* Capture only every 8 events!!! */
  /* Enable capture of TI1 */
	TIM1_ICInit(TIM1_CHANNEL_1, TIM1_ICPOLARITY_RISING, TIM1_ICSELECTION_DIRECTTI, TIM1_ICPSC_DIV8, 0);
	
  /* Enable TIM1 */
  TIM1_Cmd(ENABLE);
  
  /* wait a capture on cc1 */
  while((TIM1->SR1 & TIM1_FLAG_CC1) != TIM1_FLAG_CC1);
  /* Get CCR1 value*/
  ICValue1 = TIM1_GetCapture1();
	//printf("ICValue1 is %u\r\n,  ICValue1");
  TIM1_ClearFlag(TIM1_FLAG_CC1);
  
  /* wait a capture on cc1 */
  while((TIM1->SR1 & TIM1_FLAG_CC1) != TIM1_FLAG_CC1);
  /* Get CCR1 value*/
  ICValue2 = TIM1_GetCapture1();
	//printf("ICValue2 is %u\r\n,  ICValue2");
  TIM1_ClearFlag(TIM1_FLAG_CC1);
  
  /* Disable IC1 input capture */
  TIM1->CCER1 &= (u8)(~TIM1_CCER1_CC1E);
  /* Disable timer2 */
  TIM1_Cmd(DISABLE);
  
#else  
  /* Measure the LSI frequency with TIMER Input Capture 1 */
  
  /* Capture only every 8 events!!! */
  /* Enable capture of TI1 */
  TIM3_ICInit(TIM3_CHANNEL_1, TIM3_ICPOLARITY_RISING, TIM3_ICSELECTION_DIRECTTI, TIM3_ICPSC_DIV8, 0);

  /* Enable TIM3 */
  TIM3_Cmd(ENABLE);

	/* wait a capture on cc1 */
  while ((TIM3->SR1 & TIM3_FLAG_CC1) != TIM3_FLAG_CC1);
	/* Get CCR1 value*/
  ICValue1 = TIM3_GetCapture1();
	//printf("TIM3 ICValue1 is %u\r\n,  ICValue1");
  TIM3_ClearFlag(TIM3_FLAG_CC1);

  /* wait a capture on cc1 */
  while ((TIM3->SR1 & TIM3_FLAG_CC1) != TIM3_FLAG_CC1);
    /* Get CCR1 value*/
  ICValue2 = TIM3_GetCapture1();
	//printf("TIM3 ICValue2 is %u\r\n,  ICValue2");
	TIM3_ClearFlag(TIM3_FLAG_CC1);

  /* Disable IC1 input capture */
  TIM3->CCER1 &= (u8)(~TIM3_CCER1_CC1E);
  /* Disable timer3 */
  TIM3_Cmd(DISABLE);
#endif

  /* Compute LSI clock frequency */
  lsi_freq_hz = (8 * fmaster) / (ICValue2 - ICValue1);
  
  /* Disable the LSI measurement: LSI clock disconnected from timer Input Capture 1 */
  AWU->CSR &= (u8)(~AWU_CSR_MSR);
  return (lsi_freq_hz);
 
}
static void Solanoid_On(void)
{
	Solanoid_delay=10;
	solanoid_off_pos=0;
	GPIO_WriteHigh(GPIOA, GPIO_PIN_6);
	//Delay(50);
	User_Delay(25);
	GPIO_WriteLow(GPIOA, GPIO_PIN_6);
	GPIO_WriteLow(GPIOG, GPIO_PIN_1);
}
static void Solanoid_Off(void)
{
	Solanoid_delay=10;
	solanoid_off_pos=1;
	GPIO_WriteLow(GPIOA, GPIO_PIN_6);
	GPIO_WriteHigh(GPIOG, GPIO_PIN_1);
	//Delay(50);
	User_Delay(25);
	GPIO_WriteLow(GPIOG, GPIO_PIN_1);
}
static void Read_Status(void)
{
	
	GPIO_WriteHigh(GPIOC, GPIO_PIN_5);
	GPIO_WriteHigh(GPIOC, GPIO_PIN_6);
	
	for(i=0;i<1024;i++);
	
	Pressure_High = GPIO_ReadInputPin(GPIOB,GPIO_PIN_4);
	printf("Pressure_High  = %u\r\n", Pressure_High);
	Preasure_Low  = GPIO_ReadInputPin(GPIOB,GPIO_PIN_3);
	printf("Preasure_Low  = %u\r\n", Preasure_Low);
	ESD_scada = GPIO_ReadInputPin(GPIOE,GPIO_PIN_6);
	printf("ESD_scada  = %u\r\n", ESD_scada);
	
	
	GPIO_WriteLow(GPIOC, GPIO_PIN_5);
	GPIO_WriteLow(GPIOC, GPIO_PIN_6);
	
	
}
static void System_shutdown(void)
{
		hp_var = 0;
		lp_var = 0;
		mo_var = 0;
		lb_var = 0;
		sn_var = 0;
		esd_var = 0;
	  //if(cf_var_stable==1){}
	  //else{cf_var = 0;}
		
		cf_var = 0;
		printf("sn_var 0 = %d\r\n",	sn_var);
		printf("hp_var 0 = %d\r\n",hp_var);
		printf("lp_var 0 = %d\r\n",	lp_var);
		printf("lb_var 0 = %d\r\n",	lb_var);
		printf("mo_var 0 = %d\r\n",	mo_var);
		printf("mo_var 0 = %d\r\n",	mo_var);
			
}

static void Test_LED(void)
{
	
	System_Normal_led();
	User_Delay(50);
	System_Normal_led();
	User_Delay(50);
	System_Normal_led();
	User_Delay(50);
	System_Normal_led();
	User_Delay(50);
	
	Low_Battery_led();
	User_Delay(50);
	Low_Battery_led();
	User_Delay(50);
	Low_Battery_led();
	User_Delay(50);
	Low_Battery_led();
	User_Delay(50);
	
	Low_Pressure_led();
	User_Delay(50);
	Low_Pressure_led();
	User_Delay(50);
	Low_Pressure_led();
	User_Delay(50);
	Low_Pressure_led();
	User_Delay(50);
	
	High_Pressure_led();
	User_Delay(50);
	High_Pressure_led();
	User_Delay(50);
	High_Pressure_led();
	User_Delay(50);
	High_Pressure_led();
	User_Delay(50);
	
	Esd_Scada_led();
  User_Delay(50);
	Esd_Scada_led();
  User_Delay(50);
	Esd_Scada_led();
  User_Delay(50);
	Esd_Scada_led();
  User_Delay(50);
	
	Manual_Override_led();
	User_Delay(50);
	Manual_Override_led();
	User_Delay(50);
	Manual_Override_led();
	User_Delay(50);
	Manual_Override_led();
	User_Delay(50);

	Common_fault_led();
	User_Delay(50);
	Common_fault_led();
	User_Delay(50);
	Common_fault_led();
	User_Delay(50);
	Common_fault_led();
	User_Delay(50);
}

//Newly added

static void ADC_CH1(void)
{
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	ADC1_DeInit();
	  

	ADC1_Init(ADC1_CONVERSIONMODE_SINGLE , ADC1_CHANNEL_1, ADC1_PRESSEL_FCPU_D18, \
            ADC1_EXTTRIG_GPIO, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL1,\
            DISABLE);
						
	ADC1_Cmd(ENABLE);
	ADC1_StartConversion();
	while(ADC1_GetFlagStatus(ADC1_FLAG_EOC) == FALSE);
		 
	
	A1 = ADC1_GetConversionValue();
	ADC1_ClearFlag(ADC1_FLAG_EOC);
	printf("Adc_Buffer 1 = %u\r\n", A1 );
	ADC1_Cmd(DISABLE);
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, DISABLE);
	ADC1_DeInit();
		
}
/*
static void ADC_CH2(void)
{
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	ADC1_DeInit();
	ADC1_Init(ADC1_CONVERSIONMODE_SINGLE , ADC1_CHANNEL_2, ADC1_PRESSEL_FCPU_D18, \
            ADC1_EXTTRIG_GPIO, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL2,\
            DISABLE);
						
	ADC1_Cmd(ENABLE);
	ADC1_StartConversion();
	while(ADC1_GetFlagStatus(ADC1_FLAG_EOC) == FALSE);
		 

	A2 = ADC1_GetConversionValue();
	ADC1_ClearFlag(ADC1_FLAG_EOC);
	printf("Adc_Buffer 2 = %u\r\n", A2);
	ADC1_Cmd(DISABLE);
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, DISABLE);
	ADC1_DeInit();
	
		
}*/

static void ADC_CH6(void)
{
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	ADC1_DeInit();
	ADC1_Init(ADC1_CONVERSIONMODE_SINGLE , ADC1_CHANNEL_6, ADC1_PRESSEL_FCPU_D18, \
            ADC1_EXTTRIG_GPIO, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL6,\
            DISABLE);
						
	ADC1_Cmd(ENABLE);
	ADC1_StartConversion();
	while(ADC1_GetFlagStatus(ADC1_FLAG_EOC) == FALSE);
		 

	A6 = ADC1_GetConversionValue();
	ADC1_ClearFlag(ADC1_FLAG_EOC);
	printf("Adc_Buffer 6 = %u\r\n", A6);
	ADC1_Cmd(DISABLE);
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, DISABLE);
	ADC1_DeInit();
	
		
}


static void ADC_CH7(void)
{
	unsigned int A7_average = 0x0000;
	int average;
 for(average=0;average<30;average++)
 {
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	ADC1_DeInit();
	
	ADC1_Init(ADC1_CONVERSIONMODE_SINGLE , ADC1_CHANNEL_7, ADC1_PRESSEL_FCPU_D2, \
            ADC1_EXTTRIG_GPIO, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL7,\
            DISABLE);
						
	ADC1_Cmd(ENABLE);
	ADC1_StartConversion();
	while(ADC1_GetFlagStatus(ADC1_FLAG_EOC) == FALSE);
	
	A7_average += ADC1_GetConversionValue();

	//A7=ADC1_GetConversionValue();
	ADC1_ClearFlag(ADC1_FLAG_EOC);
	ADC1_Cmd(DISABLE);
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, DISABLE);
	ADC1_DeInit();
}	
	A7=A7_average/30;
	printf("Adc_Buffer 7 = %u\r\n", A7 );
		
}
static void ADC_CH8(void)
{
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, ENABLE);
	ADC1_DeInit();
	  

	ADC1_Init(ADC1_CONVERSIONMODE_SINGLE , ADC1_CHANNEL_8, ADC1_PRESSEL_FCPU_D18, \
            ADC1_EXTTRIG_GPIO, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL8,\
            DISABLE);
						
	ADC1_Cmd(ENABLE);
	ADC1_StartConversion();
	while(ADC1_GetFlagStatus(ADC1_FLAG_EOC) == FALSE);

		 
	
	A8 = ADC1_GetConversionValue();
	ADC1_ClearFlag(ADC1_FLAG_EOC);
	printf("Adc_Buffer 8 = %u\r\n", A8);
	ADC1_Cmd(DISABLE);
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_ADC, DISABLE);
	ADC1_DeInit();
	
}

static void High_Pressure_led(void)
{
	GPIO_WriteHigh(GPIOD, GPIO_PIN_3);
  User_Delay(2);
	GPIO_WriteLow(GPIOD, GPIO_PIN_3);

}

static void Low_Pressure_led(void)
{
	GPIO_WriteHigh(GPIOD, GPIO_PIN_4);
  User_Delay(2);
	GPIO_WriteLow(GPIOD, GPIO_PIN_4); 

}

static void Esd_Scada_led(void)
{
  GPIO_WriteHigh(GPIOC, GPIO_PIN_1);
  User_Delay(2);
	GPIO_WriteLow(GPIOC, GPIO_PIN_1); 

}

static void System_Normal_led(void)
{
  GPIO_WriteHigh(GPIOC, GPIO_PIN_2);
  User_Delay(2);
	GPIO_WriteLow(GPIOC, GPIO_PIN_2);

}

static void Manual_Override_led(void)
{
  GPIO_WriteHigh(GPIOC, GPIO_PIN_3);
  User_Delay(2);
	GPIO_WriteLow(GPIOC, GPIO_PIN_3);

}
static void Low_Battery_led(void)
{
  GPIO_WriteHigh(GPIOC, GPIO_PIN_4);
  User_Delay(2);
	GPIO_WriteLow(GPIOC, GPIO_PIN_4);

}

static void Common_fault_led()
{
	GPIO_WriteHigh(CF_LED_PORT, CF_LED_GPIO);
	User_Delay(2);
	GPIO_WriteLow(CF_LED_PORT, CF_LED_GPIO);
}

/**
  * @brief  Configure UART1 for the communication with HyperTerminal
  * @param  None
  * @retval None
  */

static void UART2_Config(void)
{
  /* EVAL COM (UART) configuration -----------------------------------------*/
  /* USART configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - Odd parity
        - Receive and transmit enabled
        - UART Clock disabled
  */
	
 UART2_Init((uint32_t)115200, UART2_WORDLENGTH_8D,UART2_STOPBITS_1, UART2_PARITY_NO, UART2_SYNCMODE_CLOCK_DISABLE,                                                                 UART2_MODE_TXRX_ENABLE);
 

  /* Enable UART */
  UART2_Cmd(ENABLE);
}

/**
  * @brief Retargets the C library printf function to the UART.
  * @param c Character to send
  * @retval char Character sent
  */
PUTCHAR_PROTOTYPE
{
  /* Write a character to the UART1 */
  UART2_SendData8(c);
  /* Loop until the end of transmission */
  while (UART2_GetFlagStatus(UART2_FLAG_TXE) == RESET);

  return (c);
}

void User_Delay(uint32_t Time)
{
  for(loop = 0; loop < Time ; loop++)
	{
		for(delay_var=0;delay_var<1460;delay_var++);
		IWDG_ReloadCounter();
  }
}
