/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */


uint8_t  rx_data;
uint8_t rx_index = 0;


#define RxBuf_SIZE   30

uint8_t RxBuf[RxBuf_SIZE];

//uint8_t hexData[] = {0x00, 0x05, 0x03, 0x01, 0x02, 0x03, 0x04};
//uint8_t hello[] = {0x00, 0x01, 0x13};
uint8_t hexData[] = {0x00, 0xf3, 0x03, 0x41, 0x20, 0x55, 0x48, 0x46, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65, 0x2c, 0x20, 0x73, 0x68, 0x6f, 0x72, 0x74, 0x66, 0x6f, 0x72, 0x20, 0x55, 0x6c, 0x74,
		0x72, 0x61, 0x2d, 0x48, 0x69, 0x67, 0x68, 0x20, 0x46, 0x72, 0x65, 0x71, 0x75, 0x65, 0x6e, 0x63, 0x79, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65, 0x2c, 0x20, 0x69, 0x73, 0x20,
		0x61, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x65, 0x6c, 0x65, 0x63, 0x74, 0x72, 0x6f, 0x6e, 0x69, 0x63, 0x20, 0x64, 0x65, 0x76, 0x69, 0x63, 0x65, 0x20, 0x63,
		0x6f, 0x6d, 0x6d, 0x6f, 0x6e, 0x6c, 0x79, 0x20, 0x75, 0x73, 0x65, 0x64, 0x20, 0x69, 0x6e, 0x20, 0x77, 0x69, 0x72, 0x65, 0x65, 0x73, 0x73, 0x20, 0x63, 0x6f, 0x6d, 0x6d,
		0x75, 0x6e, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x73, 0x2e, 0x20, 0x55, 0x48, 0x46, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65,
		0x73, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x65, 0x20, 0x69, 0x6e, 0x20, 0x74, 0x68, 0x65, 0x20, 0x66, 0x72, 0x65, 0x71, 0x75, 0x65, 0x6e, 0x63, 0x79, 0x20, 0x72, 0x61, 0x6e,
		0x67, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x33, 0x30, 0x30, 0x20, 0x4d, 0x48, 0x7a, 0x20, 0x74, 0x6f, 0x20, 0x33, 0x20, 0x47, 0x48, 0x7a, 0x2c, 0x20, 0x6d, 0x61, 0x6b, 0x69, 0x6e,
		0x67, 0x20, 0x74, 0x68, 0x65, 0x6d, 0x20, 0x69, 0x64, 0x65, 0x61, 0x6c, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x6c, 0x6f, 0x6e, 0x67, 0x2d, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x20, 0x63,
		0x6f, 0x6d, 0x6d, 0x75, 0x6e, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x2e};

//uint8_t hexData[] = {0x00, 0x01, 0x1b};

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_UART5_Init();
  /* USER CODE BEGIN 2 */

  //interrupt();

  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_4, GPIO_PIN_RESET);

  uint8_t status = 0;

  status = HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_4);

  if(status  == 0)
  {
	  HAL_UART_Transmit(&huart2, hexData, sizeof(hexData), 1000);
  //HAL_UART_Transmit(&huart2, hello, sizeof(hello), 1000);
  }
//  HAL_UART_Receive_IT(&huart2, &RxBuf[rx_index], 1);
  //HAL_UART_Receive_IT(&huart2, &rx_data,1);

//  HAL_UART_Transmit(&huart5, RxBuf, sizeof(RxBuf), 100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance==USART2)
	{
		//HAL_UART_Transmit(&huart5,"Hello",5,100);
//#if 0
		//if(rx_data == '\0' || rx_data == '\n' || rx_data == 'R' || rx_data == '0')
		//if(rx_data == 0x00)
//		if(rx_index > 15)
//		{
//			HAL_UART_Transmit(&huart5,"if",2,100);
//			RxBuf[rx_index++]= 'T';
//			HAL_UART_Transmit(&huart5,RxBuf,rx_index,100);
//			memset(RxBuf,0,sizeof(RxBuf));
//			//HAL_UART_Transmit(&huart5,"if",5,100);
//
//		}
//		else
//#endif
		{
			//HAL_UART_Transmit(&huart5,"else",5,100);
			//int i = 0;
			//HAL_UART_Transmit(huart, RxBuf, rx_index, 100);
			RxBuf[rx_index++] = rx_data;
			HAL_UART_Transmit(&huart5,&rx_data,1,100);
			//HAL_UART_Transmit(huart, RxBuf, 10, 100);
//			HAL_UART_Transmit(&huart5,"\n",1,100);

		}
		HAL_UART_Receive_IT(&huart2, &rx_data,1); //receive data one character only
	}
}

//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
// /* Prevent unused argument(s) compilation warning */
// UNUSED(huart);
// /* NOTE: This function should not be modified, when the callback is needed,
//          the HAL_UART_RxCpltCallback could be implemented in the user file
//  */
// uint8_t i;
// 	 if(huart->Instance == USART2)
// 	 {
// 		 if(rx_index == 0)
// 		 {
// 			 for(i=0; i<100; i++)
// 			 {
// 				 RxBuf[i] = 0;
// 				 HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_RESET);
// 			 }
//
// 			 if(rx_data[0] != 13)
// 			 {
// 				 RxBuf[rx_index++] = rx_data[0];
// 			 }
// 			 else
// 				 rx_index =0;
//
// 			Transfer_cplt = 1;
// 			HAL_UART_Transmit(&huart2, "\n\r", 2, 100);
// 			if(!strcmp(RxBuf, "LED ON"))
// 			{
// 				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, GPIO_PIN_SET);
// 			}
// 		 }
//
// 		 HAL_UART_Receive_IT(&huart2, rx_data, 30);
// 		HAL_UART_Transmit(&huart5, rx_data, strlen(rx_data), 100);
// 	 }
//}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
