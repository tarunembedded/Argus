///* USER CODE BEGIN Header */
///**
//  ******************************************************************************
//  * @file    RxevetCB.c
//  * @brief   This file provides code for the configuration
//  *          of RxeventCB.h
//  ******************************************************************************
//  * @attention
//  *
//  * Copyright (c) 2023 STMicroelectronics.
//  * All rights reserved.
//  *
//  * This software is licensed under terms that can be found in the LICENSE file
//  * in the root directory of this software component.
//  * If no LICENSE file comes with this software, it is provided AS-IS.
//  *
//  ******************************************************************************
//  */
///* USER CODE END Header */
//
///* Includes ------------------------------------------------------------------*/
//#include "interrupt.h"
//#include "usart.h"
//
//uint8_t  rx_data;
//uint8_t rx_index = 0;
//
//#define RxBuf_SIZE   30
//
//uint8_t RxBuf[RxBuf_SIZE];
//
//uint8_t hexData[] = {0x00, 0x01, 0x1b};
//
///* USER CODE BEGIN 0 */
//
//void interrupt(void)
//{
//	HAL_UART_Transmit(&huart2, hexData, sizeof(hexData), 1000);
//
//	HAL_UART_Receive_IT(&huart2, &rx_data,1);
//}
//
////void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
////{
////	if(huart->Instance==USART2)
////	{
////			RxBuf[rx_index++] = rx_data;
////			HAL_UART_Transmit(&huart5,&rx_data,1,100);
//////			HAL_UART_Transmit(&huart5,"\n",1,100);
////
////		HAL_UART_Receive_IT(&huart2, &rx_data,1); //receive data one character only
////	}
////}
//
///* USER CODE END 0 */
