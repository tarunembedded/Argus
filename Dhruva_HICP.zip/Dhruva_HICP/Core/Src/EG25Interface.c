/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    EG25Interface.c
  * @brief   This file provides code for the configuration
  *          of all used EG25Interface.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "EG25Interface.h"		//(User defined header file) This header file used to access EG25Interface.c file
#include "stm32l4xx_hal_uart.h"
#include "usart.h"


__IO	tEG25Interface EG25Interface;

__IO char EG25_DebugBuffer[1026];
extern volatile uint32_t AftersendTimer;
void dumpPacket(char* buffer,int count)
{
  int i;
  int len = 0;
  if(count > 255) count = 255; 			// For Buffer Overflow
  for(i=0;i<count;i++) {
    len += sprintf((char*)&EG25_DebugBuffer[len],"%02x ",buffer[i]);
  }
}

void  CUSTOM_UART_INTERRUPT_INIT()
 {
	uint8_t UART2_rxBuffer[1] = {0};
  if(HAL_UART_Receive_IT(&huart2, UART2_rxBuffer, 1) != HAL_OK)
  {
    while(1)
    {
    }
  }
 }
/*----------------------------------------------------------------------------
  Name        :	EG25InterfaceHandler
  Description : select the InterfaceType of the Host Interface
  Arguments   : count
  Returns     : None
  Notes       :
-----------------------------------------------------------------------------*/

void EG25InterfaceHandler(uint8_t count)
 {
   EG25Interface.TxPointer  = 0;
   EG25Interface.TxCount = count;
   HAL_UART_Transmit(&huart2, EG25Interface.RawTxBuffer, count, 100);
//   HAL_UART_Transmit(&huart3, EG25Interface.RawTxBuffer, count, 100);
   EG25Interface.RxCount = 0;
 }

/*---------------------------------------------------------------------------
  Name        :	EG25InterfaceISR
  Description : Handles the USARTESP Interface Interrupt
  Arguments   : Base Address of the Interface
  Returns     : None
  Notes       :
-----------------------------------------------------------------------------*/
#if 0
void EG25InterfaceISR (UART_HandleTypeDef *huart)
  {
     volatile unsigned int IIR;
     IIR = huart->Instance->ISR;
     if (IIR & UART_FLAG_RXNE)
       {                  // Check for Rx interrupt
          huart->Instance->ISR &= ~UART_FLAG_RXNE;	         // clear RXNE interrupt
          EG25Interface.EOP_Timer = 2000;
          if (EG25Interface.RxPointer < EG25_INTERFACE_MAX_LEN_RX)
             {
                EG25Interface.RawRxBuffer[EG25Interface.RxPointer] = huart->Instance->RDR;
	            EG25Interface.RxPointer++;
                EG25Interface.RxCount++;
	         }
       }
  }
#endif







