/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    log.c
  * @brief   This file provides code for the configuration
  *          of all used to print the logs.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "stm32l4xx_hal.h"
#include "log.h"			//(User defined header file) This header file used to access log.c file

extern UART_HandleTypeDef huart3;

int _write(int file, char *ptr, int len)
{
  HAL_UART_Transmit(&huart3, (uint8_t *)ptr, len, 10);
  HAL_UART_Transmit(&huart3, (uint8_t *)"\r", 1, 10);

//#ifdef ENABLE_SWO
  for (int i = 0; i < len; i++) {
    ITM_SendChar(*ptr++);
  }
//#endif
  return len;
}


