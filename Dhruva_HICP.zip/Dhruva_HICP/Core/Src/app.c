/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app.c
  * @brief   This file provides code for the configuration
  *          of all used LoRa,UHF,GSM and SHT21 Sensor.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "app.h"							//(User defined header file) This header file used to access app.c file
#include "custom_led.h"						//(User defined header file) This header file used to access custom_led.c file
#include "sht2x_for_stm32_hal.h"			//(User defined header file) This header file used to access sht2x_for_stm32_hal.c file
#include "LoRa.h"							//(User defined header file) This header file used to access LoRa.c file
#include "log.h"							//(User defined header file) This header file used to access log.c file
#include "custom_adc.h"						//(User defined header file) This header file used to access custom_adc.c file
#include "custom_external_flash.h"			//(User defined header file) This header file used to access custom_external_flash.c file
#include "custom_internal_flash.h"			//(User defined header file) This header file used to access custom_internal_flash.c file
#include "custom_internal_flash.h"			//(User defined header file) This header file used to access custom_internal_flash.c file
#include "BQ24193.h"						//(User defined header file) This header file used to access BQ24193.c file

/*---------------------------LoRa Variables---------------------------*/
LoRa myLoRa;
uint8_t read_data[128];
char* send_data;
char* RSSI[50];
uint8_t Transmit[100], hTransmit[100];
uint8_t read[30];
uint8_t packet[100];
uint8_t Receive[100];

/*--------------------------SHT21 Variables--------------------------------*/
volatile uint16_t tsize, hsize,l_size;
char tbuffer[50];
char hbuffer[50];
char Lora_buffer[50];
char server_buffer[50];
float cel,rh;

/*-------------------------GSM Module Variables-----------------------------*/
extern uint8_t test_var;
char startchar;
char cmd_AT[]="AT\r\n";
char recvBuff[10];
extern volatile uint8_t packet_handler,mqtt_pubx_cmds;

/*----------------------------Battery Variables-----------------------------*/
//uint8_t Bat_status_reg[4];
//HAL_StatusTypeDef ret;

/*------------------------Timer Variables-----------------------------------*/
volatile uint8_t  UHF_var = 1;
volatile uint8_t  GSM_var = 1;
volatile uint8_t  LoRa_var = 1;
volatile uint8_t  SHT21_var = 1;
volatile int UHF_Timer;
volatile int GSM_Timer;
volatile int LoRa_Timer;
volatile int SHT21_Timer;


//volatile uint8_t Temp_Data[245] = {0x00,0xf3,0x03,0x53,0x48,0x54,0x32,0x31,0x20,0x53,0x65,0x6E,0x73,0x6F,0x72,0x20,0x44,0x61,0x74,0x61,0x3a};

uint8_t hexData[] = {0x00, 0xf3, 0x03, 0x41, 0x20, 0x55, 0x48, 0x46, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65, 0x2c, 0x20, 0x73, 0x68, 0x6f, 0x72, 0x74, 0x66, 0x6f, 0x72, 0x20, 0x55, 0x6c, 0x74,
  		  		0x72, 0x61, 0x2d, 0x48, 0x69, 0x67, 0x68, 0x20, 0x46, 0x72, 0x65, 0x71, 0x75, 0x65, 0x6e, 0x63, 0x79, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65, 0x2c, 0x20, 0x69, 0x73, 0x20,
  		  		0x61, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x65, 0x6c, 0x65, 0x63, 0x74, 0x72, 0x6f, 0x6e, 0x69, 0x63, 0x20, 0x64, 0x65, 0x76, 0x69, 0x63, 0x65, 0x20, 0x63,
  		  		0x6f, 0x6d, 0x6d, 0x6f, 0x6e, 0x6c, 0x79, 0x20, 0x75, 0x73, 0x65, 0x64, 0x20, 0x69, 0x6e, 0x20, 0x77, 0x69, 0x72, 0x65, 0x65, 0x73, 0x73, 0x20, 0x63, 0x6f, 0x6d, 0x6d,
  		  		0x75, 0x6e, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x79, 0x73, 0x74, 0x65, 0x6d, 0x73, 0x2e, 0x20, 0x55, 0x48, 0x46, 0x20, 0x6d, 0x6f, 0x64, 0x75, 0x6c, 0x65,
  		  		0x73, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x65, 0x20, 0x69, 0x6e, 0x20, 0x74, 0x68, 0x65, 0x20, 0x66, 0x72, 0x65, 0x71, 0x75, 0x65, 0x6e, 0x63, 0x79, 0x20, 0x72, 0x61, 0x6e,
  		  		0x67, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x33, 0x30, 0x30, 0x20, 0x4d, 0x48, 0x7a, 0x20, 0x74, 0x6f, 0x20, 0x33, 0x20, 0x47, 0x48, 0x7a, 0x2c, 0x20, 0x6d, 0x61, 0x6b, 0x69, 0x6e,
  		  		0x67, 0x20, 0x74, 0x68, 0x65, 0x6d, 0x20, 0x69, 0x64, 0x65, 0x61, 0x6c, 0x20, 0x66, 0x6f, 0x72, 0x20, 0x6c, 0x6f, 0x6e, 0x67, 0x2d, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x20, 0x63,
  		  		0x6f, 0x6d, 0x6d, 0x75, 0x6e, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x2e};

const char* memory_location = "Humidity: ";

/*--------------------------Internal flash variables----------------------- */
 char *data = "Welcome_HICP";
//char *data = "SIGN";
 char *RTC_SIGN;
 uint32_t data2[] = {0x1,0x2,0x3,0x4,0x5,0x6,0x7,0x8,0x9};
 uint32_t Rx_Data[30];
 char string[100];
 int number = 123;
float val = 123.456;
float RxVal;

/* ----------------------------------------------------------------------------- *\
		name        : GET_SHT21_DATA
		description : Collecting the SHT21 sensor data
		arguments   : Nothing
		returns     : Nothing
\* ----------------------------------------------------------------------------- */
void GET_SHT21_DATA()
{
/*------------ Gets current temperature & relative humidity.----------------------- */
		 	cel = SHT2x_GetTemperature(1);
/*--------- Converts temperature to degrees Fahrenheit and Kelvin-------------------- */
		 	rh = SHT2x_GetRelativeHumidity(1);
//          tsize=0;
//          hsize=0;
/*------------ May show warning below. Ignore and proceed. -----------------------------*/
		 	tsize = sprintf(tbuffer,"%d.%d C",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1));
		 	hsize = sprintf(hbuffer,"%d.%d% RH",SHT2x_GetInteger(rh), SHT2x_GetDecimal(rh, 1));
//			tsize = sprintf(server_buffer,"Temp: %d.%d C, Hmdt: %d.%d RH ",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1));
		 	 //HAL_Delay(1000);
		 	LOG("\r\ntemp:%d.%d,hmdt:%d.%d\r\n",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1));
}

/* ----------------------------------------------------------------------------- *\
		name        : CUSTOM_UHF
		description : Transmitting sensor data via UHF Module
		arguments   : Nothing
		returns     : Nothing
\* ----------------------------------------------------------------------------- */
void CUSTOM_UHF()
{
#if 0
	sprintf(server_buffer,"Temp: %d.%d C, Hmdt: %d.%d RH ",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1));
	for(int i = 16; i<20; i++)
	{
		Temp_Data[i] = '\0';
	}
	for (int i = 20,j = 0; i<50; i++,j++)
	{
		Temp_Data[i] = server_buffer[j];
	}

	for (int i=50; i<245; i++)
	{
		Temp_Data[i] = '\0';
	}
	volatile uint8_t Temp_Data[243] = {0x00,0xf3,0x03,0x54,0x65,0x6d,0x70,0x65,0x72,0x61,0x74,0x75,0x72,0x65,0x3a,0x20};
	for (uint8_t i = 16,j = 0; i<(tsize+16); i++,j++)
		 {
		 		Temp_Data[i] = tbuffer[j];
		 }
	for (uint8_t i = (tsize+16); i<(tsize+16+5); i++)
		 {
		 		Temp_Data[i] = 'X';
		 }

/*----- Calculate the starting index in Temp_Data where you want to copy the string-----*/
	uint8_t start_index = tsize+16+5;
	for (uint8_t i = 0; memory_location[i] != '\0'; i++)
		{
		 		Temp_Data[start_index + i] = (uint8_t)memory_location[i];
		}
	for (uint8_t i = tsize+16+5+10,j = 0; i<(hsize+tsize+16+5+10); i++,j++)
	    {
		 		Temp_Data[i] = hbuffer[j];
		}
	for(uint8_t i = 30; i<243; i++)
		{
		 		Temp_Data[i] = 'X';
		}

#endif

//HAL_UART_Transmit(&huart1, hexData, sizeof(hexData), 1000);
//HAL_UART_Transmit(&huart3, hexData, sizeof(hexData), 1000);

//#if 0
	  uint8_t Temp_Data[245] = {0x00,0xf3,0x03,0x54,0x65,0x6d,0x70,0x65,0x72,0x61,0x74,0x75,0x72,0x65,0x3a,0x20};
	  for (uint8_t i = 16,j = 0; i<(tsize+16); i++,j++)
	  {
		  Temp_Data[i] = tbuffer[j];
	  }
	  for (uint8_t i = strlen(tbuffer)+16; i<25; i++)
	  {
		  Temp_Data[i] = '\0';
	  }
//	   int start_index = 25;
	  for (uint8_t i = 0; memory_location[i] != '\0'; i++)
	   {
	      Temp_Data[25 + i] = (uint8_t)memory_location[i];
	   }
	  for (uint8_t i = 35,j = 0; i<(hsize+35); i++,j++)
	  {
		  Temp_Data[i] = hbuffer[j];
	  }
	  for(uint8_t i = strlen(hbuffer)+35; i<245; i++)
	  {
		  Temp_Data[i] = '\0';
	  }
//	for(uint8_t i = 0;i<243;i++){printf("%c",Temp_Data[i]);}
//	printf("\r\n");
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
//	HAL_Delay(10);
//	uint8_t status = 0;
//	status = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8);
//	if(status == 0)
//		{
			HAL_Delay(10);
		 	HAL_UART_Transmit(&huart1, Temp_Data, sizeof(Temp_Data), 1000);
//		 	HAL_UART_Transmit(&huart3, Temp_Data, sizeof(Temp_Data),1000);
//#endif
//		 	HAL_UART_Transmit(&huart1, &Temp_Data, 245, HAL_MAX_DELAY);
		 	LOG("\r\nUHF Data Sent\r\n");
//			HAL_Delay(10);
//			HAL_UART_Transmit(&huart1, hexData, sizeof(hexData), 1000);
//		 	printf("UHF Data Sent\n");
//			for(uint8_t i = 0;i<245;i++){printf("%c",hexData[i]);}
//			printf("\r\n");
//		 	HAL_UART_Transmit(&huart2, hexData, sizeof(hexData), 1000);
//		 	memset(Temp_Data,0,sizeof(Temp_Data));
//		 	HAL_Delay(7000);
//			HAL_Delay(10);
//			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
//			memset(Temp_Data,0,sizeof(Temp_Data));			// memset of temp Data
//			HAL_Delay(10);
//			HAL_Delay(2000);
//		}
}

/* ----------------------------------------------------------------------------- *\
		name        : CUSTOM_GSM
		description : Transmitting sensor data via EG25_G Module
		arguments   : Nothing
		returns     : Nothing
\* ----------------------------------------------------------------------------- */
void CUSTOM_GSM()
{
//	if(mqtt_pubx_cmds == 18)
//		 {
//		 	sprintf(server_buffer,"Temp:%d.%dC,Hmdt:%d.%dRH,%s",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1),(char *)RSSI);
//		 			//printf("SERVER BUFFER : %s\r\n",server_buffer);
//		 }
		if(EG25Interface.TxInterfaceEvent == 1)
		  {
			  EG25Interface.TxInterfaceEvent = 0;
			  EG25InterfaceHandler(EG25Interface.TxCount);
			  memset((char*)EG25Interface.RawTxBuffer,0,sizeof(EG25Interface.RawTxBuffer));
		  }
	  if(EG25Interface.RxInterfaceEvent == 1)
		  {
//			  HAL_UART_Transmit(&huart3,server_buffer, strlen(server_buffer), 100);
			  EG25Interface.RxInterfaceEvent = 0;
			  dumpPacket((char*)EG25Interface.RawRxBuffer,EG25Interface.RxCount);
			  EG25_Packet_Handler();
			  EG25Interface.RxPointer = 0;
			  EG25Interface.RxCount = 0;
			  memset((char*)EG25Interface.RawRxBuffer,0,sizeof(EG25Interface.RawRxBuffer));
		  }
}

/* ----------------------------------------------------------------------------- *\
		name        : CUSTOM_LoRa
		description : Transmitting and Receiving the sensor data via LoRa Module
		arguments   : Nothing
		returns     : Nothing
\* ----------------------------------------------------------------------------- */
void CUSTOM_LoRa()
	{
//#if 0
/*-----------------LoRa TRANSMITTER for SHT21 Sensor Data------------------------*/
	l_size = sprintf(Lora_buffer,"Temperature: %d.%d C, Humidity: %d.%d RH\r\n",SHT2x_GetInteger(cel), SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1));
//	HAL_UART_Transmit(&huart3, Lora_buffer, strlen(Lora_buffer), 100);
//	sprintf(Transmit,"Temp:%d\r\n",LoRa_transmit(&myLoRa, Lora_buffer, l_size,1000));
	LOG("\r\nLoRa:%d\r\n",LoRa_transmit(&myLoRa, Lora_buffer, l_size,1000));
	memset(Lora_buffer,0,sizeof(Lora_buffer));
	memset(tbuffer,0,sizeof(tbuffer));
	memset(hbuffer,0,sizeof(hbuffer));
//#endif
/*---------------- LoRa RECEIVER for SHT21 Sensor Data----------------------------*/
#if 0
	if(LoRa_receive(&myLoRa, read_data, 128)!=0){
//  	  	sprintf(Receive,": %d\r\n",LoRa_receive(&myLoRa, read_data, 128));
//  		HAL_UART_Transmit(&huart3, Receive, sizeof(Receive), 100);
//  	  	LOG("\r\nLoRa Receiver: %d\r\n",Receive);
  	  	HAL_UART_Transmit(&huart3, read_data, strlen(read_data), 100);
//  	  		LOG("LoRa Receive data: %s\r\n",read_data);
  	  		memset(read_data,0,sizeof(read_data));
//  	  	memset(Receive,0,sizeof(Receive));
  	  		HAL_Delay(500);
	}
#endif
	}
volatile uint8_t Module = 1;

/* ----------------------------------------------------------------------------- *\
		name        : CUSTOM_APP
		description : this function perform will call required functions which will continuously running in while loop.
		arguments   : Nothing
		returns     : Nothing
\* ----------------------------------------------------------------------------- */
 void CUSTOM_APP(void)
 {
//	 HAL_StatusTypeDef result;
	 LED_TEST();
//	 set_time();
//	 get_time();
//	 GET_SHT21_DATA();
//	 CUSTOM_GSM();
//	 CUSTOM_LoRa();
//	 BATTERY_CHARGING_SENSING();

//#if 0
	 if(SHT21_var == 1)
	 {
//		 GET_SHT21_DATA();
//		 CUSTOM_UHF();

		 SHT21_Timer = 4000;
			switch(Module)
			{
				case 1: GET_SHT21_DATA();		//HAL_Delay(100);
						Module = 2;
						break;

				case 2: CUSTOM_UHF();			//HAL_Delay(100);
//					if(UHF_var == 1)
//					 	{
//							UHF_var = 0;
//							UHF_Timer = 3000;
//					 		CUSTOM_UHF();
//						}
						Module = 3;
						break;
				case 3: CUSTOM_LoRa();
						Module = 4;
						break;
//				case 4: get_time();
//										Module = 5;
//				case 5: CUSTOM_GSM();
						SHT21_var = 0;					//HAL_Delay(500);
//						Module = 1;
//						break;

				default : Module = 1;
						break;
			}
	 }
//#endif
#if 0
	 if(SHT21_var==1)
	 {
		 SHT21_var=0;
		 SHT21_Timer=4000;
		 GET_SHT21_DATA();
		 UHF_Timer=2000;
		 CUSTOM_UHF();
		 LoRa_Timer=3000;
		 CUSTOM_LoRa();
//		 GSM_Timer=1000;
//		 CUSTOM_GSM();
	 }
	#endif
	 CUSTOM_GSM();
//	#endif
//	CUSTOM_LoRa();
	 HAL_Delay(200);
}

 /* ----------------------------------------------------------------------------- *\
 		name        : Sht21_init
 		description : this function perform will call required functions which will continuously running in while loop.
 		arguments   : Nothing
 		returns     : Nothing
 \* ----------------------------------------------------------------------------- */
void Sht21_init()
{
	LOG("\r\n");
	LOG("Initailizing SHT21 Sensor I2C Interface\r\n");
   	SHT2x_Init(&hi2c2);
   	SHT2x_SetResolution(RES_14_12);
}

void BQ24193_Init()
{
	uint8_t Bat_status_reg[4];
	HAL_StatusTypeDef ret;

		LOG("\r\nInitializing Battery IC\r\n");

		ret = HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, Bat_status_reg, 1);
		if(ret != HAL_OK)
			 LOG_ERROR("NOT Initialized\r\n");
		else
			LOG_INFO("System Status Register: %x\r\n",Bat_status_reg[0]);

//		LOG("system_stat_reg %d",stat_data[0]);
//		HAL_Delay(100);
//		LOG_INFO("\r\nInitializing BATTERY_IC      ");
//			  ret = HAL_I2C_Master_Transmit_IT(&hi2c1,(uint16_t)(0x6b<<1),(uint8_t)system_init_reg,1);
//			  if(ret != HAL_OK)
//			  {
//				 LOG_ERROR("55\r\n");
//			  }
//			  else
//			  {
//				  LOG_INFO("BATERY_IC: MODULE ACTIVE\r\n");
//			  }

//			  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, device_id_reg, 1, id_data, 1);
//			  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, vendor_part_reg, 1, vender_part_data, 1);
//			  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);
//
//			  memset(buffer,'\0',strlen(buffer));
//			  memset(id_data,0,sizeof(id_data));
//			  memset(vender_part_data,0,sizeof(vender_part_data));
//			  memset(chrg_current_ctrl_data,0,sizeof(chrg_current_ctrl_data));
//			  memset(pre_chrg_current_ctrl_data,0,sizeof(pre_chrg_current_ctrl_data));
//			  memset(chrg_vtg_ctrl_data,0,sizeof(chrg_vtg_ctrl_data));
//			  memset(chrg_trminal_ctrl_data,0,sizeof(chrg_trminal_ctrl_data));
//			  memset(thrmal_regulation_ctrl_data,0,sizeof(thrmal_regulation_ctrl_data));
//			  memset(misc_oprtn_ctrl_data,0,sizeof(misc_oprtn_ctrl_data));
//			  memset(stat_data,0,sizeof(stat_data));
			  HAL_Delay(100);
			  percentage_value(0,Bat_status_reg[0]);
}

void LoRa_Init()
{
	LOG("\r\nInitializing LoRa...\r\n");
	myLoRa = newLoRa();

	myLoRa.hSPIx                 = &hspi2;
	myLoRa.CS_port               = RF_SPI2_CS_GPIO_Port;
	myLoRa.CS_pin                = RF_SPI2_CS_Pin;
	myLoRa.reset_port            = RF96_RESET_GPIO_Port;
	myLoRa.reset_pin             = RF96_RESET_Pin;
	myLoRa.DIO0_port			 = RF_DIO0_GPIO_Port;
	myLoRa.DIO0_pin				 = RF_DIO0_Pin;

	myLoRa.frequency             = 868;							// default = 868 MHz
	myLoRa.spredingFactor        = SF_7;						// default = SF_12
	myLoRa.bandWidth			 = BW_250KHz;					// default = BW_125KHz
	myLoRa.crcRate				 = CR_4_6;						// default = CR_4_6
	myLoRa.power				 = POWER_20db;					// default = 20db
	myLoRa.overCurrentProtection = 100; 						// default = 100 mA
	myLoRa.preamble				       = 8;		  				// default = 8;

	LoRa_reset(&myLoRa);
	LOG("Status : %d\r\n",LoRa_init(&myLoRa));
	LoRa_startReceiving(&myLoRa);
	HAL_Delay(200);
}

void GSM_Init()
{
		CUSTOM_UART_INTERRUPT_INIT();
		LOG("\r\nIntializing GSM...\r\n");
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
	   	HAL_Delay(5000);
	   	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);
	   	HAL_Delay(5000);
	   	AT_cmd();
}
void Internal_flash_init()
{
	 Flash_Write_Data(0x08030000 , (uint32_t *)data2, 9);
//	    	 Flash_Read_Data(0x08030000 , Rx_Data, sizeof(data));
	    	 int numofwords = 12;
	    	 LOG("\r\n writing to flash:%s\r\n",data);
	    	 Flash_Write_Data(0x0803C000 , (char *)data, numofwords);
	    	 Flash_Read_Data(0x0803C000 , Rx_Data, numofwords);
//	    	 Convert_To_Str(Rx_Data, string);
//	    	 printf("Internal flash:%s\r\n",string);
	    	 HAL_Delay(1000);
}
#if 0
void External_flash_init()
{
	 FlashID=sFLASH_ReadID();
   	if(FlashID==sFLASH_W25Q64_ID)
     	{
  	  		sFLASH_EraseSector(FLASH_SECTOR_TO_ERASE);
  	  		sFLASH_WriteBuffer(Tx_Buffer,FLASH_WRITE_ADDRESS,BufferSize);
//  		HAL_UART_Transmit(&huart3, Tx_Buffer, sizeof(Tx_Buffer), 200);
  	  		sFLASH_ReadBuffer(Rx_Buffer,FLASH_READ_ADDRESS,BufferSize);
  	  		sFLASH_EraseSector(FLASH_SECTOR_TO_ERASE);
  	  		sFLASH_ReadBuffer(Rx_Buffer,FLASH_READ_ADDRESS,BufferSize);
//   	  	HAL_UART_Transmit(&huart3, Rx_Buffer, 20, 200);
  	  		printf("\r\n Ext_Flash: %s\r\n",Rx_Buffer);
  	  		HAL_Delay(100);
  	  	}
  	  	else
  	  	{
  	  		HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_13);
  	  		HAL_Delay(1000);
  	  	}
}
#endif
void Custom_Init(void)
{
	set_time();
//	get_time();

	Sht21_init();

	BQ24193_Init();

	LoRa_Init();

	GSM_Init();


//	Internal_flash_init();

//	External_flash_init();

//	custom_adc();

}
