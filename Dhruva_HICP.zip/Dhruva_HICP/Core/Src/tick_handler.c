/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    tick_handler.c
  * @brief   This file provides code for the configuration
  *          of all used to delay in individual Modules.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */
#include "tick_handler.h"		//(User defined header file) This header file used to access tick_handler.c file
#include "EG25Interface.h"		//(User defined header file) This header file used to access EG25Interface.c file

volatile uint32_t uwTimingDelay;
uint8_t test_var = 0;
volatile uint32_t signal_EOT_Timer=0;

/*-------------- Timer Declarations for all the Modles-----------------*/
extern volatile int UHF_Timer;
extern volatile int GSM_Timer;
extern volatile int LoRa_Timer;
extern volatile int SHT21_Timer;
uint8_t UHF = 0;
uint8_t GSM = 0;
uint8_t LoRa = 0;
extern volatile uint8_t UHF_var;
extern volatile uint8_t GSM_var;
extern volatile uint8_t LoRa_var;
extern volatile uint8_t SHT21_var;

/*--------------------------------------------------------------------------------
*           DEF_ABS()
* Description : Determine the absolute value of a value.
* Argument(s) : a Value to calculate absolute value.
* Return(s)   : Absolute value of the value.
* Caller(s)   : various.
* Note(s)     : none.
----------------------------------------------------------------------------------*/

#define  DEF_ABS(a)                                     (((a) < 0) ? (-(a)) : (a))

/**-------------------------------------------------------------------------------
 * @brief  Inserts a delay time.
 * @param  nTime: specifies the delay time length, in milliseconds.
 * @retval None
 --------------------------------------------------------------------------------*/
void SHT21_Handler()
{
	if(SHT21_Timer !=0)
	{
		SHT21_Timer--;
		if(SHT21_Timer == 0)
		{
			SHT21_var = 1;
		}
	}
}

void UHF_Handler()
{
	if(UHF_Timer != 0)
	{
		UHF_Timer--;
		if(UHF_Timer == 0)
			{
				UHF_var = 1;
			}
	}
}

void GSM_Handler()
{
	if(GSM_Timer != 0)
	{
		GSM_Timer--;
		if(GSM_Timer == 0)
		{
			GSM_var = 1;
		}
	}
}

void LoRa_Handler()
{
	if(LoRa_Timer != 0)
	{
		LoRa_Timer--;
		if(LoRa_Timer == 0)
		{
			LoRa_var = 1;
		}
	}
}

void CUSTOM_Tickhandler(void)
{
	SHT21_Handler();
	UHF_Handler();
	GSM_Handler();
	LoRa_Handler();
}

void AppDelay(volatile uint32_t nTime)
{
	uwTimingDelay = nTime;
  while(uwTimingDelay != 0);
}

/**---------------------------------------------------------------------------------
 * @brief  Decrements the Timing Delay variable.
 * @param  None
 * @retval None
 ----------------------------------------------------------------------------------*/
void Delay_handler(void)
{
	if (uwTimingDelay != 0x00){
   uwTimingDelay--;
  }
}

void test_EOTTimer(void){
     if(signal_EOT_Timer != 0) {
      signal_EOT_Timer--;
      if(signal_EOT_Timer == 0) {
    	  test_var = 1;
      }
   }
 }

void EG25InterfaceEOPHandler(void)
{
   if(EG25Interface.EOP_Timer != 0) {
      EG25Interface.EOP_Timer--;
      if(EG25Interface.EOP_Timer == 0) {
        EG25Interface.RxInterfaceEvent = 1;
      }
   }
}

# if 0
void GSMInterfaceEOPHandler(void)
{
   if(GSMPortInterface.EOP_Timergsm != 0) {
	   GSMPortInterface.EOP_Timergsm--;
      if(GSMPortInterface.EOP_Timergsm == 0) {
    	  GSMPortInterface.RxInterfaceEventgsm = 1;
      }
   }
}

void DebugInterfaceEOPHandler(void)
{
   if(DebugPortInterface.EOP_Timer != 0) {
      DebugPortInterface.EOP_Timer--;
      if(DebugPortInterface.EOP_Timer == 0) {
        DebugPortInterface.RxInterfaceEvent = 1;
      }
   }
}
#endif

#if 0
void signal_strength_EOTTimer(void){
     if(signal_EOT_Timer != 0) {
      signal_EOT_Timer--;
      if(signal_EOT_Timer == 0) {
        if(API_buf_notification_flag == 0)
        {
          read_signal_strength_event = 1;
				}
				else
				{
				  //signal_EOT_Timer = 25000;
					read_signal_strength_waiting_flag = 1;
				}
      }
   }
 }
#endif

void TickHandler(uint32_t data)
{
	Delay_handler();
    test_EOTTimer();
    EG25InterfaceEOPHandler();
    CUSTOM_Tickhandler();
}




