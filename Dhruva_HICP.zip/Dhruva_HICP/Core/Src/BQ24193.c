/*
 * battery_charging.c
 *
 *  Created on: Nov 8, 2023
 *      Author: HP CORE I3
 */

/* Includes ------------------------------------------------------------------*/
#include "BQ24193.h"

#include <stdio.h>
#include <string.h>
//#include "Saturation.h"
#include "custom_adc.h"

#include "log.h"

/* Private Defines ---------------------------------------------------------*/

#define BAT_ADC 	3
#define CHARGE_SENSE 	4

#define ADC_AVG 	10
#define STAT_COUNT 	20


/* Private variables ---------------------------------------------------------*/
HAL_StatusTypeDef ret;


uint8_t buf[12];
int16_t val1,batttemp;
char buffer[10]; 								// buffer to hold the converted value

uint8_t id_data[4]; 							/* Buffer to hold ID data*/
uint8_t vender_part_data[4];
uint8_t chrg_current_ctrl_data[4]; 				/* Buffer to hold Charge Current Control data*/
uint8_t pre_chrg_current_ctrl_data[4];  		/* Buffer to hold Pre-Charge/Termination Current Control data*/
uint8_t chrg_vtg_ctrl_data[4];					/* Buffer to hold Charge Voltage Control data*/
uint8_t chrg_trminal_ctrl_data[4];				/* Buffer to hold Charge Termination/Timer Control data*/
uint8_t thrmal_regulation_ctrl_data[4];			/* Buffer to hold Charge Thermal Regulation Control data*/
uint8_t misc_oprtn_ctrl_data[4];				/* Buffer to hold Thermal Regulation Control data*/
uint8_t stat_data[4]; 							/* Buffer to hold status data*/
uint32_t adc_value_1,adc_value_2;
uint8_t low_battery=0;
uint16_t new_value,old_value=0;
uint16_t ADC_BAT;

volatile uint8_t  battery_variable;						/* Buffer to battery status*/
extern I2C_HandleTypeDef  hi2c1;;
extern ADC_HandleTypeDef hadc1;
extern uint16_t battery_timer;
extern volatile uint8_t battery_action,bat2;
extern const uint16_t BrtZero[2];			//{x,y} brightness zero positions
extern volatile uint8_t page;
DMA_HandleTypeDef hdma_adc1;

/* Private function prototypes -----------------------------------------------*/

/**
  * @brief  Function for Battery Initialization.
  * @retval None
  */

//void BATTERY_CHARGING_Init(void)
//{
//	  LOG_INFO("\r\nInitializing BATTERY_IC      ");
//	  ret = HAL_I2C_Master_Transmit_IT(&hi2c1,(uint16_t)(0x6b<<1),(uint8_t)system_init_reg,1);
//	  if(ret != HAL_OK)
//	  {
//		 LOG_ERROR("55\r\n");
//	  }
//	  else
//	  {
//		  LOG_INFO("BATERY_IC: MODULE ACTIVE\r\n");
//	  }
//
//	  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, device_id_reg, 1, id_data, 1);
//	  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, vendor_part_reg, 1, vender_part_data, 1);
//	  HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);
//
//	  memset(buffer,'\0',strlen(buffer));
//	  memset(id_data,0,sizeof(id_data));
//	  memset(vender_part_data,0,sizeof(vender_part_data));
//	  memset(chrg_current_ctrl_data,0,sizeof(chrg_current_ctrl_data));
//	  memset(pre_chrg_current_ctrl_data,0,sizeof(pre_chrg_current_ctrl_data));
//	  memset(chrg_vtg_ctrl_data,0,sizeof(chrg_vtg_ctrl_data));
//	  memset(chrg_trminal_ctrl_data,0,sizeof(chrg_trminal_ctrl_data));
//	  memset(thrmal_regulation_ctrl_data,0,sizeof(thrmal_regulation_ctrl_data));
//	  memset(misc_oprtn_ctrl_data,0,sizeof(misc_oprtn_ctrl_data));
//	  memset(stat_data,0,sizeof(stat_data));
//	 // HAL_Delay(1000);
//}

/**
  * @brief  Function for Device ID .
  * @retval None
  * @Note	This function was used during development
  */

void device_id(void)
{
	HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, device_id_reg, 1, id_data, 1);
	printf(" device id = %x\r\n",id_data[0]);
}

/**
  * @brief  Function for vendor ID of the battery .
  * @retval None
  * @Note	This function was used during development
  */

void vendor_id(void)
{
	HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, vendor_part_reg, 1, vender_part_data, 1);
	//printf(" Vendor part ID = %x\r\n",vender_part_data[0]);
}

/**
  * @brief  Function for Status of the battery. ie, Charging, Discharging, Charge termination and DPM charging .
  * @retval None
  * @Note	This function was used during development
  */

void system_status(void)
{
	//HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);
		ret = HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);

		if(ret != HAL_OK)
			 LOG_ERROR("LOG_ERROR\r\n");
		else
		{
			LOG("system_stat_reg %x",stat_data[0]);
			//percentage_value((uint16_t)stat_data[0]);
		}


}

/**
  * @brief  Function for Analog values getting from the battery
  * @retval None
  * @Note	This function was used during development
  */

uint16_t map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max)
{
	return (((x - in_min) * (out_max - out_min) / (in_max - in_min)) + out_min);
}

double float_saturation(double Value, double Min, double Max)
{
/* Function result declaration */
   double Function_Result = 0;

   if (Value > Max)
	{
	   Function_Result = Max;
	}
   else if (Value < Min)
	{
	   Function_Result = Min;
	}
   else
	{
	   Function_Result = Value;
	}

   return(Function_Result);
}

/**
 * @brief function reads and stores the ADC value from channel 1 for battery charging sensing.
 */
uint16_t BATTERY_CHARGING_SENSING(void)
{
	int sum=0.0,i;
		    uint16_t RAW[ADC_AVG];
	//
	//	    ret = HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);
	//
	//	    		if(ret != HAL_OK)
	//	    			 LOG_ERROR("LOG_ERROR\r\n");
	//	    		else
	//	    			percentage_value((uint16_t)stat_data[0]);




		    for(i=0;i<ADC_AVG;i++)
		    {
		        select_adc_channel(BAT_ADC);
		        HAL_ADC_Start(&hadc1);                // Start the ADC conversion
		        HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);    // Wait for the conversion to complete
		        RAW[i] = HAL_ADC_GetValue(&hadc1);     // Read and store the ADC value from channel 1
		        //printf(" adc value = %d\r\n",RAW[i]);
		        memset(RAW[i],0,sizeof(RAW[i]));
		        HAL_ADC_Stop(&hadc1);
		    }
		    for (i=0;i<ADC_AVG;i++)
		    {
		        sum+=RAW[i];
		    }

		     ADC_BAT=sum/ADC_AVG;
//		     printf(" average adc value = %d\r\n",ADC_BAT);

	//	     new_value = ADC_BAT ;
	//	     if (new_value < old_value)
	//	     {
	//	    printf("ADC value decreased: Taking new value (%d) instead of old value (%d)\n", new_value, old_value);
	//	     old_value  =  new_value;  // Take the new value as the old value
		      //  new_value = old_value;
	//	    printf(" current value = %d\r\n",old_value);
		      //batttemp = map(ADC_BAT, 635, 735, 0, 100);
		      batttemp = map(ADC_BAT, 10160, 11760, 0, 100);
	//	      printf("Battery Raw - %d\n",batttemp);
//		      batttemp = float_saturation(batttemp,0,100);
		//     // batttemp = map(old_value, 10160, 11760, 0, 100);
		//
	//	     }
	//	    else
	//	      {
	//	     new_value = old_value;
	//	    // printf(" average adc value = %d\r\n",new_value);
	//	     batttemp = map(new_value, 650, 735, 0, 100);
	//	     batttemp = saturation(batttemp,0,100);
	//	    // batttemp = map(new_value, 10400, 11760, 0, 100);
	//	      }
//		     printf("Battery Raw - %d\n",batttemp);
		     percentage_value(batttemp,0);
}


/**
  * @brief  Function for Percentage bars for the battery indication using ADC value
  * 		for battery percentage and for system status ie, Charging, Discharging, Charge termination and DPM charging.
  * @retval None
  * @Note	need to change for 25%
  */

void percentage_value (uint16_t batttemp,uint8_t stat_data )
{
//	HAL_I2C_Mem_Read_IT(&hi2c1, 0x6b<<1, system_stat_reg, 1, stat_data, 1);
//	LOG("system_stat_reg %d",stat_data[0]);
	switch(stat_data)
	{
	  case 0:
			switch(batttemp)
			{

				case 0 ... 10: LOG_INFO("Battery: 0%% \r\n");
								low_battery=1;
								battery_variable = 0;
								break;

				case 11 ... 20: LOG_INFO("Battery: 20%%\r\n");
								low_battery=1;
								battery_variable = 8;
								break;
				case 21 ... 25: LOG_INFO("Battery: 25%%\r\n");
								low_battery=1;
								battery_variable = 8;
								break;
				case 26 ... 100:LOG("Battery: %d%%\r\n",batttemp);
								low_battery=0;
//								battery_variable = 1;
								break;

//				case 41 ... 60: LOG("Battery: %d%%\r\n",batttemp);
//								low_battery=0;
//								battery_variable = 2;
//								break;

//				case 61 ... 80:  LOG_INFO("80%%\r\n");
//								low_battery=0;
//								battery_variable = 3;
//								break;
//
//				case 81 ... 100:LOG_DEBUG("100%%\r\n");
//								low_battery=0;
//								battery_variable = 4;
//								break;

				default :       LOG_INFO("default 0\r\n");
								break;
			}
				break;
	 case 0xa4 :	LOG_DEBUG("\r\n ON charging \r\n");//fast charging
							low_battery=1;
							battery_variable = 5;
							break;
	 case 0xb4 : 	LOG_DEBUG("charging terminated\r\n");//reached full voltage
		 	 	 	 	 	low_battery=0;
							battery_variable = 6;
							break;
	 case 0xac : 	LOG_DEBUG("charging DPM\r\n");//dynamic charging
		 	 	 	 	 	low_battery=1;
							battery_variable = 5;
							break;
	 case 0xf0 : 	LOG_DEBUG("OTG Charging Termination\r\n");//dynamic charging
//	 		 	 	 	 	 	low_battery=1;
//	 							battery_variable = 5;
	 							break;
	 case 0xE8 : 	LOG_DEBUG("OTG,Fast charging and DPM Enabled\r\n");//dynamic charging
	//	 		 	 	 	 	 	low_battery=1;
	//	 							battery_variable = 5;
		 							break;
		 default :		LOG_INFO("No Status \r\n");
		 	 	 	 	 	 	break;
	}
}

/**
  * @brief  This function is called in the loop which contains System status, analog value and Battery status indication
  * @retval None
  * @Note	This function is called in the main loop.
  */

void custom_battery(void)
{
	if(battery_action==1)
	{
		battery_action = 0;
		battery_timer = BATTERY_DELAY;

		system_status();
		BATTERY_CHARGING_SENSING();
		//percentage_value();
//		Read_Date_and_Time();
	}
}

