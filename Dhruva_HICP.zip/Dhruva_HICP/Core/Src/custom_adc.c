#include"custom_adc.h"
#include "adc.h"
#include "gpio.h"
#include "main.h"
#include "log.h"
#include "stm32l4xx_hal.h"
#include "string.h"

uint8_t adcvalue;
char x[10],temp[50];
extern ADC_HandleTypeDef hadc1;
extern volatile uint8_t s1_custom_rtc_5min_action, s2_custom_rtc_5min_action,s3_custom_rtc_5min_action;




void custom_adc(void)
 {
	LOG("\r\n ADC Reading\r\n");
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
	 HAL_ADC_Start(&hadc1);
	 if(HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY)==HAL_OK)
	 {
	 	for(int i=0;i<10;i++)
	 		  {
			  adcvalue=HAL_ADC_GetValue(&hadc1);
			  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
			  adcvalue+=adcvalue;
//			  sprintf(x, "ADC value=%hu\r\n", adcvalue);
			  LOG("ADC value=%hu\r\n",adcvalue);
			  HAL_Delay(500);
	 		  }
	 		  adcvalue=adcvalue/10;
//			  sprintf(temp,"voltage=%f\r\n",(adcvalue*3.3)/65536);
			  LOG("voltage=%f\r\n",(adcvalue)*(3.3)/4096);
			  LOG("Temp=%f\r\n",(332.558-0.187364*(adcvalue))+25);
			  HAL_Delay(1000);
			  memset(adcvalue,'0',sizeof(adcvalue));
	 	  }
 }

void select_adc_channel(int channel)
  {
    ADC_ChannelConfTypeDef sConfig = {0};
	sConfig.SamplingTime = ADC_SAMPLETIME_6CYCLES_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;

     switch (channel)
     {
       case 3:
             sConfig.Channel = ADC_CHANNEL_3;
             sConfig.Rank = ADC_REGULAR_RANK_1;

             if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
             {
               Error_Handler();
             }

             break;

       case 4:

             sConfig.Channel = ADC_CHANNEL_4;
             sConfig.Rank = ADC_REGULAR_RANK_1;
             if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
             {
               Error_Handler();
             }

        break;
       default:
                  break;
     }
  }
