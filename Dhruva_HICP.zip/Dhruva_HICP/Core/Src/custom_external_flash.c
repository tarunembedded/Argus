/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    custom_external_flash.c
  * @brief   This file provides code for the configuration
  *          of all used to External_Flash.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "custom_external_flash.h"		//(User defined header file) This header file used to access custom_external_flash.c file
#include "main.h"
#include "log.h"

extern SPI_HandleTypeDef hspi1;

/*---------------Private function prototypes -----------------------------------------------*/
void sFLASH_LowLevel_DeInit(void);
void sFLASH_LowLevel_Init(void);

void sFLASH_DeInit(void)
{
  sFLASH_LowLevel_DeInit();
}

void sFLASH_Reset()
{
	uint8_t tdata[2];
	tdata[0] = 0x66; //0x66: enable rest,
	tdata[1] = 0x99; //0x99 rest cmd
	sFLASH_WriteEnable();
	sFLASH_CS_LOW();
	sFLASH_SendByte(tdata[0]);
	sFLASH_SendByte(tdata[1]);
	sFLASH_CS_HIGH();
	HAL_Delay(100);

}

void sFLASH_EraseBulk(void)
{
  sFLASH_WriteEnable();		//Send write enable instruction

  /*---------------- Bulk Erase----------------------------------------------- */
  sFLASH_CS_LOW();					//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_BE);	// Send Bulk Erase instruction
  sFLASH_CS_HIGH();					//Deselect the FLASH: Chip Select high
  sFLASH_WaitForWriteEnd();			//Wait the end of Flash writing
}

uint8_t sFLASH_SendByte(uint8_t byte)
{
	uint8_t data;
  //while (SPI_I2S_GetFlagStatus(sFLASH_SPI, SPI_FLAG_TXE) == RESET);
	HAL_SPI_TransmitReceive(&hspi1, &byte, &data, 1, 10);
	return data;
}

  //SPI_I2S_SendData(sFLASH_SPI, byte);										//Send byte through the SPI1 peripheral
  //while (SPI_I2S_GetFlagStatus(sFLASH_SPI, SPI_FLAG_RXNE) == RESET);	 	// Wait to receive a byte
  //return SPI_I2S_ReceiveData(sFLASH_SPI);								  	//Return the byte read from the SPI bus

void sFLASH_EraseSector(uint32_t SectorAddr)
{
  sFLASH_WriteEnable();		//Send write enable instruction

  /*------------ Sector Erase------------ */
  sFLASH_CS_LOW();										//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_SE);						//Send Sector Erase instruction
  sFLASH_SendByte((SectorAddr & 0xFF0000) >> 16);		//Send SectorAddr high nibble address byte
  sFLASH_SendByte((SectorAddr & 0xFF00) >> 8);			//Send SectorAddr medium nibble address byte
  sFLASH_SendByte(SectorAddr & 0xFF);					//Send SectorAddr low nibble address byte
  sFLASH_CS_HIGH();										//Deselect the FLASH: Chip Select high
  sFLASH_WaitForWriteEnd();								//Wait the end of Flash writing
}

void sFLASH_WritePage(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{

  sFLASH_WriteEnable();								//Enable the write access to the FLASH
  sFLASH_CS_LOW();									//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_WRITE);				//Send "Write to Memory " instruction
  sFLASH_SendByte((WriteAddr & 0xFF0000) >> 16);	//Send WriteAddr high nibble address byte to write to
  sFLASH_SendByte((WriteAddr & 0xFF00) >> 8);		//Send WriteAddr medium nibble address byte to write to
  sFLASH_SendByte(WriteAddr & 0xFF);				//Send WriteAddr low nibble address byte to write to

  while (NumByteToWrite--)							//while there is data to be written on the FLASH
  {
    sFLASH_SendByte(*pBuffer);						//Send the current byte
    pBuffer++;										//Point on the next byte to be written
  }
  sFLASH_CS_HIGH();									//Deselect the FLASH: Chip Select high
  sFLASH_WaitForWriteEnd();							//Wait the end of Flash writing
}

void sFLASH_WriteBuffer(uint8_t* pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
  uint8_t NumOfPage = 0, NumOfSingle = 0, Addr = 0, count = 0, temp = 0;

  Addr = WriteAddr % sFLASH_SPI_PAGESIZE;
  count = sFLASH_SPI_PAGESIZE - Addr;
  NumOfPage =  NumByteToWrite / sFLASH_SPI_PAGESIZE;
  NumOfSingle = NumByteToWrite % sFLASH_SPI_PAGESIZE;

  if (Addr == 0) 							// WriteAddr is sFLASH_PAGESIZE aligned
  {
    if (NumOfPage == 0) 					// NumByteToWrite < sFLASH_PAGESIZE
    {
      sFLASH_WritePage(pBuffer, WriteAddr, NumByteToWrite);
    }
    else 									//NumByteToWrite > sFLASH_PAGESIZE
    {
      while (NumOfPage--)
      {
        sFLASH_WritePage(pBuffer, WriteAddr, sFLASH_SPI_PAGESIZE);
        WriteAddr +=  sFLASH_SPI_PAGESIZE;
        pBuffer += sFLASH_SPI_PAGESIZE;
      }
      sFLASH_WritePage(pBuffer, WriteAddr, NumOfSingle);
    }
  }
  else 								// WriteAddr is not sFLASH_PAGESIZE aligned
  {
    if (NumOfPage == 0) 			// NumByteToWrite < sFLASH_PAGESIZE
    {
      if (NumOfSingle > count)		 // (NumByteToWrite + WriteAddr) > sFLASH_PAGESIZE
      {
        temp = NumOfSingle - count;

        sFLASH_WritePage(pBuffer, WriteAddr, count);
        WriteAddr +=  count;
        pBuffer += count;

        sFLASH_WritePage(pBuffer, WriteAddr, temp);
      }
      else
      {
        sFLASH_WritePage(pBuffer, WriteAddr, NumByteToWrite);
      }
    }
    else 										// NumByteToWrite > sFLASH_PAGESIZE
    {
      NumByteToWrite -= count;
      NumOfPage =  NumByteToWrite / sFLASH_SPI_PAGESIZE;
      NumOfSingle = NumByteToWrite % sFLASH_SPI_PAGESIZE;
      sFLASH_WritePage(pBuffer, WriteAddr, count);
      WriteAddr +=  count;
      pBuffer += count;

      while (NumOfPage--)
      {
        sFLASH_WritePage(pBuffer, WriteAddr, sFLASH_SPI_PAGESIZE);
        WriteAddr +=  sFLASH_SPI_PAGESIZE;
        pBuffer += sFLASH_SPI_PAGESIZE;
      }

      if (NumOfSingle != 0)
      {
        sFLASH_WritePage(pBuffer, WriteAddr, NumOfSingle);
      }
    }
  }
}

void sFLASH_ReadBuffer(uint8_t* pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
  sFLASH_CS_LOW();								//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_READ);				//Send "Read from Memory " instruction
  sFLASH_SendByte((ReadAddr & 0xFF0000) >> 16);	//Send ReadAddr high nibble address byte to read from
  sFLASH_SendByte((ReadAddr& 0xFF00) >> 8);		//Send ReadAddr medium nibble address byte to read from
  sFLASH_SendByte(ReadAddr & 0xFF);				//Send ReadAddr low nibble address byte to read from

  while (NumByteToRead--) 						// while there is data to be read
  {
    *pBuffer = sFLASH_SendByte(W25QXX_DUMMY_BYTE);	//Read a byte from the FLASH
    pBuffer++;										//Point to the next location where the byte read will be saved

  }
  sFLASH_CS_HIGH();									//De select the FLASH: Chip Select high
}

void sFLASH_StartReadSequence(uint32_t ReadAddr)
{
  sFLASH_CS_LOW();							//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_READ);			//Send "Read from Memory " instruction

  /*-------- Send the 24-bit address of the address to read from -------------------*/
  sFLASH_SendByte((ReadAddr & 0xFF0000) >> 16);		//Send ReadAddr high nibble address byte
  sFLASH_SendByte((ReadAddr& 0xFF00) >> 8);			//Send ReadAddr medium nibble address byte
  sFLASH_SendByte(ReadAddr & 0xFF);					//Send ReadAddr low nibble address byte
}

uint8_t sFLASH_ReadByte(void)
{
  return (sFLASH_SendByte(W25QXX_DUMMY_BYTE));
}

void sFLASH_WriteEnable(void)
{
  sFLASH_CS_LOW();						//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_WREN);		// Send "Write Enable" instruction
  sFLASH_CS_HIGH();						//Deselect the FLASH: Chip Select high
}

void sFLASH_WaitForWriteEnd(void)
{
  uint8_t flashstatus = 0;
  sFLASH_CS_LOW();						//Select the FLASH: Chip Select low
  sFLASH_SendByte(sFLASH_CMD_RDSR);		//Send "Read Status Register" instruction

  /*!< Loop as long as the memory is busy with a write cycle */
  do
  {
    /*!< Send a dummy byte to generate the clock needed by the FLASH and put the value of the status register in FLASH_Status variable */
    flashstatus = sFLASH_SendByte(W25QXX_DUMMY_BYTE);
  }
  while ((flashstatus & sFLASH_WIP_FLAG) == SET); 		// Write in progress
  sFLASH_CS_HIGH();										// Deselect the FLASH: Chip Select high
}

uint32_t sFLASH_ReadID(void)
{

  uint32_t Temp = 0, Temp0 = 0, Temp1 = 0, Temp2 = 0;
//  sFLASH_WriteEnable();
  sFLASH_CS_LOW();									//Select the FLASH: Chip Select low
   sFLASH_SendByte(0x9F);							//Send "RDID " instruction
   Temp0 = sFLASH_SendByte(W25QXX_DUMMY_BYTE);		//Read a byte from the FLASH
   Temp1 = sFLASH_SendByte(W25QXX_DUMMY_BYTE);		//Read a byte from the FLASH
   Temp2 = sFLASH_SendByte(W25QXX_DUMMY_BYTE);		//Read a byte from the FLASH
    Temp = (Temp0 << 16) | (Temp1 << 8) | Temp2;
//    LOG("Flash ID: %x\r\n",Temp);
    return Temp;
}
