/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    custom_internal_flash.c
  * @brief   This file provides code for the configuration
  *          of all used to Internal_Flash.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "custom_internal_flash.h"		//(User defined header file) This header file used to access custom_internal_flash.c file
#include "stm32l4xx_hal.h"				//(User defined header file) This header file used to access stm32l4xx_hal.c file
#include "string.h"
#include "stdio.h"
#include "log.h"						//(User defined header file) This header file used to access log.c file

	extern char *data;
	extern uint32_t data2[];
	extern uint32_t Rx_Data[30];
	extern char string[100];
//	int number = 123;
//	float val = 123.456;
//	float RxVal;

/*------------------- Referance Manual RM0394 Page no 74--------------------------*/

static uint32_t GetPage(uint32_t Address)
{
  uint32_t page = 0;
  if((Address < 0x080307FF) && (Address >= 0x08030000))
  {
    page = FLASH_PAGE_96;
  }
  else if((Address < 0x08030FFF) && (Address >= 0x08030800))
  {
    page = FLASH_PAGE_97;
  }
  else if((Address < 0x080317FF) && (Address >= 0x08031000))
  {
    page = FLASH_PAGE_98;
  }
  else if((Address < 0x08031FFF) && (Address >= 0x08031800))
  {
    page = FLASH_PAGE_99;
  }
  else if((Address < 0x080327FF) && (Address >= 0x08032000))
  {
    page = FLASH_PAGE_100;
  }
  else if((Address < 0x08032FFF) && (Address >= 0x08032800))
  {
    page = FLASH_PAGE_101;
  }
  else if((Address < 0x080337FF) && (Address >= 0x08033000))
  {
    page = FLASH_PAGE_102;
  }
  else if((Address < 0x08033FFF) && (Address >= 0x08033800))
  {
    page = FLASH_PAGE_103;
  }
  else if((Address < 0x080347FF) && (Address >= 0x08034000))
  {
    page = FLASH_PAGE_104;
  }
  else if((Address < 0x08034FFF) && (Address >= 0x08034800))
  {
    page = FLASH_PAGE_105;
  }
  else if((Address < 0x0803C7FF) && (Address >= 0x0803C000))
  {
    page = FLASH_PAGE_120;
  }
  else if((Address < 0x0803CFFF) && (Address >= 0x0803C800))
   {
     page = FLASH_PAGE_121;
   }
  return page;
}

uint8_t bytes_temp[4];
#if 0
int flash_int_erase()
	  {
	  	int status;

	  	HAL_FLASH_Unlock();
	  	HAL_FLASH_OB_Unlock();
	  	status = flash_erase_unlocked();
	  	HAL_FLASH_OB_Lock();
	  	HAL_FLASH_Lock();

	  	return status;
	  }
#endif

/*
void float2Bytes(uint8_t * ftoa_bytes_temp,float float_variable)
{
    union {
      float a;
      uint8_t bytes[4];
    } thing;
    thing.a = float_variable;

    for (uint8_t i = 0; i < 4; i++) {
      ftoa_bytes_temp[i] = thing.bytes[i];
    }
}

float Bytes2float(uint8_t * float_bytes_temp)
{
    union {
      float a;
      uint8_t bytes[4];
    } thing;
    for (uint8_t i = 0; i < 4; i++) {
    	thing.bytes[i] = float_bytes_temp[i];
    }
   float float_variable =  thing.a;
   return float_variable;
}
*/

uint32_t Flash_Write_Data (uint32_t StartPageAddress, char *Data, uint16_t numberofwords)
{
//	static FLASH_EraseInitTypeDef EraseInitStruct;
//	uint32_t PAGEError;
	int sofar=0;

/*--------- Unlock the Flash to enable the flash control register access ----------*/
	 HAL_FLASH_Unlock();
	 HAL_FLASH_OB_Unlock();

/*------------------ Erase the user Flash area----------------------------------*/
/*-------------- Get the number of page to erase from 1st page----------------- */

	  	  uint32_t StartPage = GetPage(StartPageAddress);
	  	  uint32_t EndPageAddress = StartPageAddress + numberofwords*2;
	  	  uint32_t EndPage = GetPage(EndPageAddress);
	  	  uint32_t page_err;
	  	  FLASH_EraseInitTypeDef erase_page;
	  	  volatile HAL_StatusTypeDef erase_status;

	  	erase_page.TypeErase	= FLASH_TYPEERASE_PAGES;
//	  	erase_page.Banks		= FLASH_BANK_1;
	  	erase_page.Page			= StartPage;
	  	erase_page.NbPages		= EndPage - StartPage + 1;

	  	FLASH_WaitForLastOperation((uint32_t)FLASH_TIMEOUT_VALUE);
	  	erase_status = HAL_FLASHEx_Erase(&erase_page,&page_err);

	  	if(erase_status != HAL_OK)
	  	{
//	  		printf("Failed to erase %d partition error code : %d\r\n",GetPage(StartPage),erase_status);
//	  		return FLASH_ERASE_ERROR;;
	  	}
	  	else
	  	{
//	  		printf("Flash erase success\r\n");
	  		   while (sofar<numberofwords)
	  		   {
	  		     if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, StartPageAddress, Data[sofar]) == HAL_OK)
	  		     {
	  		    	 StartPageAddress +=16 ;  // use StartPageAddress += 16 for half word and 16 for double word
	  		    	 sofar++;
//	  		    	 printf("write success");
	  		     }
	  		     else
	  		     {
	  		       /* Error occurred while writing data in Flash memory*/
	  		    	 return HAL_FLASH_GetError ();
	  		     }
	  		   }
	  	}
	  	return SUCCESS;

	  /* Note: If an erase operation in Flash memory also concerns data in the data or instruction cache,
	     you have to make sure that these data are rewritten before they are accessed during code
	     execution. If this cannot be done safely, it is recommended to flush the caches by setting the
	     DCRST and ICRST bits in the FLASH_CR register. */
//	  if (HAL_FLASHEx_Erase(&EraseInitStruct, &PAGEError) != HAL_OK)
//	  {
//		  return HAL_FLASH_GetError ();
//		  printf("Internal flash Page error");
//	  }

/*------- Program the user Flash area word by word
	    (area defined by FLASH_USER_START_ADDR and FLASH_USER_END_ADDR) ---------*/
#if 0
	  	flash_int_erase();
	   while (sofar<numberofwords)
	   {
	     if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, StartPageAddress, Data[sofar]) == HAL_OK)
	     {
	    	 StartPageAddress += 4;  // use StartPageAddress += 2 for half word and 8 for double word
	    	 sofar++;
//	    	 printf("write success");
	     }
	     else
	     {
	       /* Error occurred while writing data in Flash memory*/
	    	 return HAL_FLASH_GetError ();
	     }
	   }
#endif

	   /* Lock the Flash to disable the flash control register access (recommended
	     to protect the FLASH memory against possible unwanted operation) *********/
	   HAL_FLASH_OB_Lock();
	   HAL_FLASH_Lock();
	   return 0;
}

void Flash_Read_Data (uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords)
{
//	while (1)
//	{
//		*RxBuf = *(__IO uint32_t *)StartPageAddress;
//		StartPageAddress += 16;
//		RxBuf++;
//		printf("RxBuf = %d ",RxBuf);
//		if (!(numberofwords--))
//			break;
//	}

//	printf("RxBuf = ");
	printf("Read from Flash: ");
	for (int i = 0; i < numberofwords; ++i) {
		RxBuf[i] = *(__IO uint32_t *)StartPageAddress;
		StartPageAddress += 16;
		printf("%c",RxBuf[i]);
	}
	printf("\r\n");
}

void Convert_To_Str (uint32_t *Data, char *Buf)
{
	int numberofbytes = ((strlen((char *)Data)/2) + ((strlen((char *)Data) % 2) != 0)) *4;
	for (int i=0; i<numberofbytes; i++)
	{
		Buf[i] = Data[i/2]>>(8*(i%2));
	}
}

/*
void Flash_Write_NUM (uint32_t StartSectorAddress, float Num)
{
	float2Bytes(bytes_temp, Num);
	Flash_Write_Data (StartSectorAddress, (uint32_t *)bytes_temp, 1);
}

float Flash_Read_NUM (uint32_t StartSectorAddress)
{
	uint8_t buffer[4];
	float value;
	Flash_Read_Data(StartSectorAddress, (uint32_t *)buffer, 1);
	value = Bytes2float(buffer);
	return value;
}
*/

#if 0
uint32_t Internal_flash()
{
	  Flash_Write_Data(0x08030000 , (uint32_t *)data2, 9);
	    Flash_Read_Data(0x08032000 , Rx_Data, 10);
	    int numofwords = (strlen(data)/2)+((strlen(data)%2)!=0);
	    Flash_Write_Data(0x08034000 , (uint32_t *)data, numofwords);
	    Flash_Read_Data(0x0803400 , Rx_Data, numofwords);
	    Convert_To_Str(Rx_Data, string);
}
#endif
