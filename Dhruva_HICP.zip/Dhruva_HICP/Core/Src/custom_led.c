/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    custom_led.c
  * @brief   This file provides code for the configuration
  *          of all used to custom_led.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include <custom_led.h>		//(User defined header file) This header file used to access custom_led.c file
/**
  * @brief  This function toggles the led
  * @param  None
  * @retval None
  */
void LED_TEST()
{
	 LED1_ON();
	 LED2_ON();
     //HAL_Delay(1000);
	 //LED1_OFF();
	 //LED2_OFF();
}
