/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    EG25packethandler.c
  * @brief   This file provides code for the configuration
  *          of all used EG25packethandler.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "stm32l4xx.h"
/*---------------------Include my libraries here---------------------- */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include "EG25Interface.h"			//(User defined header file) This header file used to access EG25Interface.c file
#include "EG25packethandler.h"		//(User defined header file) This header file used to access EG25packethandler.c file
#include "usart.h"
#include "gpio.h"
#include "sht2x_for_stm32_hal.h"	//(User defined header file) This header file used to access sht2x_for_stm32_hal.c file
#include "log.h"					//(User defined header file) This header file used to access log.c file
#include "app.h"					//(User defined header file) This header file used to access app.c file

#define RTC_CHAR2NUM(x)                 ((x) - '0')
#define CHARISALPHA(x)                ((x)>='a' && (x)<='z') || ((x)>='A' && (x)<='Z'))
#define CHARISNUM(x)                ((x) >= '0' && (x) <= '9')

extern volatile uint32_t signal_EOT_Timer;

//unsigned char Sendserverdata[30] = "This is test data, Dhruva HICP project.";
volatile uint8_t initial_cmds=0;
volatile uint8_t mqtt_open_cmds = 0;
volatile uint8_t mqtt_pubx_cmds = 0;
volatile uint8_t packet_handler=1;

//extern tbuffer[50];
//extern hbuffer[50];
extern int server_buffer[50];
extern char RSSI[10];
//char Sendserverdata[sizeof(server_buffer)];
extern float cel,rh; /*SHT21 Variables*/

extern volatile uint8_t Module;
char dev_id[20];
char clk[30];
char clock[30];
char read_res[30];
char operator1[9];
char operator_res[30];
char server_buf[512];
char signal_strength[4];
int reset = 0;
char converted_sig_buff[4];
extern char tbuffer[50];

/*------------Initial Commands---------------------*/
void INIT_COMMAND(void)
	{
			switch(initial_cmds)
			{
				case AT:       AT_response();
									     break;
				case AT_CPIN:  AT_CPIN_response();
											 break;
				case AT_CFUN:  AT_CFUN_response();
								   		 break;
				case AT_COPS:  AT_COPS_response();
								   		 break;
				case AT_CREG:  AT_CREG_response();
											 break;
				case AT_CREGW :  AT_CREGW_response();
										 break;
				case AT_CREGW2 :  AT_CREGW2_response();
														 break;
				case AT_CNUM:  AT_CNUM_response();
								   		 break;
				case AT_CGATT: AT_CGATT_response();
									     break;
				case AT_CGATT2: AT_CGATT2_response();
									     break;
				case AT_CCLK:  AT_CCLK_response();
								   		 break;
				case AT_GSN:   AT_GSN_response();
								  	   break;
				case AT_CSQ: AT_CSQ_response();
								  	   break;
				default : initial_cmds = AT;
										break;
      }
  }

/*--------------------MQTT Server Commands----------------------------*/
void MQTT_CMDS(void)
  {
	 switch(mqtt_open_cmds)
	  {
	 	 case AT_QMTCLOSE:          AT_QMTCLOSE_response();
			   	                    break;
	     case AT_QMTOPEN:           AT_QMTOPEN_response();
		   	                        break;
//	     case AT_QMTOPEN2:          AT_QMTOPEN2_response();
//		   	                        break;
		 case AT_QMTCONN:           AT_QMTCONN_response();
								    break;
		 case AT_QMTDSC:	        AT_QMTDSC_response();
									break;
		 case AT_QMTSUB:	        AT_QMTSUB_response();
									break;
		 case AT_QMTCFG:	        AT_QMTCFG_response();
									break;
		default : mqtt_open_cmds = AT_QMTCFG; break;
	}
}

/*-------------MQTT Server Publish Commands-------------------------------*/
void MQTT_PUBX(void)
{
	switch(mqtt_pubx_cmds)
	{
	  case AT_QMTPUB:	        AT_QMTPUB_response();
			 							break;
		default : mqtt_pubx_cmds = AT_QMTPUB; break;
	}
}

/*--------------------------Handle the Packets---------------------------*/
void EG25_Packet_Handler(void)
{
	switch(packet_handler)
	{
		case 1: INIT_COMMAND();
				break;
		case 2: MQTT_CMDS();
				break;
		case 3: MQTT_PUBX();
				break;
		default: packet_handler=0;break;
	}
}

void check_alpha(uint8_t *dest,uint8_t *src)
{
	uint8_t i=0;
	 while (CHARISALPHA(*(src+i))
				{
					*(dest+i) = *(src+i);
					i++;
				}
}

void check_number(uint8_t *dest,uint8_t *src)
{
	uint8_t j=0;
	 while (CHARISNUM(*(src+j)))
				{
					*(dest+j) = *(src+j);
					j++;
				}
}

void operator_parse_concat(void)
{
	char operator_res[80];
	char *token,*head,*tail;
	char operator2[30];
	char operator3[30];
	char *rest = operator_res;
	char *cops;

	strtok((char*)EG25Interface.RawRxBuffer,":");
	strtok(NULL,",");
	strtok(NULL,",");
	cops = strtok(NULL,",");
	strtok(NULL,"\r");
	memcpy(operator_res,cops,23);
	printf("%s\r\n",operator_res);

	token = strtok_r(rest, " ", &rest); // Message packet_send_time
	strcpy(operator1,token+1);
	printf("%s \r\n",operator1);
	head = strtok_r(rest, " ", &rest);
	strcpy(operator2,head);
	printf("%s\r\n",operator2);
	strcat(operator1, operator2);
	printf("%s\r\n",operator1);
	tail = strtok_r(rest, " ", &rest);
	check_alpha((uint8_t *)operator3,(uint8_t *)tail);
    /* while (CHARISALPHA(*(tail+i))
			{
		      sms_temp2_buf[i] = *(tail+i);
				  i++;
			}*/
		printf("%s\r\n",operator3);
		printf("%s\r\n",operator1);
}

void time_data_concat(void)
{
	 char *q = NULL;
     strtok((char*)EG25Interface.RawRxBuffer,":");
	 q = strtok(NULL,"\n");
	 strtok(NULL,"\r");
	 memcpy(clk,q+1,23);
	 memcpy(clock,clk+1,23);
	 printf("%s\r\n",clock);
	 q = strtok(clock,"/");
	 if(q[0] == '2')
	  {
	    printf("%s\r\n",clk);
	  }
}

void Signal_strength(void)
{
	 char *s = NULL;
	 s = strtok((char*)EG25Interface.RawRxBuffer,":");
	 s = strtok(NULL,",");
 	 memcpy(signal_strength,s+1,3);
	 printf("%s\r\n",signal_strength);
}

/**********************************************************************************
		@name        : AT_cmd
		@description : Attention Command
		@arguments   : Nothing
		@returns     : Nothing
***********************************************************************************/

void AT_cmd(void)
 {
	char cmd_AT[]="AT\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT,4);
	initial_cmds=AT;
	EG25Interface.TxCount = 4;
	EG25Interface.TxInterfaceEvent = 1;
 }

/* *********************************************************************************
		@name        : ATE0_cmd
		@description : Set Command Echo Mode
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void ATE0_cmd(void)
 {
	char cmd_ATE0[]="ATE0\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_ATE0,6);
	//initial_cmds=AT_CPIN;
	EG25Interface.TxCount =6;
	EG25Interface.TxInterfaceEvent = 1;
 }

/* *********************************************************************************
		@name        : AT_CPIN_cmd
		@description : The command is used to enter a password or query whether or not the module
					  requires a password which is necessary before it can be operated.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CPIN_cmd(void)
 {
	char cmd_AT_CPIN[]="AT+CPIN?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CPIN,10);
	initial_cmds=AT_CPIN;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_CFUN_cmd
		@description : The command controls the functionality level. It can also be used to reset the UE.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CFUN_cmd(void)
 {
	char cmd_AT_CFUN[]="AT+CFUN?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CFUN,10);
	initial_cmds=AT_CFUN;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_COPS_cmd
		@description : The command returns the current operators and their status, and allows setting
						automatic or manual network selection.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_COPS_cmd(void)
 {
	char cmd_AT_COPS[]="AT+COPS?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_COPS,10);
	initial_cmds=AT_COPS;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_CNUM_cmd
		@description : The command can get the subscribers own number(s) from the (U)SIM.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CNUM_cmd(void)
 {
	char cmd_AT_CNUM[]="AT+CNUM?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CNUM,10);
	initial_cmds=AT_CNUM;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_CREG_cmd
		@description : The Read Command returns the network registration status. The write command sets
						whether or not to present URC.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CREG_cmd(void)
 {
	char cmd_AT_CREG[]="AT+CREG?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CREG,10);
	initial_cmds=AT_CREG;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_CREG_cmd2
		@description : The write Command returns the network registration status. The write command sets
						whether or not to present URC.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CREGW_cmd(void)
 {
	char cmd_AT_CREG[]="AT+CREG=1\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CREG,11);
	initial_cmds=AT_CREGW;
	EG25Interface.TxCount =11;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_CREG_cmd2
		@description : The write Command returns the network registration status. The write command sets
						whether or not to present URC.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CREGW2_cmd(void)
 {
	char cmd_AT_CREG[]="AT+CREG=2\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CREG,11);
	initial_cmds=AT_CREGW2;
	EG25Interface.TxCount =11;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_CGATT_cmd
		@description : Attachment or Detachment of PS
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CGATT_cmd(void)
 {
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6,GPIO_PIN_SET);
	char cmd_AT_CGATT[]="AT+CGATT?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CGATT,11);
	initial_cmds=AT_CGATT;
	EG25Interface.TxCount =11;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_CGATT2_cmd
		@description : The Write Command is used to attach the MT to, or detach the MT from the Packet Domain service.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CGATT2_cmd(void)
 {
	char cmd_AT_CGATT[]="AT+CGATT=1\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CGATT,12);
	initial_cmds=AT_CGATT2;
	EG25Interface.TxCount =12;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_GSN_cmd
		@description : The command returns the International Mobile Equipment Identity (IMEI) number of ME.
		@arguments   : Nothing
		@returns     : Nothing
************************************************************************************/
void AT_GSN_cmd(void)
 {
	char cmd_AT_GSN[]="AT+GSN\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_GSN,8);
	initial_cmds=AT_GSN;
	EG25Interface.TxCount =8;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        :AT_CCLK_cmd
		@description : The command sets and queries the real time clock (RTC) of the module. The current setting
						is retained until the module is totally disconnected from power.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_CCLK_cmd(void)
 {
	char cmd_AT_CCLK[]="AT+CCLK?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CCLK,10);
	initial_cmds=AT_CCLK;
	EG25Interface.TxCount =10;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_CSQ_cmd
		@description : The command indicates the received signal strength <rssi> and the channel bit error rate <ber>.
		@arguments   : Nothing
		@returns     : Nothing
**********************************************************************************/
void AT_CSQ_cmd(void)
 {
	char cmd_AT_CSQ[]="AT+CSQ\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_CSQ,8);
	initial_cmds=AT_CSQ;
	EG25Interface.TxCount =8;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_QMTCFG_cmd
		@description : The command is used to configure optional parameters of MQTT.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMTCFG_cmd(void)
 {
	char cmd_AT_QMTCFG[]="AT+QMTCFG=\"recv/mode\",0,0,1\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTCFG,31);
	mqtt_open_cmds=AT_QMTCFG;
	EG25Interface.TxCount = 31;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_QMTCLOSE_cmd
		@description : The command is used to close a network for MQTT client.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMTCLOSE_cmd(void)
 {
	char cmd_AT_QMTCLOSE[]="AT+QMTCLOSE=0\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTCLOSE,15);
	mqtt_open_cmds=AT_QMTCLOSE;
	EG25Interface.TxCount = 15;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_QMTOPEN_cmd
		@description : The command is used to open a network for MQTT client.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMTOPEN_cmd(void)
 {
	char cmd_AT_QMTOPEN[]="AT+QMTOPEN=0,\"broker.hivemq.com\",1883\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTOPEN,41);
	mqtt_open_cmds=AT_QMTOPEN;
	EG25Interface.TxCount = 41;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_QMTCONN_cmd
		@description : The command is used when a client requests a connection to MQTT server.
		@arguments   : Nothing
		@returns     : Nothing
\**********************************************************************************/

void AT_QMTCONN_cmd(void)
 {
	char cmd_AT_QMTCONN[]="AT+QMTCONN=0,\"2928\"\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTCONN,23);
	mqtt_open_cmds=AT_QMTCONN;
	EG25Interface.TxCount = 23;
	EG25Interface.TxInterfaceEvent = 1;
 }

#if 0
void AT_QMTCONN_cmd(void)
 {
	char cmd_AT_QMTCONN[]="AT+QMTCONN?\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTCONN,11);
	mqtt_open_cmds=AT_QMTCONN;
	EG25Interface.TxCount = 11;
	EG25Interface.TxInterfaceEvent = 1;
 }
#endif
/**********************************************************************************
		@name        : AT_QMTSUB_cmd
		@description : The command is used to subscribe to one or more topics. A SUBSCRIBE message is sent by a
						client to register an interest in one or more topic names with the server.
		@arguments   : Nothing
		@returns     : Nothing
**********************************************************************************/
void AT_QMTSUB_cmd(void)
 {
	char cmd_AT_QMTSUB[]="AT+QMTSUB=0,1,\"DHRUVA_SPACE\",0\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTSUB,34);
	mqtt_open_cmds=AT_QMTSUB;
	EG25Interface.TxCount = 34;
	EG25Interface.TxInterfaceEvent = 1;
 }
/* *********************************************************************************
		@name        : AT_QMTPUB_cmd
		@description : The command is used to publish messages by a client to a server for distribution to
					interested subscribers.Each PUBLISH message is associated with a topic name. I
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMTPUB_cmd(void)
 {
//	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6,GPIO_PIN_SET);
	char cmd_AT_QMTPUB[]="AT+QMTPUBEX=0,0,0,0,\"DHRUVA_SPACE\",50\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTPUB,41);
	mqtt_pubx_cmds=AT_QMTPUB;
	EG25Interface.TxCount = 41;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_QMTDSC_cmd
		@description : The command is used when a client requests a disconnection from MQTT server.
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMTDSC_cmd(void)
 {
	char cmd_AT_QMTDSC[]="AT+QMTDISC=0\r\n";
	strncpy((char*)&EG25Interface.RawTxBuffer,cmd_AT_QMTDSC,14);
	mqtt_open_cmds=AT_QMTDSC;
	EG25Interface.TxCount = 14;
	EG25Interface.TxInterfaceEvent = 1;
 }
/**********************************************************************************
		@name        : AT_QMT_SEND_DATA
		@description : This data send to MQTT server
		@arguments   : Nothing
		@returns     : Nothing
********************************************************************************* */
void AT_QMT_SEND_DATA(void)
 {
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_6,GPIO_PIN_SET);
//		strncpy(Sendserverdata ,server_buffer,30);
//   	strncpy((char*)&EG25Interface.RawTxBuffer,(const char *)Sendserverdata,30);
//  	strncpy((char*)&EG25Interface.RawTxBuffer,(const char *)tbuffer,30);
//    	strncpy((char*)&EG25Interface.RawTxBuffer,(const char *)hbuffer,30);
		cel = SHT2x_GetTemperature(1);
		rh  = SHT2x_GetRelativeHumidity(1);
		sprintf(server_buffer,"Temp:%d.%d C,Hmdt:%d.%d RH,RSSI:%s",SHT2x_GetInteger(cel),SHT2x_GetDecimal(cel, 1),SHT2x_GetInteger(rh),SHT2x_GetDecimal(rh, 1),RSSI);
//	printf("SENDING THIS DATA : %s",(char*)server_buffer);
//	printf("%d\r\n",RSSI);
    strncpy((char*)&EG25Interface.RawTxBuffer,(char*)server_buffer,50);
	mqtt_pubx_cmds = AT_QMTPUB;
	EG25Interface.TxCount = 50;
	EG25Interface.TxInterfaceEvent = 1;
//	memset(server_buffer,0,sizeof(server_buffer));
 }
/* *********************************************************************************
		@name        : AT_response
		@description : AT Command Response
		@arguments   : Nothing
		@Response	: OK-->Goto CPIN command
					  ERROR--> AT_cmd
					  Nothing-->Start from AT_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_response(void)
 {
//	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
    	{
//		    ATE0_cmd();
			AT_CPIN_cmd();
    	}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
			AT_cmd();
		}
	else
		{
			AT_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_CPIN_response
		@description : Response from AT_CPIN Command
		@arguments   : Nothing
		@Response	: OK-->Goto CFUN command
					  ERROR-->  CPIN Command
					  Nothing-->Start from AT_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_CPIN_response(void)
 {
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strncmp ((char*)EG25Interface.RawRxBuffer,"OK\r\n",4))
		{
			AT_CFUN_cmd();
		}
	else if(strstr((char*) EG25Interface.RawRxBuffer,"+CME ERROR: 10"))
		{
			AT_CPIN_cmd();
		}
	else
		{
			AT_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_CFUN_response
		@description : Response from AT_CFUN Command
		@arguments   : Nothing
		@Response	: OK-->Goto COPS command
					  ERROR--> Goto CFUN Command
					  Nothing-->Start from AT_CPIN
		@returns     : Nothing
********************************************************************************* */
void AT_CFUN_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
			AT_COPS_cmd();
		}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
			AT_CFUN_cmd();
		}
	else
		{
			AT_CPIN_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_COPS_response
		@description : Response from AT_COPS Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_CREG command
					  ERROR--> Goto AT_CPOS Command
					  Nothing-->Start from AT_CFUN
					  0-->Start From AT_Cmd
		@returns     : Nothing
********************************************************************************* */
void AT_COPS_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"+COPS: 0\r\n")!= NULL)
    	{
			AT_cmd();
		}
	else if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
			operator_parse_concat();
			AT_CREG_cmd();
		}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
			AT_COPS_cmd();
		}
	else
		{
			AT_CFUN_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_CREG_response
		@description : Response from AT_CREG Command
		@arguments   : Nothing
		@Response	: 0,1-->Goto AT_CGATT command
					  0,2--> Goto AT_CREG Command
					  Nothing-->Start from AT_Cops
		@returns     : Nothing
**********************************************************************************/
void AT_CREG_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,1\r\n")!= NULL)
		{
			AT_CGATT_cmd();
     	}
	else if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,2\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,3\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,4\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,0\r\n")!= NULL) )
	    {
			AT_COPS_cmd();
//		   AT_CREGW_cmd();
		}
//	else if (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 1,3\r\n")!= NULL)
//		{
//			AT_CREGW2_cmd();
//		}
	else
	{
		AT_COPS_cmd();
	}
 }
/* *********************************************************************************
		@name        : AT_CREGW_response
		@description : Response from AT_CREG Command
		@arguments   : Nothing
		@Response	: 0,1-->Goto AT_CGATT command
					  0,2--> Goto AT_CREG Command
					  Nothing-->Start from AT_Cops
		@returns     : Nothing
**********************************************************************************/
void AT_CREGW_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,1\r\n")!= NULL)
		{
			AT_CGATT_cmd();
     	}
	else if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,2\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,3\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,4\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,0\r\n")!= NULL)||(strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 1,3\r\n")!= NULL) )
	    {
//			AT_COPS_cmd();
//		   AT_CREG_cmd();
			AT_CREGW2_cmd();
		}
	else if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
			{
				AT_CREG_cmd();
	//			AT_COPS_cmd();
			}
	else
		{
			AT_COPS_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_CREGW2_response
		@description : Response from AT_CREG Command
		@arguments   : Nothing
		@Response	: 0,1-->Goto AT_CGATT command
					  0,2--> Goto AT_CREG Command
					  Nothing-->Start from AT_Cops
		@returns     : Nothing
**********************************************************************************/
void AT_CREGW2_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,1\r\n")!= NULL)
		{
			AT_CGATT_cmd();
     	}
	else if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,2\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,3\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,4\r\n")!= NULL) || (strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 0,0\r\n")!= NULL)||(strstr ((char*)EG25Interface.RawRxBuffer,"+CREG: 1,3\r\n")!= NULL) )
	    {
//			AT_COPS_cmd();
			AT_CREG_cmd();
//		AT_CREGW2_cmd();
		}
	else if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
			{
				AT_CREG_cmd();
	//			AT_COPS_cmd();
			}
	else
		{
			AT_COPS_cmd();
		}
 }
/**********************************************************************************
		@name        : AT_CNUM_response
		@description : Response from AT_CNUM Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_CGATT command
					  ERROR--> Goto AT_CNUM Command
					  Nothing-->Start from AT_CREG
		@returns     : Nothing
********************************************************************************* */
void AT_CNUM_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
			AT_CGATT_cmd();
		}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
			AT_CNUM_cmd();
		}
	else
		{
			AT_CREG_cmd();
		}
 }
/**********************************************************************************
		@name        : AT_CGATT_response
		@description : Response from AT_CGATT Command
		@arguments   : Nothing
		@Response	: 1-->Goto AT_CCLK command
					  0--> Goto AT_CGATT2 Command
					  Nothing-->Start from AT_CREG_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_CGATT_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
    if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CGATT: 1\r\n")!= NULL))
	{
	   AT_CCLK_cmd();
	}
	else if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CGATT: 0\r\n")!= NULL))
	{
		AT_CGATT2_cmd();
//		EG25Interface.EOP_Timer = (140*1000);
	}
	else
	{
		AT_CREG_cmd();
	}
 }
/* *********************************************************************************
		@name        : AT_CGATT2_response
		@description : Response from AT_CGATT2 Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_CCLK command
					  Nothing-->Start from AT_CREG_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_CGATT2_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
    if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
	{
    	AT_CCLK_cmd();
	}
//	else if ((strstr ((char*)EG25Interface.RawRxBuffer,"+CGATT: 0\r\n")!= NULL))
//	{
//		AT_CGATT2_cmd();
//	}
	else
	{
		AT_CREG_cmd();
	}
 }
/**********************************************************************************
		@name        : AT_CCLK_response
		@description : Response from AT_CCLK Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_GSN command
					  ERROR--> Goto AT_CCLK Command
					  Nothing-->Start from AT_CGATT_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_CCLK_response(void)
 {
	printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
 	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
     	   char *q = NULL;
           strtok((char*)EG25Interface.RawRxBuffer,":");
	       q = strtok(NULL,"\n");
	       strtok(NULL,"\r");
	       memcpy(clk,q+1,23);
	       memcpy(clock,clk+1,23);
	       printf("%s\r\n",clock);
	       q = strtok(clock,"/");
	       if(q[0] == '2')
	         {
		        AT_GSN_cmd();
	            printf("%s\r\n",clk);
	         }
	       else
	         {
	    	   AT_GSN_cmd();
//	        	AT_CCLK_cmd();
	         }
        }
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
		 	AT_CCLK_cmd();
		}
	else
	{
		AT_CGATT_cmd();
	}
 }

/**********************************************************************************
		@name        : AT_GSN_response
		@description : Response from AT_GSN Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_CSQ command
					  ERROR--> Goto AT_CSQ Command
					  Nothing-->Start from AT_CCLK_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_GSN_response(void)
 {
	char *p = NULL;
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
	    {
		   strtok((char*)EG25Interface.RawRxBuffer,"\n");
	       p = strtok(NULL,"\r");
	       memcpy(dev_id,p,15);
		   printf("%s\r\n",dev_id);
//		   packet_handler=2;
//		   AT_QMTCFG_cmd();
//		   AT_QMTOPEN_cmd();
//		   EG25Interface.EOP_Timer = (120*1000);
		   AT_CSQ_cmd();
//		   HAL_Delay(10000);
		}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
	    {
//		   AT_GSN_cmd();
		   AT_CSQ_cmd();
		}
	else
		{
			AT_CCLK_cmd();
		}
 }
/**********************************************************************************
		@name        : AT_CSQ_response
		@description : Response from AT_CSQ Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_QMTCFG command
					  ERROR--> Goto AT_CSQ Command
					  Nothing-->Start from AT_GSN_cmd
					  0-->Start From AT_Cmd
		@returns     : Nothing
**********************************************************************************/
void AT_CSQ_response(void)
 {
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
//    strncpy((char*)&EG25Interface.RawRxBuffer,RSSI,30);
    strncpy((char*)RSSI,(char*) EG25Interface.RawRxBuffer,30);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
           Signal_strength();
	       packet_handler++;
	       AT_QMTCFG_cmd();
		}
	else if(strncmp((char*) EG25Interface.RawRxBuffer,"ERROR\r\n",7))
		{
			AT_CSQ_cmd();
		}
	else
		{
			AT_GSN_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_QMTCLOSE_response
		@description : Response from AT_QMTCLOSE Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_QMTOPEN command
					  Nothing-->Start from AT_QMTCFG_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_QMTCLOSE_response(void)
 {
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
	{
		 AT_QMTOPEN_cmd();
	}
	else
	{
//		 AT_QMTCFG_cmd();
//		AT_CGATT_cmd();
		packet_handler=1;
		AT_cmd();
	}
 }
/**********************************************************************************
		@name        : AT_QMTCFG_response
		@description : Response from AT_QMTCFG Command
		@arguments   : Nothing
		@Response	: OK-->Goto AT_QMTOPEN command
					  Nothing-->Start from AT_QMTDSC_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_QMTCFG_response(void)
 {
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
	{
		 AT_QMTOPEN_cmd();
	}
	else
	{
		 AT_QMTDSC_cmd();
	}
 }

/**********************************************************************************
		@name        : AT_QMTOPEN_response
		@description : Response from AT_QMTOPEN Command
		@arguments   : Nothing
		@Response	: (0,0) or (0.1) or (0,2) -->Goto AT_QMTCONN command
					  Nothing-->Start from AT_QMTCLOSE_cmd
		@returns     : Nothing
\* ----------------------------------------------------------------------------- */
void AT_QMTOPEN_response(void)
 {
    printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if ((strstr ((char*)EG25Interface.RawRxBuffer,"+QMTOPEN: 0,0\r\n")!= NULL) ||
			(strstr ((char*)EG25Interface.RawRxBuffer,"+QMTOPEN: 0,1\r\n")!= NULL) ||
			(strstr ((char*)EG25Interface.RawRxBuffer,"+QMTOPEN: 0,2\r\n")!= NULL))
		{
	       AT_QMTCONN_cmd();
		}
	else if (strstr ((char*)EG25Interface.RawRxBuffer,"+QMTOPEN: OK\r\n")!= NULL)
			{
				AT_QMTOPEN_cmd();
			}
	else
		{
		   AT_QMTCLOSE_cmd();
		}
 }
/* *********************************************************************************
		@name        : AT_QMTCONN_response
		@description : Response from AT_QMTCONN Command
		@arguments   : Nothing
		@Response	: 0,0,0 -->Goto AT_QMTSUB command
					  Nothing-->Start from AT_QMTDSC_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_QMTCONN_response(void)
 {
   printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
   if (strstr ((char*)EG25Interface.RawRxBuffer,"+QMTCONN: 0,0,0\r\n")!= NULL)
//   if (strstr ((char*)EG25Interface.RawRxBuffer,"OK\r\n")!= NULL)
		{
//	   AT_QMTCONN2_cmd();
	   	   AT_QMTSUB_cmd();
	}
	else
		{
				AT_QMTDSC_cmd();
//			EG25Interface.EOP_Timer = (30*1000);
		}
 }

/* *********************************************************************************
		@name        : AT_QMTSUB_response
		@description : Response from AT_QMTSUB Command
		@arguments   : Nothing
		@Response	: 0,1,0,0 -->Goto AT_QMTPUB command
					  Nothing-->Start from AT_QMTDSC_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_QMTSUB_response(void)
 {
   printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
   if (strstr ((char*)EG25Interface.RawRxBuffer,"+QMTSUB: 0,1,0,0\r\n")!= NULL)
	{
		  packet_handler=3;
		  AT_QMTPUB_cmd();
//		  signal_EOT_Timer = 15000;
	}
	else
	{
		AT_QMTDSC_cmd();
//		EG25Interface.EOP_Timer = (30*1000);
	}
 }
/*********************************************************************************
		@name        : AT_QMTPUB_response
		@description : Response from AT_QMTPUB Command
		@arguments   : Nothing
		@Response	: > -->Goto AT_QMT_SEND_DATA command
					  OK,(0,0,0) -->Goto AT_QMT_SEND_DATA command
					  ERROR-->Start from AT_QMTDSC_cmd
					  Nothing-->Start from AT_cmd
		@returns     : Nothing
********************************************************************************* */
void AT_QMTPUB_response(void)
 {
   printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
   if (strstr ((char*)EG25Interface.RawRxBuffer,">")!= NULL)
	   	{
		   printf("LOOP 1\r\n");
    	   memset((char*)EG25Interface.RawTxBuffer,0,sizeof(EG25Interface.RawTxBuffer));
	   	   EG25Interface.TxPointer =0;
	   	   AT_QMT_SEND_DATA();
//	   	   GET_SHT21_DATA();
//	   	   CUSTOM_UHF();
//	   	   CUSTOM_LoRa();
	    }
   else if((strncmp ((char*)EG25Interface.RawRxBuffer,"OK\r\n",4))||(strncmp ((char*)EG25Interface.RawRxBuffer,"+QMTRECV:\r\n",12)))
   	    {
	   	   if((strstr ((char*)EG25Interface.RawRxBuffer,"+QMTPUBEX: 0,0,0")!= NULL))
	   	   {
     	   		    printf("LOOP 2\r\n");
     	   		    Module = 1;
	   		   	   	AT_QMTPUB_cmd();
//	   		   	   	GET_SHT21_DATA();
//	   			   	CUSTOM_UHF();
//	   			   	CUSTOM_LoRa();
	   	   }
#if 0
	   	   else if((strstr ((char*)EG25Interface.RawRxBuffer,"ERROR")!= NULL)||(strstr ((char*)EG25Interface.RawRxBuffer,"+QMTSTAT: 0,1")!= NULL)||(strstr ((char*)EG25Interface.RawRxBuffer,"+QMTSTAT: 0,3")!= NULL))
	   	   {
	   		    printf("LOOP 3\r\n");
	   		    Module = 1;
	   		    packet_handler=1;
//	   			AT_QMTDSC_cmd();
//	   		    mqtt_open_cmds=2;
//	   			AT_QMTOPEN_cmd();
	   		    AT_cmd();
	   	   }
#endif
	   	   else
	   	   {
	   		 packet_handler=1;
//	   		AT_QMTOPEN_cmd();
	   		AT_cmd();
	   		 Module = 1;
//	   		 AT_QMTPUB_cmd();
//	   		 AT_QMTDSC_cmd();
	   		 printf("LOOP 4\r\n");
	   	   }
   	    }
#if 0
   else if(strncmp ((char*)EG25Interface.RawRxBuffer,"+QMTRECV:\r\n",12))
   {
	   if((strstr ((char*)EG25Interface.RawRxBuffer,"+QMTPUBEX: 0,0,0")!= NULL))
	   {
		   printf("LOOP 5\r\n");
		   Module = 1;
		   AT_QMTPUB_cmd();
	   }
	   else
	   {
		   printf("LOOP 6\r\n");
		   Module = 1;
		   AT_QMTPUB_cmd();
	   }
   }

   else if(strncmp ((char*)EG25Interface.RawRxBuffer,"ERROR",5))
   {
	   printf("LOOP 7\r\n");
	   AT_QMTDSC_cmd();
   }
#endif
   else
   {
	   printf("LOOP 8\r\n");
	   packet_handler=1;
	   AT_cmd();
//	   AT_QMTDSC_cmd();
   }
//	memset(server_buffer,"\0",strlen(server_buffer));

 }
/**********************************************************************************
		@name        : AT_QMTDSC_response
		@description : Response from AT_QMTDSC Command
		@arguments   : Nothing
		@Response	: (OK) or(0,0) -->Goto AT_QMTOPEN command
					  Nothing-->Start from AT_QMTCLOSE_cmd
		@returns     : Nothing
**********************************************************************************/
void AT_QMTDSC_response(void)
{
   printf("%s\r\n",(char*) EG25Interface.RawRxBuffer);
	if ((strstr ((char*)EG25Interface.RawRxBuffer,"OK")!= NULL)||
			(strstr ((char*)EG25Interface.RawRxBuffer,"+QMTDISC: 0,0")!= NULL))
	{
		AT_QMTOPEN_cmd();

//		EG25Interface.EOP_Timer = (120*1000);
	}
	else if (strstr ((char*)EG25Interface.RawRxBuffer,"ERROR")!= NULL)
	{
//		 packet_handler=1;
		 AT_QMTCFG_cmd();
	}
	else
	{
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,GPIO_PIN_SET);
		AT_QMTCLOSE_cmd();
//		AT_QMTDSC_cmd();
//		EG25Interface.EOP_Timer = (30*1000);
	}
 }



