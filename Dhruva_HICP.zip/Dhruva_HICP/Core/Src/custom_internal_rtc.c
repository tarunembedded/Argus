/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    custom_internal_rtc.c
  * @brief   This file provides code for the configuration
  *          of all used to custom_internal_rtc.
  * @Author  Argus Team
  ******************************************************************************
  */
/* USER CODE END Header */

#include "main.h"
#include "rtc.h"
#include "log.h"
#include "custom_internal_rtc.h"

void set_time(void)
{
		RTC_TimeTypeDef sTime = {0};
		RTC_DateTypeDef sDate = {0};

		if(HAL_RTCEx_BKUPRead(&hrtc, RTC_BKP_DR4) != 0x27)
		{
			 LOG("Initializing RTC\r\n");
/*----------------------Set the Time---------------*/
		sTime.Hours = 0x15;
		sTime.Minutes = 0x10;
		sTime.Seconds = 0x00;
		sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
		sTime.StoreOperation = RTC_STOREOPERATION_RESET;
		if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
		{
			Error_Handler();
		}
/*-------------------Set Date----------------------------*/
	  sDate.WeekDay = RTC_WEEKDAY_SATURDAY;
	  sDate.Month = RTC_MONTH_JANUARY;
	  sDate.Date = 0x06;
	  sDate.Year = 0x24;
	  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
	  {
	    Error_Handler();
	  }
	  HAL_RTCEx_BKUPWrite(&hrtc, RTC_BKP_DR4,0x27);
	}
		else
			LOG("Already RTC Initialized\r\n");
}
/*--------------Getting Date and Time-------------------------*/
void get_time(void)
{
	RTC_TimeTypeDef gTime;
	RTC_DateTypeDef gDate;
	HAL_RTC_GetTime(&hrtc, &gTime, RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&hrtc, &gDate, RTC_FORMAT_BIN);

	LOG("\r\nTIME: %02d:%02d:%02d\r\n",gTime.Hours,gTime.Minutes,gTime.Seconds);
	LOG("DATE: %2d-%2d-%2d\r\n",gDate.Date,gDate.Month,2000+gDate.Year);
}
void set_alarm(void);


