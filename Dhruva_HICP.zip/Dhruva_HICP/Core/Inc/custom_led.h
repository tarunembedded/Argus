/*
 * custom_led.h
 *
 *  Created on: Nov 9, 2023
 *      Author: Argus Team
 */

#ifndef INC_CUSTOM_LED_H_
#define INC_CUSTOM_LED_H_

#include "main.h"

/*LED1 Functionality*/
#define LED1_OFF()        HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_RESET) // user defined Macro for actual code related to LED_OFF
#define LED1_ON()         HAL_GPIO_WritePin(LED1_GPIO_Port,LED1_Pin,GPIO_PIN_SET)	// user defined Macro for actual code related to LED_ON

/*LED2 Functionality*/
#define LED2_OFF()        HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_RESET) // user defined Macro for actual code related to LED_OFF
#define LED2_ON()         HAL_GPIO_WritePin(LED2_GPIO_Port,LED2_Pin,GPIO_PIN_SET)	// user defined Macro for actual code related to LED_ON

void LED_TEST(void);	// user defined Function prototype for actual code related to LED_TEST

#endif /* INC_CUSTOM_LED_H_ */
