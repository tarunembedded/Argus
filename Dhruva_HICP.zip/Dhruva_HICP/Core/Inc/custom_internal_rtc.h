/*
 * custom_internal_rtc.h
 *
 *  Created on: Nov 9, 2023
 *      Author: Argus Team
 */

#ifndef INC_CUSTOM_INTERNAL_RTC_H_
#define INC_CUSTOM_INTERNAL_RTC_H_

void set_time(void); 	// user defined Function prototype for actual code related to Set Time
void get_time(void);	// user defined Function prototype for actual code related to get time
void set_alarm(void);	// user defined Function prototype for actual code related to set alarm



#endif /* INC_CUSTOM_INTERNAL_RTC_H_ */
