/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define MCU_RI_Pin GPIO_PIN_13
#define MCU_RI_GPIO_Port GPIOC
#define BAT_ADC_Pin GPIO_PIN_2
#define BAT_ADC_GPIO_Port GPIOC
#define CHARGE_SENSE_Pin GPIO_PIN_3
#define CHARGE_SENSE_GPIO_Port GPIOC
#define USART2_GSM_CTS_Pin GPIO_PIN_0
#define USART2_GSM_CTS_GPIO_Port GPIOA
#define USART2_GSM_RTS_Pin GPIO_PIN_1
#define USART2_GSM_RTS_GPIO_Port GPIOA
#define USART2_GSM_RXD_Pin GPIO_PIN_2
#define USART2_GSM_RXD_GPIO_Port GPIOA
#define USART2_GSM_TXD_Pin GPIO_PIN_3
#define USART2_GSM_TXD_GPIO_Port GPIOA
#define ADC1_Pin GPIO_PIN_4
#define ADC1_GPIO_Port GPIOA
#define USB_USART3_RX_Pin GPIO_PIN_4
#define USB_USART3_RX_GPIO_Port GPIOC
#define USB_USART3_TX_Pin GPIO_PIN_5
#define USB_USART3_TX_GPIO_Port GPIOC
#define LED1_Pin GPIO_PIN_0
#define LED1_GPIO_Port GPIOB
#define LED2_Pin GPIO_PIN_1
#define LED2_GPIO_Port GPIOB
#define RF_DIO0_Pin GPIO_PIN_2
#define RF_DIO0_GPIO_Port GPIOB
#define RF_SPI2_CS_Pin GPIO_PIN_12
#define RF_SPI2_CS_GPIO_Port GPIOB
#define RF_SPI2_SCK_Pin GPIO_PIN_13
#define RF_SPI2_SCK_GPIO_Port GPIOB
#define RF_SPI2_MISO_Pin GPIO_PIN_14
#define RF_SPI2_MISO_GPIO_Port GPIOB
#define RF_SPI2_MOSI_Pin GPIO_PIN_15
#define RF_SPI2_MOSI_GPIO_Port GPIOB
#define MC_DTR_Pin GPIO_PIN_6
#define MC_DTR_GPIO_Port GPIOC
#define ONOFF_MCU_Pin GPIO_PIN_7
#define ONOFF_MCU_GPIO_Port GPIOC
#define RESET_MCU_Pin GPIO_PIN_8
#define RESET_MCU_GPIO_Port GPIOC
#define RF96_RESET_Pin GPIO_PIN_9
#define RF96_RESET_GPIO_Port GPIOC
#define UHF_RESET_Pin GPIO_PIN_8
#define UHF_RESET_GPIO_Port GPIOA
#define UART1_RX_Pin GPIO_PIN_9
#define UART1_RX_GPIO_Port GPIOA
#define UART1_TX_Pin GPIO_PIN_10
#define UART1_TX_GPIO_Port GPIOA
#define UART1_CTS_Pin GPIO_PIN_11
#define UART1_CTS_GPIO_Port GPIOA
#define UART1_RTS_Pin GPIO_PIN_12
#define UART1_RTS_GPIO_Port GPIOA
#define W_DISABLE_MCU_Pin GPIO_PIN_10
#define W_DISABLE_MCU_GPIO_Port GPIOC
#define WAKEUP_IN_MCU_Pin GPIO_PIN_11
#define WAKEUP_IN_MCU_GPIO_Port GPIOC
#define AP_RDY_MCU_Pin GPIO_PIN_12
#define AP_RDY_MCU_GPIO_Port GPIOC
#define SPI1_CS_Pin GPIO_PIN_2
#define SPI1_CS_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
