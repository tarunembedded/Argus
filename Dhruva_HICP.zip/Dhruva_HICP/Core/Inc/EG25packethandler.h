/*
 * EG25packethandler.h
 *
 *  Created on: Nov 1, 2023
 *      Author: Argus Team
 */


#ifndef INC_EG25PACKETHANDLER_H_
#define INC_EG25PACKETHANDLER_H_


/* Define to prevent recursive inclusion -------------------------------------*/


#ifdef __cplusplus
 extern "C" {
#endif
typedef enum _EG25_list_cmd
	 {
		 AT=1,AT_CPIN,AT_CFUN,AT_CNUM,AT_COPS,AT_CREG,AT_CREGW,AT_CREGW2,AT_CGATT,AT_CGATT2,AT_CCLK,AT_GSN,AT_CSQ,AT_QMTCFG,AT_QMTCLOSE,AT_QMTOPEN,AT_QMTCONN,AT_QMTCONN2,AT_QMTSUB,AT_QMTPUB,AT_QMTDSC
     }EG25_list_cmd;

typedef enum _EG25_list_cmd_read_regular
	 {
		 AT_CSQ_REGULAR_READ = 1,
	 }EG25_list_cmd_read_regular;

void EG25_Packet_Handler(void);		// user defined Function prototype for actual code related EG25_Packet_Handler
void INIT_COMMAND(void);			// user defined Function prototype for actual code related INIT_COMMAND
void MQTT_CMDS(void);				// user defined Function prototype for actual code related MQTT_CMDS
void MQTT_PUBX(void);				// user defined Function prototype for actual code related MQTT_PUBX

/*----------------------------------------AT Commands-----------------------------------------*/
void AT_cmd(void);					// user defined Function prototype for actual code related AT_cmd
void AT_CPIN_cmd(void);				// user defined Function prototype for actual code related AT_CPIN_cmd
void AT_CFUN_cmd(void);				// user defined Function prototype for actual code related AT_CFUN_cmd
void AT_COPS_cmd(void);				// user defined Function prototype for actual code related AT_COPS_cmd
void AT_CNUM_cmd(void);				// user defined Function prototype for actual code related AT_CNUM_cmd
void AT_CREG_cmd(void);				// user defined Function prototype for actual code related AT_CREG_cmd
void AT_CREGW_cmd(void);
void AT_CREGW2_cmd(void);
void AT_CGATT_cmd(void);			// user defined Function prototype for actual code related AT_CGATT_cmd
void AT_CGATT2_cmd(void);			// user defined Function prototype for actual code related AT_CGATT2_cmd
void AT_GSN_cmd(void);				// user defined Function prototype for actual code related AT_GSN_cmd
void AT_CCLK_cmd(void);				// user defined Function prototype for actual code related AT_CCLK_cmd
void AT_CSQ_cmd(void);				// user defined Function prototype for actual code related AT_CSQ_cmd
void AT_CSQ_cmd_read_regular(void);	// user defined Function prototype for actual code related AT_CSQ_cmd_read_regular
void AT_QPOWD_cmd(void);			// user defined Function prototype for actual code related AT_QPOWD_cmd
void ATE0_cmd(void);				// user defined Function prototype for actual code related ATE0_cmd

/*---------------------AT Commands Response-------------------------------------------------------*/
void AT_response(void);				// user defined Function prototype for actual code related AT_response
void AT_CPIN_response(void);		// user defined Function prototype for actual code related AT_CPIN_response
void AT_CFUN_response(void);		// user defined Function prototype for actual code related AT_CFUN_response
void AT_COPS_response(void);		// user defined Function prototype for actual code related AT_COPS_response
void AT_CNUM_response(void);		// user defined Function prototype for actual code related AT_CNUM_response
void AT_CREG_response(void);		// user defined Function prototype for actual code related AT_CREG_response
void AT_CREGW_response(void);
void AT_CREGW2_response(void);
void AT_CGATT_response(void);		// user defined Function prototype for actual code related AT_CGATT_response
void AT_CGATT2_response(void);		// user defined Function prototype for actual code related AT_CGATT2_response
void AT_GSN_response(void);			// user defined Function prototype for actual code related AT_GSN_response
void AT_CCLK_response(void);		// user defined Function prototype for actual code related AT_CCLK_response
void AT_CSQ_response(void);			// user defined Function prototype for actual code related AT_CSQ_response

/*----------------------------MQTT Commands--------------------------------------------------*/
void AT_QMTCLOSE_cmd(void);			// user defined Function prototype for actual code related AT_QMTCLOSE_cmd
void AT_QMTCLOSE_response(void);	// user defined Function prototype for actual code related AT_QMTCLOSE_response
void AT_QMTCFG_cmd(void);			// user defined Function prototype for actual code related AT_QMTCFG_cmd
void AT_QMTCFG_response(void);		// user defined Function prototype for actual code related AT_QMTCFG_response
void AT_QMTOPEN_cmd(void);			// user defined Function prototype for actual code related AT_QMTOPEN_cmd
void AT_QMTOPEN_response(void);		// user defined Function prototype for actual code related AT_QMTOPEN_response
void AT_QMTOPEN2_cmd(void);			// user defined Function prototype for actual code related AT_QMTOPEN2_cmd
void AT_QMTOPEN2_response(void);	// user defined Function prototype for actual code related AT_QMTOPEN2_response
void AT_QMTCONN_cmd(void);			// user defined Function prototype for actual code related AT_QMTCONN_cmd
void AT_QMTCONN2_cmd(void);			// user defined Function prototype for actual code related AT_QMTCONN2_cmd
void AT_QMTCONN_response(void);		// user defined Function prototype for actual code related AT_QMTCONN_response
void AT_QMTCONN2_response(void);	// user defined Function prototype for actual code related AT_QMTCONN2_response
void AT_QMTSUB_cmd(void);			// user defined Function prototype for actual code related AT_QMTSUB_cmd
void AT_QMTSUB_response(void);		// user defined Function prototype for actual code related AT_QMTSUB_response
void AT_QMTPUB_cmd(void);			// user defined Function prototype for actual code related AT_QMTPUB_cmd
void AT_QMTPUB_response(void);		// user defined Function prototype for actual code related AT_QMTPUB_response
void AT_QMTDSC_cmd(void);			// user defined Function prototype for actual code related AT_QMTDSC_cmd
void AT_QMTDSC_response(void);		// user defined Function prototype for actual code related AT_QMTDSC_response

void operator_parse_concat(void);	// user defined Function prototype for actual code related operator_parse_concat
void time_data_concat(void);		// user defined Function prototype for actual code related time_data_concat
	 #ifdef __cplusplus
}
#endif


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

#endif /* INC_EG25PACKETHANDLER_H_ */

