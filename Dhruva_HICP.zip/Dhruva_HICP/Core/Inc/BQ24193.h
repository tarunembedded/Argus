/*
 * BQ24193 Battery Management header file
 *
 *  Created on: Dec 23, 2023
 *      Author: HP CORE I3
 */

#ifndef INC_BQ24193_H_
#define INC_BQ24193_H_

/* Includes ------------------------------------------------------------------*/
#include "main.h"
/* Private define ------------------------------------------------------------*/
static const uint8_t system_init_reg			=	0x0A;		//Device system status Register TX
static const uint8_t device_id_reg				=	0x00;		//Device ID register address
static const uint8_t vendor_part_reg			=	0x01;		//Vendor part ID register address
static const uint8_t chrg_current_ctrl_reg		=	0x02;		//charging current control register
static const uint8_t pre_chrg_current_ctrl_reg	=	0x03;		//pre-charge/Termination current control register
static const uint8_t chrg_vtg_ctrl_reg			=	0x04;		//charge voltage control register
static const uint8_t chrg_trminal_ctrl_reg		=	0x05;		//charge termination /Timer control register
static const uint8_t thrmal_regulation_ctrl_reg	=	0x06;		//Thermal regulation control register
static const uint8_t misc_oprtn_ctrl_reg		=	0x07;		//Thermal regulation control register
static const uint8_t system_stat_reg			=	0x08;		//Device system status Register

extern I2C_HandleTypeDef hi2c1;
#define BATTERY_DELAY (10*100)

//#define BAT_MIN_VALUE  10160
//#define BAT_MAX_VALUE  11760

#define BAT_MIN_VALUE	11081
#define BAT_MAX_VALUE	12273


/* Private function prototypes -----------------------------------------------*/
void BATTERY_CHARGING_Init(void);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);
uint16_t BATTERY_CHARGING_SENSING(void);
void system_status(void);
void percentage_value(uint16_t,uint8_t);
void custom_battery(void);

#ifdef __cplusplus
}
#endif



#endif /* INC_BQ24193_H_ */
