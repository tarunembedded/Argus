/*
 * EG25Interface.h
 *
 *  Created on: Nov 1, 2023
 *      Author: Argus Team
 */

#ifndef INC_EG25INTERFACE_H_
#define INC_EG25INTERFACE_H_


/* Define to prevent recursive inclusion -------------------------------------*/

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx.h"
#include "stdio.h"
#include "string.h"

#define EG25_INTERFACE_MAX_LEN		255
#define EG25_INTERFACE_MAX_LEN_RX	767

typedef void (*USART_ISR_FUNC) (USART_TypeDef* base);
/* Exported types of Structure Variables----------------------------------------- */
typedef	struct {
uint8_t	InterfaceType;
uint8_t	InterfaceAddress;
uint8_t	TxPointer;
uint16_t RxPointer;

uint16_t RxCount;
uint8_t	TxCount;
uint8_t	RxInterfaceEvent;
uint8_t	TxInterfaceEvent;

uint8_t RawRxBuffer[EG25_INTERFACE_MAX_LEN_RX +1];
uint8_t RawTxBuffer[EG25_INTERFACE_MAX_LEN+1];

uint32_t        EOP_Timer;
uint32_t        EOP_Timeout;
} tEG25Interface, *ptEG25Interface;

/* Exported Variables ------------------------------------------------------- */
extern	volatile tEG25Interface EG25Interface;

/* Exported functions ------------------------------------------------------- */
extern	void EG25InterfaceUART_Init(void);
extern	void EG25InterfaceHandler(uint8_t count);
extern  void EG25InterfaceISR (UART_HandleTypeDef *huart);
extern void dumpPacket(char* buffer,int count);
void  CUSTOM_UART_INTERRUPT_INIT();		// user defined Function prototype for actual code related CUSTOM_UART_INTERRUPT_INIT

extern USART_ISR_FUNC  Usart2Func;

void EG25_Interface_Init(void); 	// user defined Function prototype for actual code related EG25_Interface_Init

#ifdef __cplusplus
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

#endif /* INC_EG25INTERFACE_H_ */

