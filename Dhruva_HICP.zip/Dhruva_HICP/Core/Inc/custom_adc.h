/*
 * custom_adc.h
 *
 *  Created on: Dec 19, 2023
 *      Author: HP CORE I3
 */

#ifndef INC_CUSTOM_ADC_H_
#define INC_CUSTOM_ADC_H_

 void custom_adc(void);



#endif /* INC_CUSTOM_ADC_H_ */
