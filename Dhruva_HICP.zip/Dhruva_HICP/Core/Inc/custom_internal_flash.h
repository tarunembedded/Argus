/*
 * custom_internal_flash.h
 *
 *  Created on: Nov 9, 2023
 *      Author: Argus Team
 */

#ifndef INC_CUSTOM_INTERNAL_FLASH_H_
#define INC_CUSTOM_INTERNAL_FLASH_H_

#include "stdint.h"
								//Internal Flash page numbers
#define  FLASH_PAGE_96		96	//Page Number:96
#define  FLASH_PAGE_97		97	//Page Number:97
#define  FLASH_PAGE_98		98	//Page Number:98
#define  FLASH_PAGE_99		99	//Page Number:99
#define  FLASH_PAGE_100		100	//Page Number:100
#define  FLASH_PAGE_101		101	//Page Number:101
#define  FLASH_PAGE_102		102	//Page Number:102
#define  FLASH_PAGE_103		103	//Page Number:103
#define  FLASH_PAGE_104		104	//Page Number:104
#define  FLASH_PAGE_105		105	//Page Number:105
#define  FLASH_PAGE_120		120	//Page Number:120
#define  FLASH_PAGE_121		121	//Page Number:121


void Variable();
uint32_t Internal_flash();	// user defined Function prototype for actual code related Internal Flash
uint32_t Flash_Write_Data (uint32_t StartPageAddress, char *Data, uint16_t numberofwords);	// user defined Function prototype for actual code related Flash_Write_Data

void Flash_Read_Data (uint32_t StartPageAddress, uint32_t *RxBuf, uint16_t numberofwords);	// user defined Function prototype for actual code related Flash_Read_Data

void Convert_To_Str (uint32_t *Data, char *Buf);// user defined Function prototype for actual code related to converting to string

void Flash_Write_NUM (uint32_t StartPageAddress, float Num);	// user defined Function prototype for actual code related to Flash_Write_NUM

float Flash_Read_NUM (uint32_t StartPageAddress);		// user defined Function prototype for actual code related to Flash_Read_NUM
int flash_int_erase();			// user defined Function prototype for actual code related to Internal flash erase


#endif /* INC_CUSTOM_INTERNAL_FLASH_H_ */
