
/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    tickhandler.h
  * @brief   This file contains all the function prototypes for
  *          the tickhandler.c file
  * @Author: Argus Team
  *******************************************************************************/
/* USER CODE END Header */

#ifndef INC_TICK_HANDLER_H_
#define INC_TICK_HANDLER_H_


//#include "common.h"
//#include "API_packet.h"
#include <stdint.h>

void TickHandler(uint32_t data);		// user defined Structure for actual code related TickHandler
void GSMInterfaceEOPHandler(void);		// user defined Structure for actual code related GSMInterfaceEOPHandler
void DebugInterfaceEOPHandler(void);	// user defined Structure for actual code related DebugInterfaceEOPHandler

//uint32_t TSGetUnixTimeStamp(tPacket_TS* data);
//uint32_t GetUnixEpochFromDateTimeString(uint8_t * str );

#endif /* INC_TICK_HANDLER_H_ */


