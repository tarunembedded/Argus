/*
 * app.h
 *
 *  Created on: Nov 1, 2023
 *      Author: Argus Team
 */

#ifndef INC_APP_H_
#define INC_APP_H_

#include "main.h"
#include "i2c.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
#include "sht2x_for_stm32_hal.h" //This user defined header file used to access SHT21.c file
#include <stdlib.h>
#include "string.h"
#include "LoRa.h"		//This user defined header file used to access LoRa.c file
#include "stdio.h"

/* Library files of GSM LTE */
#include "log.h"		//This user defined header file used to access log.c file
#include "tick_handler.h"		//This user defined header file used to access tick_handler.c file
#include "EG25Interface.h"		//This user defined header file used to access EG25Interface.c file
#include "EG25packethandler.h"	//This user defined header file used to access tick_handler.c file
/* Library files of GSM LTE */

 void CUSTOM_APP(void); 	// user defined Function prototype for first phase initializations
 void CUSTOM_UHF();			// user defined Function prototype for actual code related UHF module from which we will get output
 void CUSTOM_GSM();			// user defined Function prototype for actual code related GSM module from which we will get output
 void CUSTOM_LoRa();		// user defined Function prototype for actual code related LoRa module from which we will get output
 void GET_SHT21_DATA();		// user defined Function prototype for actual code related SHT21 Sensor Data from which we will get Temperature and Humidity

 void Custom_Init(void);
 void Sht21_init(void);
 void BQ24193_Init(void);
 void LoRa_Init(void);
 void GSM_Init(void);
 void Internal_flash_init(void);
 void External_flash_init(void);

#endif /* INC_APP_H_ */
