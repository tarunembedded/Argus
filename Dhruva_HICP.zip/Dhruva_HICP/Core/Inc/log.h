/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    log.h
  * @brief   This file contains all the function prototypes for
  *          the log.c file
  * @Author: Argus Team
  *****************************************************************************/
/* USER CODE END Header */

#ifndef INC_LOG_H_
#define INC_LOG_H_

#include <stdio.h>

/*
 * Following macro can be used for enabling/disabling
 * serial debug messages. This will not affect messages
 * on LOG_INFO or LOG_ERROR channels.
 */
#define ENABLE_DEBUG


/*
 * Following macro can be used for enabling/disabling
 * serial message transmission through STLink-SWO
 * interface. It should be either viewed through CubeIDE
 * debug or Cube programmer SWV sessions.
 */
//#define ENABLE_SWO

#define LOG(msg, ...) printf(msg, ##__VA_ARGS__)
#define LOG_ERROR(msg, ...) LOG("ERR: " msg, ##__VA_ARGS__)
#define LOG_INFO(msg, ...) LOG("INF: " msg, ##__VA_ARGS__)
#define LOG_WARN(msg, ...) LOG("WARN: " msg, ##__VA_ARGS__)

#ifdef ENABLE_DEBUG
  #define LOG_DEBUG(msg, ...) LOG("DBG: " msg, ##__VA_ARGS__)
#else
  #define LOG_DEBUG(msg, ...) do {} while (0)
#endif


#endif /* INC_LOG_H_ */

